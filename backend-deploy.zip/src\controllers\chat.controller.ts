import { Request, Response, NextFunction } from 'express';
import ChatMessage from '../models/chatMessage.model.js';
import mongoose from 'mongoose';

// Get global chat messages
export const getGlobalMessages = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { page = 1, limit = 50 } = req.query;

    const options = {
      page: Number(page),
      limit: Number(limit),
      sort: { timestamp: -1 },
      populate: { path: 'sender_id', select: 'username first_name last_name' }
    };

    const messages = await ChatMessage.paginate(
      { room_id: 'global', chat_type: 'global', deleted: false },
      options
    );

    res.json({
      success: true,
      data: {
        ...messages,
        docs: messages.docs.reverse() // Reverse for chronological order
      }
    });
  } catch (error) {
    next(error);
  }
};

// Send global message
export const sendGlobalMessage = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { message, message_type = 'text', file_url } = req.body;
    const userId = (req as any).user?.id;
    const username = (req as any).user?.username || 'User';

    if (!message) {
      return res.status(400).json({
        success: false,
        message: 'Message is required'
      });
    }

    const chatMessage = new ChatMessage({
      room_id: 'global',
      chat_type: 'global',
      sender_id: userId,
      sender_username: username,
      message,
      message_type,
      file_url
    });

    await chatMessage.save();

    res.status(201).json({
      success: true,
      data: chatMessage
    });
  } catch (error) {
    next(error);
  }
};

// Get private chat messages between two users
export const getPrivateMessages = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { otherUserId } = req.params;
    const { page = 1, limit = 50 } = req.query;
    const userId = (req as any).user?.id;

    // Generate room ID (always use sorted user IDs for consistency)
    const roomId = [userId, otherUserId].sort().join('_');

    const options = {
      page: Number(page),
      limit: Number(limit),
      sort: { timestamp: -1 },
      populate: { path: 'sender_id recipient_id', select: 'username first_name last_name' }
    };

    const messages = await ChatMessage.paginate(
      { 
        room_id: roomId, 
        chat_type: 'private',
        deleted: false
      },
      options
    );

    // Mark messages as read
    await ChatMessage.updateMany(
      {
        room_id: roomId,
        recipient_id: userId,
        read: false
      },
      {
        $set: { read: true }
      }
    );

    res.json({
      success: true,
      data: {
        ...messages,
        docs: messages.docs.reverse()
      }
    });
  } catch (error) {
    next(error);
  }
};

// Send private message
export const sendPrivateMessage = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { recipientId, message, message_type = 'text', file_url } = req.body;
    const userId = (req as any).user?.id;
    const username = (req as any).user?.username || 'User';

    if (!message || !recipientId) {
      return res.status(400).json({
        success: false,
        message: 'Message and recipient are required'
      });
    }

    // Generate room ID
    const roomId = [userId, recipientId].sort().join('_');

    const chatMessage = new ChatMessage({
      room_id: roomId,
      chat_type: 'private',
      sender_id: userId,
      sender_username: username,
      recipient_id: recipientId,
      message,
      message_type,
      file_url
    });

    await chatMessage.save();

    res.status(201).json({
      success: true,
      data: chatMessage
    });
  } catch (error) {
    next(error);
  }
};

// Get list of conversations (private chats)
export const getConversations = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const userId = (req as any).user?.id;

    // Find all unique conversations for this user
    const conversations = await ChatMessage.aggregate([
      {
        $match: {
          chat_type: 'private',
          $or: [
            { sender_id: new mongoose.Types.ObjectId(userId) },
            { recipient_id: new mongoose.Types.ObjectId(userId) }
          ]
        }
      },
      {
        $sort: { timestamp: -1 }
      },
      {
        $group: {
          _id: '$room_id',
          lastMessage: { $first: '$$ROOT' },
          unreadCount: {
            $sum: {
              $cond: [
                {
                  $and: [
                    { $eq: ['$recipient_id', new mongoose.Types.ObjectId(userId)] },
                    { $eq: ['$read', false] }
                  ]
                },
                1,
                0
              ]
            }
          }
        }
      },
      {
        $lookup: {
          from: 'users',
          let: {
            senderId: '$lastMessage.sender_id',
            recipientId: '$lastMessage.recipient_id'
          },
          pipeline: [
            {
              $match: {
                $expr: {
                  $or: [
                    { $eq: ['$_id', '$$senderId'] },
                    { $eq: ['$_id', '$$recipientId'] }
                  ]
                }
              }
            }
          ],
          as: 'participants'
        }
      },
      {
        $sort: { 'lastMessage.timestamp': -1 }
      }
    ]);

    res.json({
      success: true,
      data: conversations
    });
  } catch (error) {
    next(error);
  }
};

// Delete message
export const deleteMessage = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;
    const userId = (req as any).user?.id;

    const message = await ChatMessage.findOne({ _id: id, sender_id: userId });

    if (!message) {
      return res.status(404).json({
        success: false,
        message: 'Message not found'
      });
    }

    message.deleted = true;
    await message.save();

    res.json({
      success: true,
      message: 'Message deleted'
    });
  } catch (error) {
    next(error);
  }
};

