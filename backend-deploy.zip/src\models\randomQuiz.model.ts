import { Schema, model, Document } from "mongoose";

import { optionSchema } from "./schemas/question.js";
import { Option } from "./schemas/question.js";

import dotenv from "dotenv";
import { getCurrentDate } from "../utils/date.js";
dotenv.config();

export interface RandomQuestion {
    add_hint: string | null;
    audio: string;
    fun_fact: string;
    id: number;
    image: string;
    is_published: boolean;
    question: string;
    text: string;
    types: string;
    video: string;
    options: Option []
    completed_by: string [],
    language_id: number
    score: number,
    date_time: string,
    title: string, 
}

type RandomQuestionDocument = RandomQuestion & Document

const randomQuestionSchema = new Schema<RandomQuestionDocument>({
    add_hint: { type: String, default: null },
    audio: { type: String, default: null },
    fun_fact: { type: String, default: null },
    id: { type: Number, required: true, index: true },
    image: { type: String, default: null },
    is_published: { type: Boolean, default: true },
    question: { type: String, required: true },
    text: { type: String},
    video: { type: String, default: null },
    score: {type: Number, default: 5},
    language_id: {type: Number, required: true, index: true},
    title: {type: String, required: true},
    date_time: {type: String, default: getCurrentDate()},
    completed_by: {type: [String], default: []},
    options: [optionSchema],
});

randomQuestionSchema.path("image").get(function(value: string | null) {
    const hostname = process.env.HOSTNAME; // Get the hostname from your .env file
    if(value === null || value.length === 0) return null;
    return value.length > 1 ? `${hostname}/${value}` : "";
});
  
randomQuestionSchema.path("video").get(function(value: string | null) {
    const hostname = process.env.HOSTNAME; // Get the hostname from your .env file
    if(value === null || value.length === 0) return null;
    return value.length > 1 ? `${hostname}/${value}` : "";
  });
  
randomQuestionSchema.path("audio").get(function(value: string | null) {
    const hostname = process.env.HOSTNAME; // Get the hostname from your .env file
    if(value === null || value.length === 0) return null;
    return value.length > 1 ? `${hostname}/${value}` : "";
});

const RandomQuizModel = model<RandomQuestionDocument>("randomQuiz", randomQuestionSchema, 'random_quiz');
export default RandomQuizModel;