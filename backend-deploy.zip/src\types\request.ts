import { Request } from "express";
import { UserDocument } from "../models/user.model.js";


export interface AuthenticatedRequest extends Request {
    userId: string
}

export interface AdminRequest extends Request {
    user: UserDocument
}