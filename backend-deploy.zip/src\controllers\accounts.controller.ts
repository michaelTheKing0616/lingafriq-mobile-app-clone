import { Request, Response, NextFunction } from "express";
import UserModel from "../models/user.model.js";
import { AuthenticatedRequest } from "../types/request.js";
import _ from "lodash";
import dotenv from "dotenv";
import djangoHash from "django-hash";
import { ValidationError } from "../utils/error.js";
import jwt, { JwtPayload } from "jsonwebtoken";
import { sendResetEmail } from "../utils/resetEmail.js";

dotenv.config();

export const getUserDetails = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const userId = req.userId;
    const user = await UserModel.findById(userId);
    const ranks = await user.ranks;
    const details = {
      ..._.pick(user, [
        "id",
        "email",
        "first_name",
        "last_name",
        "username",
        "nationality",
        "agree_to_privacy_terms",
        "avater",
        "points",
        "level",
      ]),
      ranks: String(ranks),
      points: String(user.points),
    };
    res.status(200).json({ ...details });
  } catch (e) {
    next(e);
  }
};

export const getProfileInfo = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const profileId = req.query.id;
    const userId = req.userId;

    const currentUser = await UserModel.findById(userId);
    const user = await UserModel.findOne({ id: Number(profileId) });

    if (!user || !currentUser) return res.status(200).json([]);

    const is_current_user = user.id === currentUser.id;
    const completed_point = String(user.points);
    const rank = await user.ranks;
    const details = {
      ..._.pick(user, [
        "id",
        "email",
        "first_name",
        "last_name",
        "username",
        "nationality",
        "agree_to_privacy_terms",
        "avater",
      ]),
      is_current_user,
      completed_point,
      rank,
    };
    res.status(200).json([{ ...details }]);
  } catch (e) {
    next(e);
  }
};

export const updateUserDetails = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const userData = _.pick(req.body, ["first_name", "last_name", "nationality", "avater"]);
    await UserModel.findByIdAndUpdate(req.userId, userData, { new: true });
    res.status(200).json({ msg: "User Updated Successfully" });
  } catch (e) {
    next(e);
  }
};

export const resetUserPassword = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const { email } = req.body;
    const checkUser = await UserModel.findOne({ email: email.toLowerCase().trim() });

    if (!checkUser) return res.status(400).json({ msg: "User not Found" });

    const token = jwt.sign({ _id: checkUser._id }, process.env.JWT_SECRET, { expiresIn: "7d" });

    await sendResetEmail(email, token);

    res.status(204).json({ msg: "Email has been sent to user" });
  } catch (e) {
    next(e);
  }
};

export const handleResetPassword = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const { token, password } = req.body;
    const secret = process.env.JWT_SECRET;
    const decoded = jwt.verify(token, secret) as JwtPayload;
    const userId = decoded._id;
    const user = await UserModel.findById(userId);
    const hashedPassword = await djangoHash.hash(password);
    user.password = hashedPassword;
    await user.save();
    res.status(200).json({ msg: "Password changed successfully" });
  } catch (e) {
    next(e);
  }
};

export const changeUserPassword = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const userId = req.userId;
    const user = await UserModel.findById(userId);

    const { new_password, current_password } = req.body;

    const match = await djangoHash.verify(current_password, user.password);
    if (!match) throw new ValidationError("The current password is not a match");

    if (new_password.length < 6) throw new ValidationError("Password should be at least 6 letters");

    user.password = await djangoHash.hash(new_password);
    await user.save();

    res.status(204).json({ msg: "Password Changed Successfully" });
  } catch (e) {
    next(e);
  }
};

export const deleteUserAccount = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const { current_password } = req.body;
    const userId = req.userId;
    const user = await UserModel.findById(userId);

    const match = await djangoHash.verify(current_password, user.password);

    if (!match) throw new ValidationError("The current password is invalid");

    await UserModel.findByIdAndDelete(userId);

    res.status(200).json({ msg: "User Deleted Successfully" });
  } catch (e) {
    next(e);
  }
};

export const getAllUsersRanked = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const userId = req.userId;
    const page = req.query.page ? Number(req.query.page) : 1;
    if (Number.isNaN(page)) throw new ValidationError("Page parameter should be a number only");

    const fullUrl = `${process.env.HOSTNAME}/account/all_users/`;

    UserModel.paginate({ points: { $gt: 0 } }, { page, limit: 10, sort: { points: -1 } }).then((result) => {
      const count = result.totalDocs;
      const next = result.hasNextPage ? `${fullUrl}?page=${page + 1}` : null;
      const previous = result.hasPrevPage ? `${fullUrl}?page=${page - 1}` : null;
      const results = result.docs;

      const newResults = results.map((item, i) => {
        const rank = (page - 1) * 10 + i + 1;
        const is_current_user = item._id === userId;
        return {
          ..._.pick(item, [
            "id",
            "email",
            "username",
            "first_name",
            "last_name",
            "nationality",
            "agree_to_privacy_terms",
            "avater",
          ]),
          completed_point: String(item.points),
          is_current_user,
          rank,
        };
      });

      res.status(200).json({
        result: {
          count,
          next,
          previous,
          results: newResults,
        },
      });
    });
  } catch (e) {
    next(e);
  }
};

export const updateUsers = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    res.status(200).json({ msg: "Success" });
  } catch (e) {
    next(e);
  }
};

/**
 * @openapi
 * /accounts/auth/users/delete_via_credentials:
 *   post:
 *     summary: Delete account by verifying email + password (no JWT required)
 *     tags:
 *       - Accounts
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               email:
 *                 type: string
 *               password:
 *                 type: string
 *     responses:
 *       '200':
 *         description: Account deleted successfully
 *       '400':
 *         description: Missing email or password
 *       '401':
 *         description: Invalid credentials
 *       '404':
 *         description: User not found
 */
export const deleteUserViaCredentials = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ msg: "Email and password are required" });
    }

    const user = await UserModel.findOne({
      email: { $regex: new RegExp("^" + email.trim() + "$", "i") },
    });

    if (!user) {
      return res.status(404).json({ msg: "User not found" });
    }

    const match = await djangoHash.verify(password, user.password);
    if (!match) {
      return res.status(401).json({ msg: "Invalid credentials" });
    }

    await UserModel.findByIdAndDelete(user._id);
    return res.status(200).json({ msg: "User deleted successfully" });
  } catch (err) {
    next(err);
  }
};
