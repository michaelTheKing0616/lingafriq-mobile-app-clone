import mongoose, { Schema, Document } from 'mongoose';
import { QuizSection, QuizSectionSchema } from './schemas/quiz.js';
import mongoosePaginate from "mongoose-paginate-v2";
import { PaginateModel } from 'mongoose';
import { getUniqueId } from '../utils/random.js';

export interface HistoryQuiz {
  congrats: string;
  id: number;
  language_id: number
  name: string;
  quiz_sections: QuizSection []
}

export type HistoryQuizDocument = HistoryQuiz & Document

const MySchema: Schema = new Schema<HistoryQuizDocument>({
  congrats: { type: String },
  id: { type: Number, required: true, index: true },
  language_id: {type: Number, required: true, index: true},
  name: { type: String, required: true }, 
  quiz_sections: {type: [QuizSectionSchema], default: []},
});

MySchema.plugin(mongoosePaginate)


const HistoryQuizModel = mongoose.model<HistoryQuizDocument, PaginateModel<HistoryQuizDocument>>('historyQuiz', MySchema, "history_quiz");
export default HistoryQuizModel;
