import { Request, Response, NextFunction } from 'express';
import Media from '../models/media.model.js';
import multer from 'multer';
import path from 'path';
import fs from 'fs/promises';

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: async (req, file, cb) => {
    const uploadDir = path.join(process.cwd(), 'uploads', 'media');
    await fs.mkdir(uploadDir, { recursive: true });
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

export const upload = multer({
  storage,
  limits: {
    fileSize: 100 * 1024 * 1024, // 100MB max
  },
  fileFilter: (req, file, cb) => {
    const allowed = /jpeg|jpg|png|gif|mp3|wav|m4a|mp4|mov|avi/;
    const ext = path.extname(file.originalname).toLowerCase();
    const mime = file.mimetype;
    
    if (allowed.test(ext) && (mime.startsWith('image/') || mime.startsWith('audio/') || mime.startsWith('video/'))) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type'));
    }
  }
});

// Upload media file
export const uploadMedia = async (req: Request, res: Response, next: NextFunction) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'No file uploaded'
      });
    }

    const { title, description, language } = req.body;
    const userId = (req as any).user?.id;

    if (!userId) {
      return res.status(401).json({
        success: false,
        message: 'Unauthorized'
      });
    }

    let fileType: 'audio' | 'video' | 'image';
    if (req.file.mimetype.startsWith('audio/')) fileType = 'audio';
    else if (req.file.mimetype.startsWith('video/')) fileType = 'video';
    else fileType = 'image';

    const media = new Media({
      user_id: userId,
      title: title || req.file.originalname,
      description,
      file_type: fileType,
      original_filename: req.file.originalname,
      file_url: `/uploads/media/${req.file.filename}`,
      file_size: req.file.size,
      language,
      processing_status: 'pending',
    });

    await media.save();

    // Trigger background processing (transcription/translation)
    processMediaAsync(media._id.toString()).catch(console.error);

    res.status(201).json({
      success: true,
      data: media
    });
  } catch (error) {
    next(error);
  }
};

// Get user's media files
export const getUserMedia = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const userId = (req as any).user?.id;
    const { page = 1, limit = 20, file_type } = req.query;

    const query: any = { user_id: userId };
    if (file_type) query.file_type = file_type;

    const options = {
      page: Number(page),
      limit: Number(limit),
      sort: { created_at: -1 }
    };

    const media = await Media.paginate(query, options);

    res.json({
      success: true,
      data: media
    });
  } catch (error) {
    next(error);
  }
};

// Get single media file
export const getMediaById = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;
    const userId = (req as any).user?.id;

    const media = await Media.findOne({ _id: id, user_id: userId });

    if (!media) {
      return res.status(404).json({
        success: false,
        message: 'Media not found'
      });
    }

    res.json({
      success: true,
      data: media
    });
  } catch (error) {
    next(error);
  }
};

// Delete media file
export const deleteMedia = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;
    const userId = (req as any).user?.id;

    const media = await Media.findOne({ _id: id, user_id: userId });

    if (!media) {
      return res.status(404).json({
        success: false,
        message: 'Media not found'
      });
    }

    // Delete file from filesystem
    const filePath = path.join(process.cwd(), media.file_url);
    await fs.unlink(filePath).catch(() => {});

    await Media.findByIdAndDelete(id);

    res.json({
      success: true,
      message: 'Media deleted successfully'
    });
  } catch (error) {
    next(error);
  }
};

// Background processing function
async function processMediaAsync(mediaId: string) {
  try {
    const media = await Media.findById(mediaId);
    if (!media) return;

    media.processing_status = 'processing';
    await media.save();

    // TODO: Implement actual transcription/translation
    // For now, just mark as completed
    // In production, you would:
    // 1. Use FFmpeg to extract audio
    // 2. Use Whisper or Google Speech-to-Text for transcription
    // 3. Use translation API for target language

    media.processing_status = 'completed';
    media.transcription = 'Transcription will be available soon';
    media.translation = 'Translation will be available soon';
    await media.save();

    console.log(`✓ Processed media: ${media.title}`);
  } catch (error) {
    console.error(`✗ Error processing media ${mediaId}:`, error);
    
    const media = await Media.findById(mediaId);
    if (media) {
      media.processing_status = 'failed';
      media.processing_error = String(error);
      await media.save();
    }
  }
}

