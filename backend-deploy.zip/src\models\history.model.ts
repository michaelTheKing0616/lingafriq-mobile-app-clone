import mongoose, { Document, PaginateModel } from "mongoose";
import { Lesson, LessonSchema } from "./schemas/lesson.js";
import { QuizSectionSchema, QuizSection } from "./schemas/quiz.js";
import { PaginateDocument } from "mongoose";
import mongoosePaginate from "mongoose-paginate-v2";
import { getUniqueId } from "../utils/random.js";
export interface History{
  congrats: string;
  language_id: number,
  id: number;
  name: string;
  history_lessons: Lesson [];
  quiz_sections: QuizSection [];
}

export type HistoryDocument = History & Document;

const historySchema = new mongoose.Schema<HistoryDocument>({
  congrats: {
    type: String,
  },
  language_id: {type: Number, required: true, index: true},
  id: {
    type: Number,
    index: true,
  },
  name: {
    type: String,
  },
  history_lessons:{
    type:  [LessonSchema],
    default: []
  },
  quiz_sections: {
    type: [QuizSectionSchema],
    default:[]
  },
});

historySchema.plugin(mongoosePaginate);

const HistoryModel = mongoose.model<HistoryDocument, PaginateModel<HistoryDocument>>('history', historySchema, "history");
export default HistoryModel;
