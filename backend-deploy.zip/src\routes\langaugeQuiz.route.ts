import express from 'express';
import { getIdFromJWT, requireSignin } from '../middleware/auth.middleware.js';
import { getAllLanguageQuiz, getLanguageQuizSection, getAllLanguageQuizSection, markLanguageQuizQuestionAsCompleted } from '../controllers/languageQuiz.controller.js';

const router  = express.Router();

router.get("/", requireSignin, getIdFromJWT, getAllLanguageQuiz);

router.get("/:languageId/quizes/:sectionId/quiz_detail", requireSignin, getIdFromJWT, getLanguageQuizSection);

router.patch("/:sectionId/quizes/:questionId/quiz_detail", requireSignin, getIdFromJWT, markLanguageQuizQuestionAsCompleted);

router.get("/:languageId/all", requireSignin, getIdFromJWT, getAllLanguageQuizSection)

export default router;