import { Document, Schema, model, Types } from 'mongoose';
import { QuizSection, QuizSectionSchema } from './schemas/quiz.js';
import { LessonSchema as Less, Lesson as LessonType, LessonDocument as LessonDocumentType } from './schemas/lesson.js';
import mongoosePaginate from "mongoose-paginate-v2";
import { PaginateModel } from 'mongoose';
import { getUniqueId } from '../utils/random.js';


export interface ILesson {
  congrats: string;
  id: number;
  name: string;
  language_id: number,
  lesson_sections: LessonType[],
  quiz_sections: QuizSection [],
}

export type LessonDocument = ILesson & Document

const LessonSchema = new Schema<LessonDocument>({
  congrats: { type: String },
  id: { type: Number, required: true, index: true, default: getUniqueId() },
  language_id: { type: Number, required: true, index: true },
  name: { type: String, required: true },
  lesson_sections: {type: [Less], default: []},
  quiz_sections: {type: [QuizSectionSchema], default: []}
});

LessonSchema.plugin(mongoosePaginate);

const LessonModel = model<LessonDocument, PaginateModel<LessonDocument>>('lesson', LessonSchema, 'lesson');
export default LessonModel;
