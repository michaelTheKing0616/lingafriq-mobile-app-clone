import { Lesson } from "@/models/schemas/lesson.js";
import { NextFunction, Request, Response } from "express";
import { Model, Document } from "mongoose";
import { QuizSection } from "@/models/schemas/quiz.js";
import _ from "lodash";
import { validateLessonSection } from "../utils/validation/validateLessonSection.js";
import { ValidationError } from "../utils/error.js";
import AppMetadata from "../models/appMetadata.model.js";


export interface LessonSectionData {
    date_time: string;
    id: number;
    image: string;
    lesson_section_id: number;
    score: number;
    text: string;
    title: string;
    types: string;
    video: string;
}

interface ModelDocument extends Document {
    language_id: number
    lessons?: Lesson []
    history_lessons?: Lesson []
    lesson_sections?: Lesson [];
    quiz_sections?: QuizSection []
}

export const fetchAllLessonSectionsFromModel = (Model: Model<ModelDocument>) => async (req: Request, res: Response, next: NextFunction) => {
    try{
        const { lesson_id } = req.params;
        
        const lesson = (await Model.findOne({id: lesson_id})).toJSON();

        const lesson_sections = [];
        const quiz_sections = []

        if(lesson.lesson_sections) {
            lesson_sections.push(...lesson.lesson_sections);
        }
        if(lesson.history_lessons) lesson_sections.push(...lesson.history_lessons);
        if(lesson.lessons) lesson_sections.push(...lesson.lessons);

        if(lesson.quiz_sections) quiz_sections.push(...lesson.quiz_sections)

        res.status(200).json({lesson_sections, quiz_sections})
    }
    catch(e){
        next(e);
    }
}

export const addNewLessonSectionToModel = (Model: Model<ModelDocument>) => async <T extends Document> (req: Request, res: Response, next: NextFunction) => {
    try{
        const { lesson_id } = req.params;

        const formData = req.body;

        const image: Express.Multer.File | undefined = req.files["image"];
        const audio: Express.Multer.File | undefined = req.files["audio"];
        const video: Express.Multer.File | undefined = req.files["video"];

        if(image) formData.image = _.replace(image[0].path, "public/media/", "")
        if(audio) formData.audio = _.replace(audio[0].path, "public/media/", "")
        if(video) formData.video = _.replace(video[0].path, "public/media/", "")

        const lesson = await Model.findOne({id: lesson_id});

        const appData = await AppMetadata.findOne({});

        const id = appData.next_lesson_section_id;

        if(lesson.schema.paths["lesson_sections"]){
            const {error, value} = validateLessonSection(formData, Number(lesson_id), id)
            if(error) throw new ValidationError(error.details[0].message);
            lesson.lesson_sections.push({...value})
            appData.languages[lesson.language_id].lesson.lesson_sections.push(id)
        }

        else if(lesson.schema.paths["history_lessons"]){
            const {error, value} = validateLessonSection(formData, Number(lesson_id), id)
            if(error) throw new ValidationError(error.details[0].message);
            lesson.history_lessons.push({...value})
            appData.languages[lesson.language_id].history.lesson_sections.push(id);
        }

        else if(lesson.schema.paths["lessons"]){
            const {error, value} = validateLessonSection(formData, Number(lesson_id), id)
            if(error) throw new ValidationError(error.details[0].message);
            lesson.lessons.push({...value})
            appData.languages[lesson.language_id].history.lesson_sections.push(id)
        }

        await appData.save();
        
        await lesson.save();
        
        res.status(200).json({msg: "New Section Added Successfully"});
    } catch(e){
        next(e)
    }
}

export const updateLessonSectionInModel = (Model: Model<ModelDocument>) => async <T extends Document> (req: Request, res: Response, next: NextFunction) => {
    try {
        const { lesson_id, section_id } = req.params;
    
        const formData = req.body;
    
        const image: Express.Multer.File | undefined = req.files["image"];
        const audio: Express.Multer.File | undefined = req.files["audio"];
        const video: Express.Multer.File | undefined = req.files["video"];
    
        if(image) formData.image = _.replace(image[0].path, "public/media/", "")
        if(audio) formData.audio = _.replace(audio[0].path, "public/media/", "")
        if(video) formData.video = _.replace(video[0].path, "public/media/", "")
    
        const lesson = await Model.findOne({id: lesson_id});

        const {error, value} = validateLessonSection(formData, Number(lesson_id), Number(section_id))
        if(error) throw new ValidationError(error.details[0].message);
    
        if(lesson.schema.paths["lesson_sections"]){
            lesson.lesson_sections = lesson.lesson_sections.map(item=>{
                if(item.id !== Number(section_id)) return item;
                return {
                    ...item,
                    ...value
                }
            })
        }
    
        if(lesson.schema.paths["history_lessons"]){
            lesson.history_lessons = lesson.history_lessons.map(item=>{
                if(item.id !== Number(section_id)) return item;
                return {
                    ...item,
                    ...value
                }
            })
        }
    
        if(lesson.schema.paths["lessons"]){
            lesson.lessons = lesson.lessons.map(item=>{
                if(item.id !== Number(section_id)) return item;
                return {
                    ...item,
                    ...value
                }
            })
        }
    
        await lesson.save();
        
        res.status(200).json({msg: "Lesson Section Added Successfully"});
    } catch (error) {
        next(error)
    }
}

export const deleteLessonSectionFromModel = (Model: Model<ModelDocument>) => async <T extends Document> (req: Request, res: Response, next: NextFunction) => {
    try {
        const { lesson_id, section_id } = req.params;
    
        const lesson = await Model.findOne({id: lesson_id});
        
        if(lesson.schema.paths["lesson_sections"]){
            lesson.lesson_sections = lesson.lesson_sections.filter(section => section.id !== Number(section_id));
        }
    
        if(lesson.schema.paths["history_lessons"]){
            lesson.history_lessons = lesson.history_lessons.filter(section => section.id !== Number(section_id));
        }
    
        if(lesson.schema.paths["lessons"]){
            lesson.lessons = lesson.lessons.filter(section => section.id !== Number(section_id));
        }
    
        await lesson.save();
        
        res.status(200).json({msg: "Lesson Section Deleted Successfully"});
    } catch (error) {
        next(error)
    }
}