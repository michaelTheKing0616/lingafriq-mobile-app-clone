
import { ServiceAccount } from 'firebase-admin';
import serviceAccount from './lingafriq-15d2a-firebase-adminsdk-us33e-bc5f413f35.json' assert {type: "json"};
import admin from 'firebase-admin';

const serviceData = serviceAccount as ServiceAccount

admin.initializeApp({
    credential: admin.credential.cert(serviceData),
});

export const sendMessage = async (token: string, title: string, body: string) => {
    try{
        const message = {
            notification: {
              title,
              body,
            },
            token,
        };
        await admin.messaging().send(message);
        return Promise.resolve(true)
    }catch(e){
        return Promise.resolve(false);
    }
}