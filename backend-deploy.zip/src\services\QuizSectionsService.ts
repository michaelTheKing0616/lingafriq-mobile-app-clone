import { Lesson } from "@/models/schemas/lesson.js";
import { NextFunction, Request, Response } from "express";
import { Model, Document } from "mongoose";
import { QuizSection } from "@/models/schemas/quiz.js";
import _ from "lodash";
import { validateQuizSection } from "../utils/validation/validateQuizSection.js";
import { ValidationError } from "../utils/error.js";
import AppMetadata from "../models/appMetadata.model.js";

export interface LessonSectionData {
    date_time: string;
    id: number;
    image: string;
    lesson_section_id: number;
    score: number;
    text: string;
    title: string;
    types: string;
    video: string;
}

interface ModelDocument extends Document {
    language_id: number
    lessons?: Lesson []
    history_lessons?: Lesson []
    lesson_sections?: Lesson [];
    quiz_sections?: QuizSection []
}

export const addNewQuizSectionToModel = (Model: Model<ModelDocument>) => async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { lesson_id } = req.params;
    
        const formData = req.body as QuizSection;
    
        const lesson = await Model.findOne({id: lesson_id});
    
        // find the highest id in quiz section array
        const appData = await AppMetadata.findOne({});
        const id =  appData.next_quiz_section_id;

        const {error, value} = validateQuizSection(formData, Number(lesson_id),id);
        if(error) throw new ValidationError(error.details[0].message);
        
        if(lesson.schema.paths["quiz_sections"]){
            lesson.quiz_sections.push({...value})
        }

        const collectionName = Model.collection.name as "history" | "lesson" | "history_quiz" | "language_quiz";

        appData.languages[lesson.language_id][collectionName].quiz_sections.push(id);

        appData.save();
    
        await lesson.save();
        
        res.status(200).json({msg: "New Section Added Successfully"});
    } catch (error) {
        next(error)
    }
}

export const updateQuizSectionInModel = (Model: Model<ModelDocument>) => async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { lesson_id, section_id } = req.params;
        const data = req.body as QuizSection;
    
        const lesson = await Model.findOne({id: lesson_id});

        const {error, value} = validateQuizSection(data, Number(lesson_id), Number(section_id))
        if(error) throw new ValidationError(error.details[0].message);
    
        if(lesson.schema.paths["quiz_sections"]){
            lesson.quiz_sections = lesson.quiz_sections.map(section=>{
                if(section.id === Number(section_id)){
                    return {...section, ...value}
                }
                return {...section}
            })
        }
    
        await lesson.save();
        
        res.status(200).json({msg: "Quiz Section Updated Successfully"});
    } catch (error) {
        next(error)
    }
}

export const deleteQuizSectionFromModel = (Model: Model<ModelDocument>) => async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { lesson_id, section_id } = req.params;
    
        const lesson = await Model.findOne({id: lesson_id});
    
        if(lesson.schema.paths["quiz_sections"]){
            lesson.quiz_sections = lesson.quiz_sections.filter(section => section.id !== Number(section_id));
        }
    
        await lesson.save();
        
        res.status(200).json({msg: "Quiz Section Deleted Successfully"});
    } catch (error) {
        next(error)
    }
}