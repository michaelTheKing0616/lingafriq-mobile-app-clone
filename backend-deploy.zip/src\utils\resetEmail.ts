import nodemailer from "nodemailer";

const fullUrl = process.env.HOSTNAME

export const sendResetEmail = async (email: string, token: string): Promise<string> => {
  return new Promise(async (resolve, reject)=>{
    try{
      const transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 465,
        secure: true,
        auth:{
            user:"lingafriq@gmail.com",
            pass:"zwmcuwbcolletvcw"
        }
      });
        
      const mailOptions = {
          from: 'hello@lingafriq.com',
          to: email,
          subject: 'Password Reset Request',
          text: `Click on this link to reset your password: ${fullUrl}/accounts/auth/reset_password/confirm/?token=${token}`,
      };
  
      const res = await transporter.sendMail(mailOptions);
      console.log(res.response);
      resolve("Email sent Successfully")
    } catch(e){
      console.log(e)
      reject("Email Could not be sent")
    }
  })

    

}
  