import mongoose, { Document, Model } from 'mongoose';

interface AppMetadataDocument extends Document {
  languages: {
    [key: number]: {
      language_name: string;
      language_id: number;
      lesson: {
        lesson_sections: number []
        quiz_sections: number []
      }
      history: {
        lesson_sections: number []
        quiz_sections: number []
      }
      mannerism: {
        lesson_sections: number []
      }
      history_quiz: {
        quiz_sections: number []
      }
      language_quiz: {
        quiz_sections: number []
      }
      random_quiz: {
        questions: number []
      }
    }
  }
  next_lesson_section_id: number
  next_quiz_section_id: number
}

interface AppMetadataModel extends Model<AppMetadataDocument> {}

const appMetadataSchema = new mongoose.Schema<AppMetadataDocument>({
  languages: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  }
});

appMetadataSchema.virtual("next_lesson_section_id").get(function(this: AppMetadataDocument){
  let nextLessonID = 1;
  // Find the highest lesson_sections value across all languages
  for (const language of Object.values(this.languages)) {
    for (const lessonSection of language.lesson.lesson_sections) {
      if (lessonSection > nextLessonID) {
        nextLessonID = lessonSection;
      }
    }
    for (const lessonSection of language.history.lesson_sections) {
      if (lessonSection > nextLessonID) {
        nextLessonID = lessonSection;
      }
    }
    for (const lessonSection of language.mannerism.lesson_sections) {
      if (lessonSection > nextLessonID) {
        nextLessonID = lessonSection;
      }
    }
  }

  return nextLessonID + 1;
})

appMetadataSchema.virtual("next_quiz_section_id").get(function(this: AppMetadataDocument){
  let nextLessonID = 1;
  // Find the highest lesson_sections value across all languages
  for (const language of Object.values(this.languages)) {
    for (const id of language.lesson.quiz_sections) {
      if (id > nextLessonID) {
        nextLessonID = id;
      }
    }
    for (const id of language.history.quiz_sections) {
      if (id > nextLessonID) {
        nextLessonID = id;
      }
    }
    for (const id of language.history_quiz.quiz_sections) {
      if (id > nextLessonID) {
        nextLessonID = id;
      }
    }
    for (const id of language.language_quiz.quiz_sections) {
      if (id > nextLessonID) {
        nextLessonID = id;
      }
    }
  }

  return nextLessonID + 1;
})


const AppMetadata: AppMetadataModel = mongoose.model<AppMetadataDocument, AppMetadataModel>('AppMetadata', appMetadataSchema);

export default AppMetadata;
