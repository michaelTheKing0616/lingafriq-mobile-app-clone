import { ILesson } from "@/models/lesson.model.js";
import { NextFunction, Request, Response } from "express";
import { Model, Document } from "mongoose";
import _ from "lodash";
import { validateLesson } from "../utils/validation/validateLesson.js";
import { ValidationError } from "../utils/error.js";

export interface LessonData {
    congrats: string;
    language_id: number,
    id: number;
    name: string;
}

export const fetchAllLessonsFromModel = (Model: Model<Document>) => async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { language_id } = req.params;
        const lessons = await Model.find({language_id});
        res.status(200).json([...lessons])
    } catch (error) {
        next(error)
    }
}

export const addNewLessonToModel = (Model: Model<Document>) => async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { language_id } = req.params;
        const formData = req.body as LessonData;
    
        const lessons = await Model.find({}) as unknown as ILesson [];

        // was:const id = lessons.length > 1 ? _.maxBy(lessons, "id").id + 1 : 1;
        const id = lessons.length >= 1 ? _.maxBy(lessons, "id").id + 1 : 1;

        const {error, value} = validateLesson({...formData, language_id: Number(language_id), id})

        console.log(error);


        if(error) throw new ValidationError(error.details[0].message);

        
        const lesson = new Model({...value});
        await lesson.save();
        res.status(200).json({msg: "Lesson Created successfully"});
    } catch (error) {
        next(error)
    }
}

export const updateLessonInModel = (Model: Model<Document>) => async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { lesson_id } = req.params;
        const formData = req.body as LessonData;

        const {error, value} = validateLesson(formData)
        if(error) throw new ValidationError(error.details[0].message);

        const lesson = await Model.findOneAndUpdate({id: lesson_id}, {...value})

        await lesson.save();
        res.status(200).json({msg: "Lesson Updated successfully"});
    } catch (error) {
        next(error)
    }
}

export const deleteLessonFromModel = (Model: Model<Document>) => async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { lesson_id } = req.params;
        await Model.findOneAndDelete({id: lesson_id});
        res.status(204).json({msg: "Lesson Successfully Deleted"})
    } catch (error) {
        next(error)
    }
}
