import express from 'express';
import { requireAdmin, requireSignin } from '../../middleware/auth.middleware.js';
import multer from "multer";

import * as LessonSectionController from "../../services/LessonSectionsService.js";
import * as QuizSectionController from "../../services/QuizSectionsService.js";
import * as QuestionController from "../../services/QuestionsService.js"
import * as LessonsController from "../../services/LessonService.js"

import LessonModel from '../../models/lesson.model.js';

const storageDisk = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'public/media/lesson/');
    },
    filename: function (req, file, cb) {
        const objName = Date.now().valueOf().toString() + file.originalname
        cb(null, objName);
    }
})

const upload = multer({ storage: storageDisk })

const router = express.Router();

router.get("/get_all_lessons/:language_id", requireSignin, requireAdmin, LessonsController.fetchAllLessonsFromModel(LessonModel));

router.post("/add_new_lesson/:language_id", requireSignin, requireAdmin,  LessonsController.addNewLessonToModel(LessonModel));

router.put("/update_lesson/:lesson_id", requireSignin, requireAdmin, LessonsController.updateLessonInModel(LessonModel));

router.delete("/delete_lesson/:lesson_id",  requireSignin, requireAdmin, LessonsController.deleteLessonFromModel(LessonModel));

/**
 * 
 * Lessons and Quizzes Routes
 * 
 */

router.get("/get_all_sections/:lesson_id", requireSignin, requireAdmin, LessonSectionController.fetchAllLessonSectionsFromModel(LessonModel));

/**
 * 
 * Quiz Section Routes
 * 
 */
router.post("/:lesson_id/quiz_section", requireSignin, requireAdmin, QuizSectionController.addNewQuizSectionToModel(LessonModel));

router.put("/:lesson_id/quiz_section/:section_id", requireSignin, requireAdmin, QuizSectionController.updateQuizSectionInModel(LessonModel));

router.delete("/:lesson_id/quiz_section/:section_id", requireSignin, requireAdmin, QuizSectionController.deleteQuizSectionFromModel(LessonModel));

/**
 * 
 * Lesson Section Routes
 * 
 */
router.post("/:lesson_id/lesson_section", 
    requireSignin, 
    requireAdmin, 
    upload.fields([
        { name: 'image', maxCount: 1 },
        { name: 'audio', maxCount: 1 },
        { name: 'video', maxCount: 1 }
    ]
    ), LessonSectionController.addNewLessonSectionToModel(LessonModel));

router.put("/:lesson_id/lesson_section/:section_id", 
    requireSignin, 
    requireAdmin, 
    upload.fields([
        { name: 'image', maxCount: 1 },
        { name: 'audio', maxCount: 1 },
        { name: 'video', maxCount: 1 }
    ]
    ), LessonSectionController.updateLessonSectionInModel(LessonModel));

router.delete("/:lesson_id/lesson_section/:section_id", requireSignin, requireAdmin, LessonSectionController.deleteLessonSectionFromModel(LessonModel));

/**
 * 
 * Question Routes
 * 
 */
router.get("/:lesson_id/quiz_section/:section_id/questions", requireSignin, requireAdmin, QuestionController.fetchAllQuestionsFromModel(LessonModel))

router.post("/:lesson_id/quiz_section/:section_id/questions", 
    requireSignin, 
    requireAdmin, 
    upload.fields([
        { name: 'image', maxCount: 1 },
        { name: 'audio', maxCount: 1 },
        { name: 'video', maxCount: 1 }
    ]
    ), QuestionController.addNewQuestionsToModel(LessonModel));

// Lesson section upload routes
router.put("/:lesson_id/quiz_section/:section_id/questions/:question_id", 
    requireSignin, 
    requireAdmin, 
    upload.fields([
        { name: 'image', maxCount: 1 },
        { name: 'audio', maxCount: 1 },
        { name: 'video', maxCount: 1 }
]
), QuestionController.updateQuestionsInModel(LessonModel));

router.delete("/:lesson_id/quiz_section/:section_id/questions/:question_id", requireSignin, requireAdmin, QuestionController.deleteQuestionsFromModel(LessonModel))

/**
 * 
 * Word Question Routes
 * 
 */

router.get("/:lesson_id/quiz_section/:section_id/word_questions", requireSignin, requireAdmin, QuestionController.fetchAllWordQuestionsFromModel(LessonModel))

router.post("/:lesson_id/quiz_section/:section_id/word_questions", 
    requireSignin, 
    requireAdmin, 
    upload.fields([
        { name: 'image', maxCount: 1 },
        { name: 'audio', maxCount: 1 },
        { name: 'video', maxCount: 1 }
    ]
    ), QuestionController.addNewWordQuestionsToModel(LessonModel));

// Lesson section upload routes
router.put("/:lesson_id/quiz_section/:section_id/word_questions/:question_id", 
    requireSignin, 
    requireAdmin, 
    upload.fields([
        { name: 'image', maxCount: 1 },
        { name: 'audio', maxCount: 1 },
        { name: 'video', maxCount: 1 }
]
), QuestionController.updateWordQuestionsInModel(LessonModel));

router.delete("/:lesson_id/quiz_section/:section_id/word_questions/:question_id", requireSignin, requireAdmin, QuestionController.deleteWordQuestionsInModel(LessonModel))




export default router;