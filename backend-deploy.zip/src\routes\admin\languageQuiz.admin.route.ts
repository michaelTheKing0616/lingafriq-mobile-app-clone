import express from 'express';
import { requireAdmin, requireSignin } from '../../middleware/auth.middleware.js';

import * as LessonSectionController from "../../services/LessonSectionsService.js";
import * as QuizSectionController from "../../services/QuizSectionsService.js";
import * as QuestionController from "../../services/QuestionsService.js"
import * as LessonsController from "../../services/LessonService.js"

import LanguageQuizModel from '../../models/languageQuiz.model.js';

import multer from "multer";

const storageDisk = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'public/media/language_quiz/');
    },
    filename: function (req, file, cb) {
        const objName = Date.now().valueOf().toString() + file.originalname
        cb(null, objName);
    }
})

const upload = multer({ storage: storageDisk })

const router = express.Router();

router.get("/get_all_lessons/:language_id", requireSignin, requireAdmin, LessonsController.fetchAllLessonsFromModel(LanguageQuizModel));

router.post("/add_new_lesson/:language_id", requireSignin, requireAdmin,  LessonsController.addNewLessonToModel(LanguageQuizModel));

router.put("/update_lesson/:lesson_id", requireSignin, requireAdmin, LessonsController.updateLessonInModel(LanguageQuizModel));

router.delete("/delete_lesson/:lesson_id",  requireSignin, requireAdmin, LessonsController.deleteLessonFromModel(LanguageQuizModel));

/**
 * Lesson And Quiz Routes
 */
router.get("/get_all_sections/:lesson_id", requireSignin, requireAdmin, LessonSectionController.fetchAllLessonSectionsFromModel(LanguageQuizModel));

/**
 * Quiz Section Routes
 */
router.post("/:lesson_id/quiz_section", requireSignin, requireAdmin, QuizSectionController.addNewQuizSectionToModel(LanguageQuizModel));

router.put("/:lesson_id/quiz_section/:section_id", requireSignin, requireAdmin, QuizSectionController.updateQuizSectionInModel(LanguageQuizModel));

router.delete("/:lesson_id/quiz_section/:section_id", requireSignin, requireAdmin, QuizSectionController.deleteQuizSectionFromModel(LanguageQuizModel));

/** 
 * Question Routes
 */
router.get("/:lesson_id/quiz_section/:section_id/questions", requireSignin, requireAdmin, QuestionController.fetchAllQuestionsFromModel(LanguageQuizModel))

// Question section upload routes
router.post("/:lesson_id/quiz_section/:section_id/questions", 
    requireSignin, 
    requireAdmin, 
    upload.fields([
        { name: 'image', maxCount: 1 },
        { name: 'audio', maxCount: 1 },
        { name: 'video', maxCount: 1 }
    ]
    ), QuestionController.addNewQuestionsToModel(LanguageQuizModel));

// Lesson section upload routes
router.put("/:lesson_id/quiz_section/:section_id/questions/:question_id", 
    requireSignin, 
    requireAdmin, 
    upload.fields([
        { name: 'image', maxCount: 1 },
        { name: 'audio', maxCount: 1 },
        { name: 'video', maxCount: 1 }
]
), QuestionController.updateQuestionsInModel(LanguageQuizModel));

router.delete("/:lesson_id/quiz_section/:section_id/questions/:question_id", requireSignin, requireAdmin, QuestionController.deleteQuestionsFromModel(LanguageQuizModel))

export default router;