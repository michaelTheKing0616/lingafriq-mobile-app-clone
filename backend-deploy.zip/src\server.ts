import mongoose from "mongoose";
import http from "http";
import app from "./app.js";
import swaggerDocs from "./utils/swagger.js";
import { initSocketServer } from "./services/socket.service.js";

const port = Number(process.env.PORT) || 4000;
const server = http.createServer(app);

mongoose.connection.on("connected",()=>{
    try{
        server.listen(port, ()=>{
            console.log('app is running on port ' + port);
            console.log("app is running on a " + process.env.NODE_ENV + " Enviroment")
            initSocketServer(server);
            swaggerDocs(app, port)
        })
    } catch(e){
        console.log(e)
    }
})

mongoose.connection.on("error", (e)=>{
    console.log(e)
})