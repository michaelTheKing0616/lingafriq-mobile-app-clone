import express from 'express';
import { getIdFromJWT, requireSignin } from '../middleware/auth.middleware.js';
import { getALLRandomQuizQuestions, markRandomQuestionAsComplete } from '../controllers/randomQuiz.controller.js';


const router = express.Router();

router.get("/:languageId/all", requireSignin, getIdFromJWT, getALLRandomQuizQuestions);

router.patch("/:languageId/questions/:questionId/inst_ques_detail", requireSignin, getIdFromJWT, markRandomQuestionAsComplete)



export default router