import express from 'express';
import { getIdFromJWT, requireSignin } from '../middleware/auth.middleware.js';
import { getAllHistoryQuiz, getHistoryQuizSections, getAllHistoryQuizSection, markHistoryQuizQuestionAsCompleted } from '../controllers/historyQuiz.controller.js';

const router = express.Router();

router.get("/", requireSignin, getIdFromJWT, getAllHistoryQuiz);

router.get("/:lessonId/quizes/:sectionId/quiz_detail", requireSignin, getIdFromJWT, getHistoryQuizSections)

router.patch("/:lessonId/quizes/:sectionId/quiz_detail", requireSignin, getIdFromJWT, markHistoryQuizQuestionAsCompleted)

router.get("/:lessonId/all", requireSignin, getIdFromJWT, getAllHistoryQuizSection);

export default router;