import express from 'express';
import { requireAdmin, requireSignin } from '../../middleware/auth.middleware.js';
import { addNewLanguage, deleteLanguage, getAllLanguages, updateLanguage } from '../../controllers/admin/language.admin.controller.js';
import multer from "multer";

const storageDisk = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'public/media/');
    },
    filename: function (req, file, cb) {
        const objName = Date.now().valueOf().toString() + file.originalname
        cb(null, objName);
    }
})

  
const upload = multer({ storage: storageDisk })

const router = express.Router();

router.get("/get_all", requireSignin, requireAdmin, getAllLanguages);

router.post("/add_new_language", requireSignin, requireAdmin, upload.single("background"), addNewLanguage);

router.put("/update_language/:language_id", requireSignin, requireAdmin, upload.single("background"), updateLanguage);

router.delete("/delete_language/:language_id",  requireSignin, requireAdmin, deleteLanguage);

export default router;
