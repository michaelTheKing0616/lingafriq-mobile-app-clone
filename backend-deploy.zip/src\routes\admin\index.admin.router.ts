import express from "express";
import accountRouter from "./account.admin.route.js";
import languageRouter from "./language.admin.route.js";
import messageRouter from "./messages.admin.route.js";
import lessonRouter from "./lessons.admin.route.js";
import historyRouter from "./history.admin.route.js";
import mannerismRouter from "./mannerism.admin.route.js";
import languageQuizRouter from "./languageQuiz.admin.route.js"
import historyQuizRouter from "./historyQuiz.model.js";
import randomQuizRouter from "./randomQuiz.admin.route.js";
import defaultRouter from "./defaults.admin.route.js"

const router = express.Router();

router.use("/accounts", accountRouter);

router.use("/language", languageRouter);

router.use("/message", messageRouter);

router.use("/lesson", lessonRouter);

router.use("/history", historyRouter);

router.use("/mannerism", mannerismRouter);

router.use("/history_quiz", historyQuizRouter);

router.use("/language_quiz", languageQuizRouter);

router.use("/random_quiz", randomQuizRouter);

router.use("/defaults", defaultRouter)

export default router