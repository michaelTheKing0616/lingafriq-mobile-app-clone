import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import morgan from 'morgan';
import cookieParser from 'cookie-parser';
import dotenv from 'dotenv';
import helmet from "helmet"
import router from "./routes/index.route.js";

// middlewares
import errorHandler from './middleware/errorHandler.middleware.js';
import { storeDefaults } from './utils/defaults.js';

dotenv.config();

const connectWithRetry = async () => {
    try{
        const mongodbUri = process.env.MONGODB_URI
        if (mongodbUri) await mongoose.connect(mongodbUri);
        console.log("app is connected to mongodb table");
    } catch(e){
        console.error('Failed to connect to MongoDB:', e);
        console.log('Retrying connection in 5 seconds...');
        setTimeout(connectWithRetry, 5000);
    }
}

if(process.env.NODE_ENV !== "test"){
    connectWithRetry();
}

const app = express();

// add express admin
// const connected = await startApp(app);
// console.log(connected)

// serve static files
app.use(express.static('public'));

//apply express middleware
app.use(helmet())
app.use(cors({ credentials: true, origin: ["https://lingafriq.com", "https://www.lingafriq.com", "http://localhost:5500", 'https://lingafriq-admin.web.app'] }));
app.use(cookieParser());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
// app.use(multer().none());
app.use(morgan('dev'));

app.use(router)

app.use("/accounts/auth/reset_password/confirm/", express.static("views"));

app.get("/store", storeDefaults)

app.use(errorHandler);

export default app;
