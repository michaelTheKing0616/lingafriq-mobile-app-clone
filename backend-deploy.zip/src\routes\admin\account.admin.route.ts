import express from 'express';
import { adminLogin } from "../../controllers/admin/auth.admin.controller.js";
import { getAllUsers, deleteUserAsAdmin, editUser } from '../../controllers/admin/accounts.admin.controller.js';
import { requireAdmin, requireSignin } from '../../middleware/auth.middleware.js';
import { logout } from '../../controllers/admin/auth.admin.controller.js';


const router = express.Router();

router.post("/auth/login", adminLogin); 

router.get("/get_all_accounts", requireSignin, requireAdmin, getAllUsers);

router.post("/delete_user_as_admin", requireSignin, requireAdmin, deleteUserAsAdmin);

router.post("/edit_user", requireSignin, requireAdmin, editUser);

router.get("/log_out", logout);

export default router;
