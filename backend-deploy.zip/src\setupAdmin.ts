import AdminJS from 'adminjs'
import AdminJSExpress from '@adminjs/express';
import * as AdminsMongoose from "@adminjs/mongoose";
import {Express} from 'express'
import UserModel from './models/user.model.js';
import HistoryModel from './models/history.model.js';
import HistoryQuizModel from './models/historyQuiz.model.js';
import LanguageModel from './models/language.model.js';
import LanguageQuizModel from './models/languageQuiz.model.js';
import RandomQuizModel from './models/randomQuiz.model.js';
import MannerismModel from './models/mannerism.model.js';
import LessonModel from './models/lesson.model.js';

const DEFAULT_ADMIN = {
    email: 'admin@lingafriq.com',
    password: 'lingafriq123',
}

const authenticate = async (email: string, password: string) => {
    if (email === DEFAULT_ADMIN.email && password === DEFAULT_ADMIN.password) {
      return Promise.resolve(DEFAULT_ADMIN)
    }
    return null
}

AdminJS.registerAdapter({
    Resource:AdminsMongoose.Resource,
    Database: AdminsMongoose.Database
})

export const startApp = (app:Express) : Promise<string>=> {
    return new Promise(async (resolve, reject)=>{
        try{

            const adminOptions = {
                resources: [UserModel, HistoryModel, HistoryQuizModel, LanguageModel, LanguageQuizModel, RandomQuizModel, MannerismModel, LessonModel],
                rootPath: "/admin"
            }

            const admin = new AdminJS(adminOptions)

            // const adminRouter = AdminJSExpress.buildRouter(admin);
            const adminRouter = AdminJSExpress.buildAuthenticatedRouter(admin, 
                {
                    authenticate,
                    cookieName: "AdminJS",
                    cookiePassword: "Secret",
                }
            )
            app.use(admin.options.rootPath, adminRouter)
            resolve("Connected to Admin")
        }catch(e){
            reject("Could not connect to Admin")
        }
    })
}