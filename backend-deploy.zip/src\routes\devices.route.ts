import express from 'express';
import { getIdFromJWT, requireSignin } from '../middleware/auth.middleware.js';
import { getAllDevices, removeDevice, addDevice } from '../controllers/devices.controller.js';

const router  = express.Router();

router.get("/", requireSignin, getIdFromJWT, getAllDevices);

router.post("/", requireSignin, getIdFromJWT, addDevice);

router.delete("/:token", removeDevice);

export default router;