import { IUser } from "../../models/user.model.js"
import { ValidationError } from "../error.js";
import djangoHash from "django-hash";

type UserData = Omit<IUser,"is_active" | "is_staff" | "is_admin" | "last_login" | "id">

export const validateUser = async (userData : UserData) :Promise<IUser> => {
    const randomNumber = Math.floor(Math.random() * 10000000000000) + 1;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!userData.email || typeof userData.email !== "string" || !emailRegex.test(userData.email)) {
        throw new ValidationError("Invalid email");
    }
    if (!userData.password || typeof userData.password !== "string" || userData.password.length < 6) {
        throw new ValidationError("Invalid password (must be at least 6 characters)");
    }
    if (!userData.username || typeof userData.username !== "string" || userData.username.length < 3) {
        throw new ValidationError("Invalid username(must be a string of atleast 3 characters)");
    }
    if (!userData.first_name || typeof userData.first_name !== "string") {
        throw new ValidationError("Invalid first_name");
    }
    if (!userData.last_name || typeof userData.last_name !== "string") {
        throw new ValidationError("Invalid last_name");
    }
    if (!userData.nationality || typeof userData.nationality !== "string") {
        throw new ValidationError("Invalid Nationality");
    }

    const newPassword: string = await djangoHash.hash(userData.password);

    return {
        ...userData, 
        email: userData.email.toLowerCase().trim(), 
        username: userData.username.trim(),
        password: newPassword, 
        is_active: true, 
        is_admin: false, 
        is_staff: false, 
        id: randomNumber, 
        last_login: null,
        level: "Beginner",
        avater: null
    }
}