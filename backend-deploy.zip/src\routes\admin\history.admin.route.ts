import express from 'express';
import { requireAdmin, requireSignin } from '../../middleware/auth.middleware.js';

import * as LessonSectionController from "../../services/LessonSectionsService.js";
import * as QuizSectionController from "../../services/QuizSectionsService.js";
import * as QuestionController from "../../services/QuestionsService.js"
import * as LessonsController from "../../services/LessonService.js"

import HistoryModel from '../../models/history.model.js';

import multer from "multer";

const storageDisk = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'public/media/history/');
    },
    filename: function (req, file, cb) {
        const objName = Date.now().valueOf().toString() + file.originalname
        cb(null, objName);
    }
})

const upload = multer({ storage: storageDisk })

const router = express.Router();

router.get("/get_all_lessons/:language_id", requireSignin, requireAdmin, LessonsController.fetchAllLessonsFromModel(HistoryModel));

router.post("/add_new_lesson/:language_id", requireSignin, requireAdmin,  LessonsController.addNewLessonToModel(HistoryModel));

router.put("/update_lesson/:lesson_id", requireSignin, requireAdmin, LessonsController.updateLessonInModel(HistoryModel));

router.delete("/delete_lesson/:lesson_id",  requireSignin, requireAdmin, LessonsController.deleteLessonFromModel(HistoryModel));

/**
 * Lesson And Quiz Routes
 */
router.get("/get_all_sections/:lesson_id", requireSignin, requireAdmin, LessonSectionController.fetchAllLessonSectionsFromModel(HistoryModel));

/**
 * Lesson Section Routes
 */
router.post("/:lesson_id/lesson_section", 
    requireSignin, 
    requireAdmin, 
    upload.fields([
        { name: 'image', maxCount: 1 },
        { name: 'audio', maxCount: 1 },
        { name: 'video', maxCount: 1 }
    ]
    ), LessonSectionController.addNewLessonSectionToModel(HistoryModel));

router.put("/:lesson_id/lesson_section/:section_id", 
    requireSignin, 
    requireAdmin, 
    upload.fields([
        { name: 'image', maxCount: 1 },
        { name: 'audio', maxCount: 1 },
        { name: 'video', maxCount: 1 }
    ]
    ), LessonSectionController.updateLessonSectionInModel(HistoryModel));

router.delete("/:lesson_id/lesson_section/:section_id", requireSignin, requireAdmin, LessonSectionController.deleteLessonSectionFromModel(HistoryModel));

/**
 * Quiz Section Routes
 */
router.post("/:lesson_id/quiz_section", requireSignin, requireAdmin, QuizSectionController.addNewQuizSectionToModel(HistoryModel));

router.put("/:lesson_id/quiz_section/:section_id", requireSignin, requireAdmin, QuizSectionController.updateQuizSectionInModel(HistoryModel));

router.delete("/:lesson_id/quiz_section/:section_id", requireSignin, requireAdmin, QuizSectionController.deleteQuizSectionFromModel(HistoryModel));

/** 
 * Question Routes
 */
router.get("/:lesson_id/quiz_section/:section_id/questions", requireSignin, requireAdmin, QuestionController.fetchAllQuestionsFromModel(HistoryModel))

// Question section upload routes
router.post("/:lesson_id/quiz_section/:section_id/questions", 
    requireSignin, 
    requireAdmin, 
    upload.fields([
        { name: 'image', maxCount: 1 },
        { name: 'audio', maxCount: 1 },
        { name: 'video', maxCount: 1 }
    ]
    ), QuestionController.addNewQuestionsToModel(HistoryModel));

// Lesson section upload routes
router.put("/:lesson_id/quiz_section/:section_id/questions/:question_id", 
    requireSignin, 
    requireAdmin, 
    upload.fields([
        { name: 'image', maxCount: 1 },
        { name: 'audio', maxCount: 1 },
        { name: 'video', maxCount: 1 }
]
), QuestionController.updateQuestionsInModel(HistoryModel));

router.delete("/:lesson_id/quiz_section/:section_id/questions/:question_id", requireSignin, requireAdmin, QuestionController.deleteQuestionsFromModel(HistoryModel))

export default router;