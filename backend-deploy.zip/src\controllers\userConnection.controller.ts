import { Request, Response, NextFunction } from 'express';
import UserConnection from '../models/userConnection.model.js';
import User from '../models/user.model.js';

// Send connection request
export const sendConnectionRequest = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { connectedUserId } = req.body;
    const userId = (req as any).user?.id;

    if (!connectedUserId) {
      return res.status(400).json({
        success: false,
        message: 'Connected user ID is required'
      });
    }

    if (userId === connectedUserId) {
      return res.status(400).json({
        success: false,
        message: 'Cannot connect with yourself'
      });
    }

    // Check if connection already exists
    const existing = await UserConnection.findOne({
      $or: [
        { user_id: userId, connected_user_id: connectedUserId },
        { user_id: connectedUserId, connected_user_id: userId }
      ]
    });

    if (existing) {
      return res.status(400).json({
        success: false,
        message: 'Connection already exists'
      });
    }

    // Create bidirectional connection
    const connection1 = new UserConnection({
      user_id: userId,
      connected_user_id: connectedUserId,
      status: 'pending',
      initiated_by: userId
    });

    const connection2 = new UserConnection({
      user_id: connectedUserId,
      connected_user_id: userId,
      status: 'pending',
      initiated_by: userId
    });

    await connection1.save();
    await connection2.save();

    res.status(201).json({
      success: true,
      data: connection1
    });
  } catch (error) {
    next(error);
  }
};

// Accept connection request
export const acceptConnectionRequest = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { connectionId } = req.params;
    const userId = (req as any).user?.id;

    const connection = await UserConnection.findOne({ _id: connectionId, user_id: userId, status: 'pending' });

    if (!connection) {
      return res.status(404).json({
        success: false,
        message: 'Connection request not found'
      });
    }

    // Update both connections to accepted
    await UserConnection.updateMany(
      {
        $or: [
          { user_id: userId, connected_user_id: connection.connected_user_id },
          { user_id: connection.connected_user_id, connected_user_id: userId }
        ]
      },
      {
        $set: { status: 'accepted' }
      }
    );

    res.json({
      success: true,
      message: 'Connection accepted'
    });
  } catch (error) {
    next(error);
  }
};

// Reject/Remove connection
export const rejectConnection = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { connectionId } = req.params;
    const userId = (req as any).user?.id;

    const connection = await UserConnection.findOne({ _id: connectionId, user_id: userId });

    if (!connection) {
      return res.status(404).json({
        success: false,
        message: 'Connection not found'
      });
    }

    // Delete both connections
    await UserConnection.deleteMany({
      $or: [
        { user_id: userId, connected_user_id: connection.connected_user_id },
        { user_id: connection.connected_user_id, connected_user_id: userId }
      ]
    });

    res.json({
      success: true,
      message: 'Connection removed'
    });
  } catch (error) {
    next(error);
  }
};

// Get user's connections
export const getConnections = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const userId = (req as any).user?.id;
    const { status = 'accepted' } = req.query;

    const connections = await UserConnection.find({
      user_id: userId,
      status
    }).populate('connected_user_id', 'username first_name last_name email completed_point');

    res.json({
      success: true,
      data: connections
    });
  } catch (error) {
    next(error);
  }
};

// Get pending connection requests
export const getPendingRequests = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const userId = (req as any).user?.id;

    const requests = await UserConnection.find({
      user_id: userId,
      status: 'pending',
      initiated_by: { $ne: userId } // Only show requests initiated by others
    }).populate('connected_user_id', 'username first_name last_name email completed_point');

    res.json({
      success: true,
      data: requests
    });
  } catch (error) {
    next(error);
  }
};

// Search users to connect with
export const searchUsers = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { query, page = 1, limit = 20 } = req.query;
    const userId = (req as any).user?.id;

    if (!query) {
      return res.status(400).json({
        success: false,
        message: 'Search query is required'
      });
    }

    // Find users matching the query
    const users = await User.find({
      _id: { $ne: userId },
      $or: [
        { username: { $regex: query, $options: 'i' } },
        { first_name: { $regex: query, $options: 'i' } },
        { last_name: { $regex: query, $options: 'i' } }
      ]
    })
      .select('username first_name last_name email completed_point')
      .limit(Number(limit))
      .skip((Number(page) - 1) * Number(limit));

    // Check connection status for each user
    const userIds = users.map(u => u._id);
    const connections = await UserConnection.find({
      user_id: userId,
      connected_user_id: { $in: userIds }
    });

    const connectionMap = new Map(connections.map(c => [c.connected_user_id.toString(), c.status]));

    const usersWithStatus = users.map(user => ({
      ...user.toObject(),
      connectionStatus: connectionMap.get(user._id.toString()) || 'none'
    }));

    res.json({
      success: true,
      data: usersWithStatus
    });
  } catch (error) {
    next(error);
  }
};

