import express from 'express';
import * as mediaController from '../controllers/media.controller.js';
import { protect } from '../middleware/auth.middleware.js';

const router = express.Router();

// All routes require authentication
router.use(protect);

router.post('/upload', mediaController.upload.single('file'), mediaController.uploadMedia);
router.get('/', mediaController.getUserMedia);
router.get('/:id', mediaController.getMediaById);
router.delete('/:id', mediaController.deleteMedia);

export default router;

