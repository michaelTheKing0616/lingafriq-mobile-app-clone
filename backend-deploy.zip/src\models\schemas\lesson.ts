import mongoose,{ Document, model, Schema } from 'mongoose';
import dotenv from "dotenv";
import { getCurrentDate } from '../../utils/date.js';
import { getUniqueId } from '@/utils/random.js';

dotenv.config()

export interface Lesson {
  audio: string;
  date_time: string;
  id: number;
  image: string;
  lesson_section_id: number;
  score: number;
  text: string;
  title: string;
  types: string;
  video: string;
}

export interface LessonDocument extends Lesson , Omit<Document, "id"> {}

const LessonSchema = new Schema<LessonDocument>({
  audio: {
    type: String,
    default: null,
  },
  date_time: {
    type: String,
    default: getCurrentDate()
  },
  id: {
    type: Number,
    required: true,
  },
  image: {
    type: String,
    default: null,
  },
  lesson_section_id: {
    type: Number,
    required: true,
  },
  score: {
    type: Number,
    required: true,
    default: 5
  },
  text: {
    type: String,
  },
  title: {
    type: String,
  },
  types: {
    type: String,
    default: "Tutorial"
  },
  video: {
    type: String,
    default: null,
  },
}, {virtuals: true});

LessonSchema.set("toJSON", {
  transform: function (doc, ret) {
    const hostname = process.env.HOSTNAME; // Make sure HOSTNAME is set in your environment
    if(ret.image && ret.image.length > 0){
      ret.image = `${hostname}/media/${ret.image}`; // Modify the image URL
    }
    if(ret.audio && ret.audio.length > 0){
      ret.audio = `${hostname}/media/${ret.audio}`; // Modify the image URL
    }
    if(ret.video && ret.video.length > 0){
      ret.video = `${hostname}/media/${ret.video}`; // Modify the image URL
    }
    return ret;
  },
})

LessonSchema.path("image").get(function(value: string | null) {
  const hostname = process.env.HOSTNAME; // Get the hostname from your .env file
  if(value === null || value.length === 0) return null;
  return value.length > 1 ? `${hostname}/media/${value}` : "";
});

LessonSchema.path("video").get(function(value: string | null) {
  const hostname = process.env.HOSTNAME; // Get the hostname from your .env file
  if(value === null || value.length === 0) return null;
  return value.length > 1 ? `${hostname}/media/${value}` : "";
});

LessonSchema.path("audio").get(function(value: string | null) {
  const hostname = process.env.HOSTNAME; // Get the hostname from your .env file
  if(value === null || value.length === 0) return null;
  return value.length > 1 ? `${hostname}/media/${value}` : "";
});

export { LessonSchema };
