import express from 'express';
import { getIdFromJWT, requireSignin } from '../middleware/auth.middleware.js';
import { getAllMannerism, getAllMannerismLessons, getMannerismLessonSections, markMannerismSectionAsCompleted } from '../controllers/mannerism.controller.js';

const router = express.Router();

router.get("/", requireSignin,  getIdFromJWT, getAllMannerism );

router.get("/:lessonId/all", requireSignin,  getIdFromJWT, getAllMannerismLessons)

router.get("/:lessonId/mannerism/:sectionId/lessons", requireSignin,  getIdFromJWT, getMannerismLessonSections);

router.patch("/:lessonId/mannerism/:sectionId/lessons", requireSignin,  getIdFromJWT, markMannerismSectionAsCompleted);


export default router;