import express from 'express';
import { getIdFromJWT, requireSignin } from '../middleware/auth.middleware.js';
import { getAllHistory, getHistoryLessonsSections, getHistoryQuizSections, getAllHistoryLessonsandQuizzes, markHistoryLessonAsCompleted, markHistoryQuizSectionAsCompleted } from '../controllers/history.controller.js';

const router = express.Router();

router.get("/", requireSignin, getIdFromJWT, getAllHistory);

router.get("/:lessonId/lessons/:sectionId/history_lesson", requireSignin, getIdFromJWT, getHistoryLessonsSections)

router.patch("/:lessonId/lessons/:sectionId/history_lesson", requireSignin, getIdFromJWT, markHistoryLessonAsCompleted)

router.get("/:lessonId/quizes/:sectionId/quiz_detail", requireSignin, getIdFromJWT, getHistoryQuizSections)

router.patch("/:lessonId/quizes/:sectionId/quiz_detail", requireSignin, getIdFromJWT, markHistoryQuizSectionAsCompleted)

router.get("/:lessonId/all", requireSignin, getIdFromJWT, getAllHistoryLessonsandQuizzes);


export default router;