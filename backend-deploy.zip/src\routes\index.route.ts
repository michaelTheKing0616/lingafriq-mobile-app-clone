// routers 
import authRouter from '../routes/auth.route.js';
import languageRouter from "../routes/language.route.js";
import lessonsRouter from "../routes/lessons.route.js";
import historyRouter from "../routes/history.route.js";
import mannerismRouter from "../routes/mannerism.route.js";
import historyQuizRouter from "../routes/historyQuiz.route.js";
import randomQuizRouter from "../routes/randomQuiz.route.js";
import languageQuizRouter from "../routes/langaugeQuiz.route.js";
import accountsRouter from "../routes/accounts.route.js";
import accountRouter from "../routes/account.route.js";
import devicesRouter from "../routes/devices.route.js";
import loadingScreenRouter from "../routes/loadingScreen.route.js";
import adminRouter from './admin/index.admin.router.js';
// New feature routers
import cultureMagazineRouter from "../routes/cultureMagazine.route.js";
import mediaRouter from "../routes/media.route.js";
import chatRouter from "../routes/chat.route.js";
import userConnectionRouter from "../routes/userConnection.route.js";
import scraperRouter from "../routes/scraper.route.js";
import multer from 'multer';

import { Request, Response } from 'express';
import { Router } from 'express';

const router  = Router()

//initialize routes

/**
   * @openapi
   * /healthcheck:
   *  get:
   *     tags:
   *     - Healthcheck
   *     description: Responds if the app is up and running
   *     responses:
   *       200:
   *         description: App is up and running
   */
router.get("/healthcheck", ((req: Request, res: Response)=>res.status(200).json({ok: true})));

router.use('/auth', multer().none(), authRouter);
router.use("/language",multer().none(), languageRouter);
router.use("/lessons",multer().none(), lessonsRouter);
router.use("/history",multer().none(), historyRouter);
router.use("/mannerism",multer().none(), mannerismRouter);
router.use("/history_quiz",multer().none(), historyQuizRouter);
router.use("/random_quiz",multer().none(), randomQuizRouter);
router.use("/language_quiz",multer().none(), languageQuizRouter);
router.use("/accounts",multer().none(), accountsRouter);
router.use("/account",multer().none(), accountRouter);
router.use("/devices",multer().none(), devicesRouter);
router.use("/loading-screen",multer().none(), loadingScreenRouter);
router.use("/admin", adminRouter);

// New feature routes
router.use("/culture-magazine", cultureMagazineRouter);
router.use("/media", mediaRouter);
router.use("/chat", chatRouter);
router.use("/connections", userConnectionRouter);
router.use("/scraper", scraperRouter); // Secure API for automated scrapers


export default router;