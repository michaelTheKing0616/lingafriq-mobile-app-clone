import Joi from "joi";
import { getCurrentDate } from "../date.js";

const optionsSchema = Joi.object({
    id: Joi.number().required(),
    quiz_question_id: Joi.number().required(),
    correct_answer: Joi.boolean().required(),
    image: Joi.string().allow(null, "").default(''),
    text: Joi.string().min(1).required(),
});

export const validateRandomQuestion = (formData: any) => {
    return Joi.object({
        language_id: Joi.number(),
        id: Joi.number().unsafe(),
        add_hint: Joi.string().allow(null, "").default(null),
        audio: Joi.string().allow(null, "").default(''),
        fun_fact: Joi.string().allow(null, "").default(null),
        image: Joi.string().allow(null, "").default(''),
        is_published: Joi.boolean().default(true),
        question: Joi.string().required(),
        text: Joi.string().allow(null, ""),
        video: Joi.string().allow(null, "").default(''),
        options: Joi.array().items(optionsSchema).default([]),
        score: Joi.number().default(5),
        title: Joi.string().allow(null, ""),
        date_time: Joi.string().default(getCurrentDate())
    }).validate(formData, {allowUnknown: true, stripUnknown: true})
}