import { NextFunction, Response } from "express";
import { AuthenticatedRequest } from "../types/request.js";
import HistoryModel from "../models/history.model.js";
import _ from "lodash";
import { ValidationError } from "../utils/error.js";
import UserModel from "../models/user.model.js";


export const getAllHistory = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try{
        const userId = req.userId;
        const page = 1;
        const limit = 50;
        
        const fullUrl = process.env.HOSTNAME;

        HistoryModel.paginate({}, {page, limit}).then((result)=>{
            let total_score = 0;
            const count = result.totalDocs;
            const next = result.hasNextPage ? `${fullUrl}?page=${page + 1}` : null;
            const previous = result.hasPrevPage ? `${fullUrl}?page=${page - 1}` : null;
            const results = result.docs;
            const data = results.map(result=>{

                const count = result.history_lessons.length;
                let completed = 0;
                let score = 0;
                const history_language = result.language_id;

                result.history_lessons.forEach((section)=>{
                    score = score + section.score;
                    total_score = total_score + section.score;
                })

                result.quiz_sections.forEach((section)=>{
                    score = score + section.score;
                    total_score = total_score + section.score;
                })

                return {count, completed, score, history_language, id:result.id, congrats: result.congrats, name: result.name}
            })
            res.status(200).json({ total_score, result: {count, next, previous, results:data }});
        })
        
    }catch(e){
        next(e);
    }
}

export const getHistoryLessonsSections = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try{
        const userId = req.userId
        const lessonId = Number(req.params.lessonId);
        const sectionId = Number(req.params.sectionId);

        if (typeof lessonId !== "number" || typeof sectionId !== "number" ) throw new ValidationError("Id should be a number");

        const lesson = await HistoryModel.findOne({id: lessonId});
        const lessonSection = lesson.history_lessons.find(section=>section.id === sectionId);

        return res.status(200).json([{
            ..._.pick(lessonSection, ["id", "title", "score","types", "date_time", "text", "image", "audio", "video"]),
            lesson_history: lessonSection.lesson_section_id,
            completed_by: userId
        }]);
    } catch (e){
        next(e)
    }
}

export const getHistoryQuizSections = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try{
        const lessonId = Number(req.params.lessonId);
        const sectionId = Number(req.params.sectionId);

        if (typeof lessonId !== "number" || typeof sectionId !== "number" ) throw new ValidationError("Id should be a number");

        const lesson = await HistoryModel.findOne({id: lessonId});
        
        const quizSection = lesson.quiz_sections.find(section=>section.id === sectionId);

        if(quizSection === undefined) return res.status(200).json([])

        const quiz = [{
            ..._.pick(quizSection, ["id", "quiz", "quiz_type", "score", "date_time", "quiz_section"]),
            completed_by: req.userId,
        }]

        const questionItem = []

            if(quizSection.quiz_type === "Word Quiz"){
                const word_question  = [];
                quizSection.word_questions.forEach(questionItem=>{
                    const question = {
                        ..._.pick(questionItem, ["id", "question", "text", "add_hint", "is_published", "types", "content"]),
                        lesson_section: questionItem.quiz_section_id,
                    }
                    word_question.push(question);
                })
                questionItem.push(...word_question);
            }
            else if (quizSection.quiz_type === "Instant Quiz"){
                const questionArray = [];
                quizSection.questions.forEach(questionItem=>{
                    const choices = questionItem.options;
                    const question = {
                        ..._.pick(questionItem, ["id", "question", "text", "add_hint", "is_published", "types", "image", "audio", "video","fun_fact"]),
                        lesson_section: questionItem.quiz_section_id
                    }
                    questionArray.push({question, choices});
                })
                questionItem.push(...questionArray);
            }

            return res.status(200).json([{quiz, question: questionItem}])
    } catch (e){
        next(e)
    }
}

export const getAllHistoryLessonsandQuizzes = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try{
        const lessonId = Number(req.params.lessonId);

        const user = await UserModel.findById(req.userId);
        const lesson = await HistoryModel.findOne({id: lessonId});

        if(!lesson) res.status(200).json([]);

        const lessonsArray = lesson.history_lessons.map(item=>{
            const completed = user.history.lesson_sections.includes(item.id);
            return {
                ..._.pick(item, ["id", "title", "text", "image", "audio", "video", "score", "types", "date_time"]),
                completed_by: completed ? user.id :  null,
                lesson_section: item.lesson_section_id
            }
        })

        const quizArray = lesson.quiz_sections.map(item=>{
            const completed = user.history.quiz_sections.includes(item.id);

            const quiz = [{
                ..._.pick(item, ["id", "quiz", "quiz_type", "score", "date_time"]),
                completed_by: completed ? user.id :  null,
                quiz_section: item.quiz_section_id
            }]

            const questionItem = []

            if(item.quiz_type === "Word Quiz"){
                const word_question  = [];
                item.word_questions.forEach(questionItem=>{
                    const question = {
                        ..._.pick(questionItem, ["id", "question", "text", "add_hint", "is_published", "types", "content"]),
                        quize_history: questionItem.quiz_section_id,
                    }
                    word_question.push(question);
                })
                questionItem.push(...word_question);
            }
            else if (item.quiz_type === "Instant Quiz"){
                const questionArray = [];
                item.questions.forEach(questionItem=>{
                    const choices = questionItem.options.map(item=>{
                        return {..._.pick(item, ["id", "text", "image", "correct_answer"]), history_question: item.quiz_question_id}
                    })
                    const question = {
                        ..._.pick(questionItem, ["id", "question", "text", "image", "audio", "video", "add_hint", "fun_fact", "is_published", "types"]),
                        quize_history: questionItem.quiz_section_id
                    }
                    questionArray.push({question, choices});
                })
                questionItem.push(...questionArray);
            }

            return {quiz, question: questionItem}
        })

        res.status(200).json([...lessonsArray, ...quizArray])
    } catch(e){
        next(e)
    }
}

export const markHistoryLessonAsCompleted = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try{
        const { lessonId, sectionId } = req.params;

        if(!lessonId || !sectionId) throw new ValidationError("language Id and question Id should be provided")

        const history = await HistoryModel.findOne({id: lessonId});

        if(!history) throw new Error("Document not Found")

        const history_lesson = history.history_lessons.find(item=> item.id === Number(sectionId));


        const currentUser = await UserModel.findById(req.userId);

        let msg;

        if(!currentUser.history.lesson_sections.includes(Number(sectionId))){
            currentUser.points = currentUser.points + history_lesson.score;
            currentUser.history.lesson_sections.push(Number(sectionId))
            await currentUser.save();
            msg = "Lesson Completed Successfully"
        }
        else msg = "You have already completed this Lesson!"

        res.status(200).json({msg})

    } catch(e){
        next(e)
    }
}

export const markHistoryQuizSectionAsCompleted = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try{
        const { lessonId, sectionId } = req.params;

        if(!lessonId || !sectionId) throw new ValidationError("language Id and question Id should be provided")

        const history = await HistoryModel.findOne({id: lessonId});

        if(!history) throw new Error("Document not Found");

        const lesson = history.quiz_sections.find(item=> item.id === Number(sectionId));
        
        const currentUser = await UserModel.findById(req.userId);

        let msg;

        if(!currentUser.history.quiz_sections.includes(Number(sectionId))){
            currentUser.points = currentUser.points + lesson.score;
            currentUser.history.quiz_sections.push(Number(sectionId))
            await currentUser.save();
            msg = "Lesson Completed Successfully"
        }
        else msg = "You have already completed this Lesson!"

        res.status(200).json({msg})

    } catch(e){
        next(e)
    }
}