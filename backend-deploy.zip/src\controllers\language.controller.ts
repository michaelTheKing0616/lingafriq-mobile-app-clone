import LanguageModel from '../models/language.model.js';
import { Response, NextFunction } from "express";
import _ from "lodash";
import LessonModel from '../models/lesson.model.js';
import { AuthenticatedRequest } from '../types/request.js';
import UserModel from '../models/user.model.js';
import { AuthenticationError } from '../utils/error.js';
import MannerismModel from '../models/mannerism.model.js';
import HistoryModel from '../models/history.model.js';

export const getAllLanguages = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try{

        const limit = 10;
        let page = 1;

        if(typeof req.query.page === "string") page = parseInt(req.query.page);
        if(Array.isArray(req.query.page) && typeof req.query.page[0] === "string") page = parseInt(req.query.page[0]);

        const user = await UserModel.findById(req.userId);

        if (!user) throw new AuthenticationError("User Not found");

        const fullUrl = process.env.HOSTNAME;

        await LanguageModel.paginate({is_published: true}, {page, limit}).then( async (result) => {
            const count = result.totalDocs;
            const next = result.hasNextPage ? `${fullUrl}?page=${page + 1}` : null;
            const previous = result.hasPrevPage ? `${fullUrl}?page=${page - 1}` : null;

            const results = await Promise.all(result.docs.map(async doc=>{

                let total_score = 0;
                let total_count = 0;
                let completed = 0;

                const lessonArray = await LessonModel.find({language_id: doc.id});
                const mannerism = await MannerismModel.findOne({language_id: doc.id});
                const history = await HistoryModel.findOne({language_id:doc.id})

                mannerism.lessons.forEach(item=>{
                    total_count++
                    if(user.mannerism.lesson_sections.includes(item.id)){
                        total_score = total_score + item.score;
                        completed++
                    }
                })

                history.history_lessons.forEach(item=>{
                    total_count++
                    if(user.history.lesson_sections.includes(item.id)){
                        total_score = total_score + item.score;
                        completed++
                    }
                })

                lessonArray.forEach(lesson=>{
                    lesson.lesson_sections.forEach((item)=>{
                        total_count++;
                        if(user.lesson.lesson_sections.includes(item.id)){
                            total_score = total_score + item.score;
                            completed++;
                        }
                    })
                })

                return {..._.pick(doc, ["id", "Inrtoduction", "background", "name", "level_language", "is_published", "is_featured"]), 
                total_score,
                total_count,
                completed
            }
            }));
            res.json({result: { count, next, previous, results }});
        });
        
    }catch(e){
        next(e);
    }
}