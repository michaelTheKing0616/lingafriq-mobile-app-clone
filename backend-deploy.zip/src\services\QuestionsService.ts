import { Lesson } from "@/models/schemas/lesson.js";
import { NextFunction, Request, Response } from "express";
import { Model, Document } from "mongoose";
import { QuizSection } from "@/models/schemas/quiz.js";
import _ from "lodash";
import { validateWordQuestion } from "../utils/validation/validateWordQuestion.js";
import { validateQuestion } from "../utils/validation/validateQuestion.js";
import { Option } from "@/models/schemas/question.js";
import { ValidationError } from "../utils/error.js";

interface ModelDocument extends Document {
    lessons?: Lesson []
    history_lessons?: Lesson []
    lesson_sections?: Lesson [];
    quiz_sections?: QuizSection []
}

export const fetchAllQuestionsFromModel = (Model: Model<ModelDocument>) => async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { lesson_id, section_id } = req.params;
        const lessons = (await Model.findOne({id: lesson_id})).toJSON();
        const questions = lessons.quiz_sections.find(item=> item.id === Number(section_id)).questions

        res.status(200).json([...questions])
    } catch (error) {
        next(error)
    }
}

export const addNewQuestionsToModel = (Model: Model<ModelDocument>) => async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { lesson_id, section_id } = req.params;
    
        const formData = req.body;
    
        const image: Express.Multer.File | undefined = req.files["image"];
        const audio: Express.Multer.File | undefined = req.files["audio"];
        const video: Express.Multer.File | undefined = req.files["video"];
    
        if(image) formData.image = _.replace(image[0].path, "public/media/", "")
        if(audio) formData.audio = _.replace(audio[0].path, "public/media/", "")
        if(video) formData.video = _.replace(video[0].path, "public/media/", "")
    
        const lesson = await Model.findOne({id: Number(lesson_id)});
    
        const section = lesson.quiz_sections.find(item=>item.id === Number(section_id))
    
        const quiz_question_id = section.questions.length > 0 ? _.maxBy(section.questions, "id").id + 1 : 1;

        formData.options = JSON.parse(formData.options).map((option: Option, index: number)=>{
            return {
                ...option,
                id: index + 1,
                quiz_question_id: quiz_question_id
            }
        }) as Option [];

        const {error, value} = validateQuestion({...formData}, Number(section_id), quiz_question_id)

        if(error) throw new ValidationError(error.details[0].message);

        lesson.quiz_sections = lesson.quiz_sections.map(item=>{
            if(item.id !== Number(section_id)) return item;
            item.questions.push({...value})
            return item;
        })
    
        await lesson.save();
    
        res.status(200).json({msg: "Question Added Suceesfully"})
    } catch (error) {
        next(error)
    }
}

export const updateQuestionsInModel = (Model: Model<ModelDocument>) => async <T extends Document> (req: Request, res: Response, next: NextFunction) => {
    try {
        const { lesson_id, section_id, question_id } = req.params;
    
        const formData = req.body;

        const image: Express.Multer.File | undefined = req.files["image"];
        const audio: Express.Multer.File | undefined = req.files["audio"];
        const video: Express.Multer.File | undefined = req.files["video"];
    
        if(image) formData.image = _.replace(image[0].path, "public/media/", "")
        if(audio) formData.audio = _.replace(audio[0].path, "public/media/", "")
        if(video) formData.video = _.replace(video[0].path, "public/media/", "")
    
        const lesson = await Model.findOne({id: Number(lesson_id)});

        formData.options = JSON.parse(formData.options).map((option: Option, index: number)=>{
            return {
                ...option,
                id: index + 1,
                quiz_question_id: question_id
            }
        }) as Option [];

        const {error, value} = validateQuestion({...formData}, Number(section_id), Number(question_id));

        if(error) throw new ValidationError(error.details[0].message);

        lesson.quiz_sections = lesson.quiz_sections.map(item=>{
            if(item.id !== Number(section_id)) return item;
            return {
                ...item,
                questions: item.questions.map(question=>{
                    if(question.id === Number(question_id)){
                        return {
                            ...question,
                            ...value, 
                        }
                    }
                    return question
                })
            }
        })
    
        await lesson.save();
    
        res.status(200).json({msg: "Question Updated Suceesfully"})
    } catch (error) {
        next(error)
    }
}

export const deleteQuestionsFromModel = (Model: Model<ModelDocument>) => async <T extends Document> (req: Request, res: Response, next: NextFunction) => {
    try {
        const { lesson_id, section_id, question_id } = req.params;
    
        const lesson = await Model.findOne({id: Number(lesson_id)});
    
        lesson.quiz_sections = lesson.quiz_sections.map(item=>{
            if(item.id !== Number(section_id)) return item;
            return {
                ...item,
                questions: item.questions.filter(item=>item.id !== Number(question_id))
            }
        })
    
        await lesson.save();
    
        res.status(200).json({msg: "Question Updated Suceesfully"})
    } catch (error) {
        next(error)
    }
}

export const fetchAllWordQuestionsFromModel = (Model: Model<ModelDocument>) => async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { lesson_id, section_id } = req.params;
        const lessons = await Model.findOne({id: lesson_id});
        const questions = lessons.quiz_sections.find(item=> item.id === Number(section_id)).word_questions;
        res.status(200).json([...questions])
    } catch (error) {
        next(error)
    }
}

export const addNewWordQuestionsToModel = (Model: Model<ModelDocument>) => async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { lesson_id, section_id } = req.params;
    
        const formData = req.body;
    
        const lesson = await Model.findOne({ id: Number(lesson_id) });
    
        const section = lesson.quiz_sections.find(item=>item.id === Number(section_id))
    
        const quiz_question_id = section.questions.length > 0 ? _.maxBy(section.questions, "id").id + 1 : 1;

        const {error, value} = validateWordQuestion({...formData, quiz_section_id: section_id, id: quiz_question_id })

        if(error) throw new ValidationError(error.details[0].message);

        lesson.quiz_sections = lesson.quiz_sections.map(item=>{
            if(item.id !== Number(section_id)) return item;
            item.word_questions.push({...value})
            return item;
        })
    
        await lesson.save();
    
        res.status(200).json({msg: "Question Added Suceesfully"})
    } catch (error) {
        next(error)
    }
}

export const updateWordQuestionsInModel = (Model: Model<ModelDocument>) => async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { lesson_id, section_id, question_id } = req.params;
    
        const formData = req.body;
    
        const lesson = await Model.findOne({ id: Number(lesson_id) });
    
        const {error, value} = validateWordQuestion({...formData, quiz_section_id: section_id, id: question_id })

        if(error) throw new ValidationError(error.details[0].message);

        lesson.quiz_sections = lesson.quiz_sections.map(item=>{
            if(item.id !== Number(section_id)) return item;
            return {
                ...item,
                word_questions: item.word_questions.map((question)=>{
                    return {
                        ...question,
                        ...value
                    }
                })
            }
        })
    
        await lesson.save();
    
        res.status(200).json({msg: "Word Question Updated Suceesfully"})
    } catch (error) {
        next(error)
    }
}

export const deleteWordQuestionsInModel = (Model: Model<ModelDocument>) => async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { lesson_id, section_id, question_id } = req.params;
    
        const lesson = await Model.findOne({id: Number(lesson_id)});
    
        lesson.quiz_sections = lesson.quiz_sections.map(item=>{
            if(item.id !== Number(section_id)) return item;
            return {
                ...item,
                word_questions: item.word_questions.filter(item=>item.id !== Number(question_id))
            }
        })
    
        await lesson.save();
    
        res.status(200).json({msg: "Question Updated Suceesfully"})
    } catch (error) {
        next(error)
    }
}