import Joi from "joi"

export const validateLesson = (formData: any) => {
    return Joi.object({
        id: Joi.number().unsafe().optional(), 
        congrats: Joi.string().allow(null, ""),
        language_id: Joi.number().unsafe().optional(),
        name: Joi.string(),
    }).validate(formData, {allowUnknown: true, stripUnknown: true, presence: "optional"})
}