import express, { Request, Response } from 'express';
import { getIdFromJWT, requireSignin } from '../middleware/auth.middleware.js';
import { getProfileInfo, deleteUserAccount, getAllUsersRanked} from '../controllers/accounts.controller.js';
import { login, register } from '../controllers/auth.controller.js';

const router  = express.Router();

router.get("/my_user_profile/", requireSignin, getIdFromJWT, getProfileInfo);

router.get("/update", requireSignin, getIdFromJWT, ((req: Request, res: Response)=>res.status(200).send({ok: true})))

router.delete("/user_delete/:userId" , requireSignin, getIdFromJWT, deleteUserAccount);

// POST alias for clients that can't send DELETE with body
router.post("/user_delete", requireSignin, getIdFromJWT, deleteUserAccount);

router.get("/all_users", requireSignin, getIdFromJWT, getAllUsersRanked);


export default router;
