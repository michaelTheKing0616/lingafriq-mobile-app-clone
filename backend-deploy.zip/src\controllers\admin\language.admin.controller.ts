import { NextFunction, Request, Response } from "express";
import { AdminRequest } from "../../types/request.js";
import LanguageModel, { Language } from "../../models/language.model.js";
import { validateLanguage } from "../../utils/validation/validateLanguage.js";
import { convertToBoolean } from "../../utils/convertToBoolean.js";
import { LanguageData } from "../../utils/validation/validateLanguage.js";
import _ from "lodash";
import AppMetadata from "../../models/appMetadata.model.js";

export const getAllLanguages = async (req: AdminRequest, res: Response, next: NextFunction) => {
    try{
        const languages = await LanguageModel.find({});

        const parsedLanguages = languages.map((doc)=>{
            return {
                ..._.pick(doc, ["id", "_id", "background", "name", "is_featured", "is_published", "level_language", "createdAt", "updatedAt", "Introduction"])
            }
        })
        res.status(200).json([...parsedLanguages])
    } catch(e){
        next(e)
    }
}

export const addNewLanguage = async (req: AdminRequest, res: Response, next: NextFunction) => {
    try{
        const data = req.body as LanguageData;

        // todo add language validation
        validateLanguage(data);

        const file = req.file;

        const background = file.filename;

        const language = new LanguageModel({
            ...data, 
            is_featured: convertToBoolean(data.is_featured), 
            is_published: convertToBoolean(data.is_published),
            background
        });

        await language.save();

        const appData = await AppMetadata.findOne({});
        appData.languages[language.id] = {
            language_id: language.id,
            language_name: language.name,
                lesson: {
                    lesson_sections: [],
                    quiz_sections: []
                },
                history: {
                    lesson_sections: [],
                    quiz_sections: []
                },
                mannerism: {
                    lesson_sections: []
                },
                history_quiz: {
                    quiz_sections: []
                },
                language_quiz: {
                    quiz_sections: []
                },
                random_quiz: {
                    questions: []
                }
        }
        res.status(201).json({msg: "Language successfully added"})
    } catch(e){
        next(e)
    }
}

export const updateLanguage = async (req: AdminRequest, res: Response, next: NextFunction) => {
    try{
        const data = req.body as LanguageData;
        const { language_id } = req.params;

        const file = req.file;

        const dataToBeSaved = {
            ...data,
        }

        if (file){
            dataToBeSaved.background = file.filename;
        }

        const langauge = await LanguageModel.findOneAndUpdate({id: language_id}, dataToBeSaved);

        res.status(200).json({msg: "Language successfully updated"})
    } catch(e){
        next(e)
    }
}

export const deleteLanguage = async (req: AdminRequest, res: Response, next: NextFunction) => {
    try{
        const { language_id }= req.params;
        await LanguageModel.findOneAndDelete({id: language_id});
        res.status(204).json({msg: "Language Successfully Deleted"});
    } catch(e){
        next(e)
    }
}