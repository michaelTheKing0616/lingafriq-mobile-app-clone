import express from 'express';
import { requireAdmin, requireSignin } from '../../middleware/auth.middleware.js';
import AppMetadata from '../../models/appMetadata.model.js';


const router = express.Router();

router.get("/get", requireSignin, requireAdmin, async (req, res, next)=>{
    try{
        const appData = await AppMetadata.findOne({});
        res.status(200).json([...Object.values(appData.languages)]);
    } catch(e){
        next(e)
    }
})

export default router