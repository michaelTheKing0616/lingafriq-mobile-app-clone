import mongoose, { Document, Schema, model } from 'mongoose';
import { WordQuestion, questionSchema, wordQuestionSchema } from './question.js';
import { Question } from './question.js';
import { getCurrentDate } from '../../utils/date.js';
import { getUniqueId } from '../../utils/random.js';

export interface QuizSection  {
  date_time: string;
  id: number;
  quiz: string;
  quiz_section_id: number;
  quiz_type: string;
  score: number;
  questions: Question[];
  word_questions: WordQuestion [],
}

type QuizSectionDocument = QuizSection & Document

export const QuizSectionSchema = new Schema<QuizSectionDocument>({
  date_time: { type: String, required: true, default: getCurrentDate() },
  id: { type: Number, required: true, default: getUniqueId()},
  quiz: { type: String },
  quiz_section_id: { type: Number, required: true },
  quiz_type: { type: String },
  score: { type: Number },
  questions: {
    type: [questionSchema],
    default: []
  },
  word_questions: {
    type: [wordQuestionSchema],
    default: []
  },
});