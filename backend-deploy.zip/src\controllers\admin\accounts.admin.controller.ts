import { NextFunction, Response } from "express";
import { AdminRequest } from "../../types/request.js";
import UserModel from "../../models/user.model.js";
import { ValidationError } from "../../utils/error.js";


export const getAllUsers = async (req: AdminRequest, res: Response, next: NextFunction) => {
    try{
        const { _id:userId } = req.user;
        // const users = await UserModel.find({ _id: { $ne: userId }});
        const users = await UserModel.find({});
        res.status(200).json(users);
    } catch(e){
        next(e)
    }
}

export const deleteUserAsAdmin = async (req: AdminRequest, res: Response, next: NextFunction) => {
    try{
        const { id } = req.body;
        if(!id) throw new ValidationError("No Id was provided")
        await UserModel.findOneAndDelete({id});
        res.status(204).json({msg: "User has been deleted"});
    } catch(e){
        next(e)
    }
}

export const editUser = async (req: AdminRequest, res: Response, next: NextFunction) => {
    try{
        const { id, is_admin, is_active } = req.body;
        if(!id) throw new ValidationError("No Id was provided")
        const user = await UserModel.findOneAndUpdate({id: id}, { is_admin, is_active });
        res.status(200).json({msg: "User has been edited successfully"});
    } catch(e){
        next(e)
    }
}