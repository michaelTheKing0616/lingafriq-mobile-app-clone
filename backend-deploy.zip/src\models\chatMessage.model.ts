import mongoose, { Document, Schema } from 'mongoose';
import mongoosePaginate from 'mongoose-paginate-v2';

export interface IChatMessage extends Document {
  room_id: string; // 'global' for global chat, or private room ID
  chat_type: 'global' | 'private';
  sender_id: mongoose.Types.ObjectId;
  sender_username: string;
  recipient_id?: mongoose.Types.ObjectId; // for private chats
  message: string;
  message_type: 'text' | 'image' | 'audio' | 'video' | 'file';
  file_url?: string;
  read: boolean;
  deleted: boolean;
  edited: boolean;
  timestamp: Date;
  created_at: Date;
}

const chatMessageSchema = new Schema<IChatMessage>({
  room_id: { type: String, required: true, index: true },
  chat_type: { type: String, required: true, enum: ['global', 'private'] },
  sender_id: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  sender_username: { type: String, required: true },
  recipient_id: { type: Schema.Types.ObjectId, ref: 'User' },
  message: { type: String, required: true },
  message_type: { type: String, default: 'text', enum: ['text', 'image', 'audio', 'video', 'file'] },
  file_url: { type: String },
  read: { type: Boolean, default: false },
  deleted: { type: Boolean, default: false },
  edited: { type: Boolean, default: false },
  timestamp: { type: Date, default: Date.now },
  created_at: { type: Date, default: Date.now }
});

chatMessageSchema.plugin(mongoosePaginate);

chatMessageSchema.index({ room_id: 1, timestamp: -1 });
chatMessageSchema.index({ sender_id: 1, recipient_id: 1 });

const ChatMessage = mongoose.model<IChatMessage>('ChatMessage', chatMessageSchema);
export default ChatMessage as any; // Type assertion for paginate plugin

