import { Schema, Document, model } from 'mongoose';

interface IMessage {
    message: {
        body: string;
        title: string;
    }
    users: number []
}

interface MessageDocument extends IMessage, Document {}

const MessageSchema = new Schema<MessageDocument>({
    users: [Number],
    message: {
        body: String,
        title: String,
    },
}, {timestamps: true});

const MessageModel = model<MessageDocument>("message", MessageSchema);
export default MessageModel;

