import express from 'express';
import { getIdFromJWT, requireSignin } from '../middleware/auth.middleware.js';
import { getAllLanguages } from '../controllers/language.controller.js';


const router = express.Router();

router.get("/", requireSignin, getIdFromJWT, getAllLanguages);

export default router;