import express from 'express';
import { getIdFromJWT, requireSignin } from '../middleware/auth.middleware.js';
import { getAllLessons, getLesson, getLessonSection, getAllLessonsandQuizzes, getQuizSection, markLessonSectionAsCompleted, markQuizSectionAsCompleted } from '../controllers/lessons.controller.js';

const router = express.Router();

router.get("/", requireSignin, getIdFromJWT, getAllLessons);

router.get("/:id", requireSignin,getIdFromJWT, getLesson);

router.get("/:lessonId/lessons/:sectionId/lesson_lesson", getIdFromJWT, getLessonSection);

router.patch("/:lessonId/lessons/:sectionId/lesson_lesson", getIdFromJWT, markLessonSectionAsCompleted);

router.get("/:lessonId/lessons/:sectionId/quiz_detail", getIdFromJWT, getQuizSection);

router.patch("/:lessonId/lessons/:sectionId/quiz_detail", getIdFromJWT, markQuizSectionAsCompleted);

router.get("/:lessonId/all", requireSignin, getIdFromJWT, getAllLessonsandQuizzes);

export default router;