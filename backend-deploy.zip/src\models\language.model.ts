import mongoose, { ObjectId } from "mongoose";
import { Document, Schema, model } from 'mongoose';

import mongoosePaginate from "mongoose-paginate-v2";

import { PaginateModel } from "mongoose";
import { getUniqueId } from "../utils/random.js";

export interface Language {
  Introduction: string;
  background: string;
  id: number;
  is_featured: boolean;
  is_published: boolean;
  level_language: "Beginner" | "Intermediate" | "Expert";
  name: string;
}

// type LanguageDocument = Language & Document
interface LanguageDocument extends Language, Omit<Document, "id"> {}

const languageSchema = new mongoose.Schema<LanguageDocument>({
  Introduction: {
    type: String,
    required: true
  },
  background: {
    type: String,
  },
  id: {
    type: Number,
    unique: true,
    default: getUniqueId(),
    index: true
  },
  is_featured: {
    type: Boolean,
    default: true
  },
  is_published: {
    type: Boolean,
    default: true
  },
  level_language: {
    type: String,
    default: "Beginner"
  },
  name: {
    type: String,
    required: true
  },
}, {timestamps: true, virtuals: true});

languageSchema.virtual("Inrtoduction").get(function(){
  return this.Introduction
})

languageSchema.path("background").get(function(value: string){
  const prefix = process.env.HOSTNAME;
  return `${prefix}/media/${value}`;
})

languageSchema.plugin(mongoosePaginate)

const LanguageModel = model<LanguageDocument, PaginateModel<LanguageDocument>>('language', languageSchema, "language");
export default LanguageModel;