import jwt from 'jsonwebtoken';
import djangoHash from "django-hash";

import { Request, Response, NextFunction } from "express";
import { AuthenticationError, ValidationError } from "../utils/error.js";
import { validateUser } from "../utils/validation/validateUser.js";
import UserModel from "../models/user.model.js";
import dotenv from "dotenv";

import moment from "moment";
import { dateFormat } from "../utils/date.js";
import { getUniqueId } from '../utils/random.js';

dotenv.config()


export const register = async (req: Request, res:Response, next: NextFunction) => {
    try{
        const body = req.body;
        const validatedUser = await validateUser(body);

        const checkUserName = await UserModel.findOne({ username: { $regex: new RegExp('^' + validatedUser.username+ '$', 'i') } });

        if(checkUserName) throw new AuthenticationError("Username Already taken");

        const checkEmail = await UserModel.findOne({ email: { $regex: new RegExp('^' + validatedUser.email + '$', 'i') } });

        if(checkEmail) throw new AuthenticationError("Email Already taken");

        let id: number;
        let checkId = null;

        do{
            id = getUniqueId();
            checkId = await UserModel.findOne({id: id});
        }
        while(checkId);

        const newUser = new UserModel({...validatedUser, id});
        await newUser.save();
        res.status(201).json({ ok: true })
    }
    catch(e){
        next(e);
    }
}

export const login = async (req: Request, res:Response, next: NextFunction) => {
    try{
        // get login details from request
        const {email, password} = req.body;
        if(email.length < 1 || password.length < 6){
            throw new ValidationError("Email and password are required")
        }

        // check to see if user is in system and return with error message
        const user = await UserModel.findOne({ email: { $regex: new RegExp('^' + email.trim() + '$', 'i') } })
        if(!user) throw new AuthenticationError("User not Found");


        const match = await djangoHash.verify(password, user.password);
        if(!match) throw new AuthenticationError("Password is not a match");

        user.last_login = moment().format(dateFormat);
        await user.save()

        const token = jwt.sign({_id: user._id.toString()}, process.env.JWT_SECRET , {expiresIn: "7d"})

        res.cookie("token", token, {httpOnly: true});

        res.status(200).json({access:token, refresh: token})

    }catch(e){
        next(e)
    }
}

export const logout = async (req: Request, res: Response) =>{
    try{
        // clear cookie from user seystem
        res.clearCookie('token');
        
        // response to determine logout was successful
        res.json('Logged out Successful')
    }
    catch(err){
        res.status(400).send('Error Logging out');
    }
}