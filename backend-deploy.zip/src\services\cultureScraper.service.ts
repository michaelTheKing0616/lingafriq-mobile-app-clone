import CultureArticle from '../models/cultureMagazine.model.js';

/**
 * Culture Content Scraper Service
 * 
 * This service provides a framework for scraping African cultural content.
 * Due to legal and ethical considerations, this is a TEMPLATE that should be adapted
 * to work with:
 * 1. Open APIs (Wikipedia, Wikimedia Commons, News APIs)
 * 2. RSS feeds from African news sites with proper attribution
 * 3. Content with explicit permission/licensing
 * 
 * IMPORTANT: Always respect robots.txt, rate limits, and copyright laws.
 * Add proper source attribution for all scraped content.
 */

interface ScrapedArticle {
  title: string;
  content: string;
  excerpt: string;
  category: string;
  country: string;
  region?: string;
  language?: string;
  featured_image?: string;
  images?: string[];
  source_url: string;
  source_name: string;
  tags: string[];
}

export class CultureScraperService {
  // Wikipedia API - Completely legal and open
  async scrapeWikipediaArticles(topics: string[]) {
    const articles: ScrapedArticle[] = [];

    for (const topic of topics) {
      try {
        // Wikipedia REST API
        const response = await fetch(
          `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(topic)}`
        );

        if (!response.ok) continue;

        const data = await response.json();

        articles.push({
          title: data.title,
          content: data.extract,
          excerpt: data.extract.substring(0, 300),
          category: this.categorizeContent(data.extract),
          country: this.extractCountry(topic),
          featured_image: data.thumbnail?.source,
          images: data.thumbnail ? [data.thumbnail.source] : [],
          source_url: data.content_urls.desktop.page,
          source_name: 'Wikipedia',
          tags: this.extractTags(data.extract),
        });
      } catch (error) {
        console.error(`Error scraping ${topic}:`, error);
      }
    }

    return articles;
  }

  // News API for African news (requires API key)
  async scrapeAfricanNews(apiKey: string, category: string) {
    const articles: ScrapedArticle[] = [];
    
    // Example: Using NewsAPI (requires registration)
    const africanCountries = ['ng', 'za', 'ke', 'gh', 'et', 'tz'];
    
    for (const country of africanCountries) {
      try {
        const response = await fetch(
          `https://newsapi.org/v2/top-headlines?country=${country}&category=${category}&apiKey=${apiKey}`
        );

        if (!response.ok) continue;

        const data = await response.json();

        for (const article of data.articles || []) {
          articles.push({
            title: article.title,
            content: article.description || article.content || '',
            excerpt: (article.description || '').substring(0, 300),
            category: category,
            country: this.getCountryName(country),
            featured_image: article.urlToImage,
            images: article.urlToImage ? [article.urlToImage] : [],
            source_url: article.url,
            source_name: article.source.name,
            tags: this.extractTags(article.title + ' ' + article.description),
          });
        }
      } catch (error) {
        console.error(`Error scraping news for ${country}:`, error);
      }
    }

    return articles;
  }

  // Save articles to database
  async saveArticles(articles: ScrapedArticle[]) {
    const saved = [];
    
    for (const article of articles) {
      try {
        // Check if article already exists
        const existing = await CultureArticle.findOne({ title: article.title });
        
        if (!existing) {
          const newArticle = new CultureArticle({
            ...article,
            published: false, // Require manual review before publishing
            featured: false,
            author: 'LingAfriq Editorial Team',
          });
          
          await newArticle.save();
          saved.push(newArticle);
        }
      } catch (error) {
        console.error(`Error saving article "${article.title}":`, error);
      }
    }

    return saved;
  }

  // Utility: Categorize content based on keywords
  private categorizeContent(text: string): string {
    const keywords = {
      tradition: ['tradition', 'custom', 'ritual', 'ceremony', 'cultural practice'],
      cuisine: ['food', 'cuisine', 'dish', 'recipe', 'cooking'],
      music: ['music', 'song', 'dance', 'instrument', 'rhythm'],
      history: ['history', 'historical', 'ancient', 'colonial', 'independence'],
      language: ['language', 'dialect', 'linguistic', 'speak', 'translation'],
      festivals: ['festival', 'celebration', 'holiday', 'event', 'carnival'],
      art: ['art', 'painting', 'sculpture', 'craft', 'artist'],
      literature: ['literature', 'book', 'story', 'poetry', 'author', 'novel'],
    };

    const lowerText = text.toLowerCase();
    
    for (const [category, terms] of Object.entries(keywords)) {
      if (terms.some(term => lowerText.includes(term))) {
        return category;
      }
    }

    return 'tradition';
  }

  // Utility: Extract country from topic
  private extractCountry(topic: string): string {
    const countryMap: Record<string, string> = {
      'nigeria': 'Nigeria',
      'south africa': 'South Africa',
      'kenya': 'Kenya',
      'ghana': 'Ghana',
      'ethiopia': 'Ethiopia',
      'tanzania': 'Tanzania',
      'uganda': 'Uganda',
      'egypt': 'Egypt',
      'morocco': 'Morocco',
      'senegal': 'Senegal',
    };

    const lowerTopic = topic.toLowerCase();
    
    for (const [key, value] of Object.entries(countryMap)) {
      if (lowerTopic.includes(key)) {
        return value;
      }
    }

    return 'Africa';
  }

  // Utility: Extract relevant tags
  private extractTags(text: string): string[] {
    const commonWords = new Set(['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for']);
    const words = text.toLowerCase().split(/\W+/);
    const tags = new Set<string>();

    for (const word of words) {
      if (word.length > 3 && !commonWords.has(word)) {
        tags.add(word);
      }
    }

    return Array.from(tags).slice(0, 10);
  }

  // Utility: Get full country name from code
  private getCountryName(code: string): string {
    const codeMap: Record<string, string> = {
      'ng': 'Nigeria',
      'za': 'South Africa',
      'ke': 'Kenya',
      'gh': 'Ghana',
      'et': 'Ethiopia',
      'tz': 'Tanzania',
    };

    return codeMap[code] || 'Africa';
  }

  // Predefined topics to scrape from Wikipedia  
  async scrapeDefaultTopics() {
    const topics = [
      // Nigerian culture
      'Yoruba_people', 'Igbo_people', 'Hausa_people', 'Nigerian_cuisine',
      'Nollywood', 'Afrobeat', 'Jollof_rice',
      
      // South African culture
      'Zulu_people', 'Xhosa_people', 'South_African_cuisine', 'Kwaito',
      'Ubuntu_(philosophy)', 'Braai',
      
      // Kenyan culture
      'Swahili_culture', 'Maasai_people', 'Kenyan_cuisine', 'Benga_music',
      
      // Ghanaian culture
      'Ashanti_people', 'Ghanaian_cuisine', 'Highlife', 'Kente_cloth',
      
      // Ethiopian culture
      'Ethiopian_cuisine', 'Ethiopian_Orthodox', 'Ge\'ez', 'Coffee_ceremony',
      
      // Pan-African
      'African_art', 'African_literature', 'Pan-Africanism', 'Kwanzaa',
    ];

    const articles = await this.scrapeWikipediaArticles(topics);
    return articles; // Return scraped articles without saving (for API client)
  }

  // Scrape and save to database directly (for local use)
  async scrapeAndSaveDefaultTopics() {
    const articles = await this.scrapeDefaultTopics();
    return await this.saveArticles(articles);
  }
}

// Cron job function (call this periodically)
export const runScraperJob = async () => {
  console.log('Starting culture content scraper...');
  
  // Connect to MongoDB if not already connected
  const mongoose = await import('mongoose');
  if (mongoose.default.connection.readyState === 0) {
    const mongoUri = process.env.MONGODB_URI;
    if (!mongoUri) {
      throw new Error('MONGODB_URI environment variable is not set');
    }
    console.log('Connecting to MongoDB...');
    await mongoose.default.connect(mongoUri);
    console.log('✓ Connected to MongoDB');
  } else {
    console.log('✓ Already connected to MongoDB');
  }
  
  const scraper = new CultureScraperService();
  
  try {
    const articles = await scraper.scrapeAndSaveDefaultTopics();
    console.log(`✓ Scraped and saved ${articles.length} new articles`);
    
    // Optionally scrape news (requires API key from env)
    if (process.env.NEWS_API_KEY) {
      const newsArticles = await scraper.scrapeAfricanNews(
        process.env.NEWS_API_KEY,
        'culture'
      );
      const savedNews = await scraper.saveArticles(newsArticles);
      console.log(`✓ Scraped and saved ${savedNews.length} news articles`);
    }
  } catch (error) {
    console.error('✗ Scraper job failed:', error);
  }
  
  console.log('Culture content scraper completed.');
};

