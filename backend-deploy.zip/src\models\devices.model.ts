import mongoose, { Document, PaginateModel } from "mongoose";
export interface IDevice {
    name: string;
    active: boolean;
    date_created: Date;
    device_id: string;
    registration_id: string;
    type: string;
    user_id: number;
}

interface IDeviceDocument extends IDevice, Document {}

const deviceSchema = new mongoose.Schema<IDeviceDocument>({
    name: {
        type: String,
        default: null
    },
    active: {
        type: Boolean,
        default: true
    },
    date_created: {
        type: Date,
        default: new Date()
    },
    device_id: {
        type: String,
        default: null,
        index: true
    },
    registration_id: {
        type: String,
        required: true,
        unique: true,
        index: true
    },
    type: {
        type: String,
        required: true
    },
    user_id: {
        type: Number,
        required: true,
        index: true
    }
}, {timestamps: true})

const DeviceModel = mongoose.model<IDeviceDocument>("device", deviceSchema);
export default DeviceModel;