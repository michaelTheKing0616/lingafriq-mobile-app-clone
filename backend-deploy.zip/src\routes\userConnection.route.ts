import express from 'express';
import * as connectionController from '../controllers/userConnection.controller.js';
import { protect } from '../middleware/auth.middleware.js';

const router = express.Router();

// All routes require authentication
router.use(protect);

router.post('/request', connectionController.sendConnectionRequest);
router.post('/:connectionId/accept', connectionController.acceptConnectionRequest);
router.delete('/:connectionId', connectionController.rejectConnection);
router.get('/', connectionController.getConnections);
router.get('/pending', connectionController.getPendingRequests);
router.get('/search', connectionController.searchUsers);

export default router;

