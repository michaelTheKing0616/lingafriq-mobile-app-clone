import mongoose, { Document, Schema } from 'mongoose';
import mongoosePaginate from 'mongoose-paginate-v2';

export interface IMedia extends Document {
  user_id: mongoose.Types.ObjectId;
  title: string;
  description?: string;
  file_type: 'audio' | 'video' | 'image';
  original_filename: string;
  file_url: string;
  file_size: number;
  duration?: number; // in seconds for audio/video
  language?: string;
  transcription?: string;
  translation?: string;
  processing_status: 'pending' | 'processing' | 'completed' | 'failed';
  processing_error?: string;
  metadata?: {
    format?: string;
    codec?: string;
    bitrate?: number;
    dimensions?: { width: number; height: number };
  };
  created_at: Date;
  updated_at: Date;
}

const mediaSchema = new Schema<IMedia>({
  user_id: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  title: { type: String, required: true },
  description: { type: String },
  file_type: { type: String, required: true, enum: ['audio', 'video', 'image'] },
  original_filename: { type: String, required: true },
  file_url: { type: String, required: true },
  file_size: { type: Number, required: true },
  duration: { type: Number },
  language: { type: String },
  transcription: { type: String },
  translation: { type: String },
  processing_status: { 
    type: String, 
    default: 'pending', 
    enum: ['pending', 'processing', 'completed', 'failed'] 
  },
  processing_error: { type: String },
  metadata: {
    format: { type: String },
    codec: { type: String },
    bitrate: { type: Number },
    dimensions: {
      width: { type: Number },
      height: { type: Number }
    }
  },
  created_at: { type: Date, default: Date.now },
  updated_at: { type: Date, default: Date.now }
});

mediaSchema.plugin(mongoosePaginate);

mediaSchema.pre('save', function(next) {
  this.updated_at = new Date();
  next();
});

const Media = mongoose.model<IMedia>('Media', mediaSchema);
export default Media as any; // Type assertion for paginate plugin

