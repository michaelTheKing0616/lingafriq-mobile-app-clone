import { Server as HttpServer } from 'http';
import { Server as SocketServer, Socket } from 'socket.io';
import ChatMessage from '../models/chatMessage.model.js';

type OnlineUser = {
  socketId: string;
  userId: string;
  username: string;
};

const onlineUsers = new Map<string, OnlineUser>();

const allowedOrigins = [
  'https://lingafriq.com',
  'https://www.lingafriq.com',
  'https://lingafriq-admin.web.app',
  'http://localhost:5500',
  'http://localhost:3000',
];

export const initSocketServer = (server: HttpServer) => {
  const io = new SocketServer(server, {
    cors: {
      origin: allowedOrigins,
      credentials: true,
    },
  });

  io.on('connection', (socket: Socket) => {
    const headerUserId = socket.handshake.headers['userid'];
    const headerUsername = socket.handshake.headers['username'];
    const userId = normalizeHeader(headerUserId);
    const username = normalizeHeader(headerUsername) ?? 'Learner';

    if (userId) {
      onlineUsers.set(socket.id, {
        socketId: socket.id,
        userId,
        username,
      });
      broadcastOnlineUsers(io);
    }

    socket.on('user_connected', (payload) => {
      if (!payload || typeof payload !== 'object') return;
      const incomingId = payload.userId?.toString();
      const incomingName = payload.username?.toString() ?? username;
      if (incomingId) {
        onlineUsers.set(socket.id, {
          socketId: socket.id,
          userId: incomingId,
          username: incomingName,
        });
        broadcastOnlineUsers(io);
      }
    });

    socket.on('join_room', (data) => {
      const room = data?.room?.toString();
      if (room) {
        socket.join(room);
      }
    });

    socket.on('leave_room', (data) => {
      const room = data?.room?.toString();
      if (room) {
        socket.leave(room);
      }
    });

    socket.on('send_message', async (payload) => {
      if (!payload || typeof payload !== 'object') return;
      const room = payload.room?.toString();
      const message = payload.message?.toString();
      if (!room || !message) return;
      const timestamp =
          payload.timestamp?.toString() ?? new Date().toISOString();
      const userIdPayload = payload.userId?.toString() ?? userId ?? '0';
      const usernamePayload = payload.username?.toString() ?? username;
      const recipientId = payload.recipientId?.toString();
      const messageType = payload.messageType?.toString() ?? 'text';
      const chatType = payload.chatType?.toString() ?? 'global';

      // Save message to database
      try {
        const chatMessage = new ChatMessage({
          room_id: room,
          chat_type: chatType,
          sender_id: userIdPayload,
          sender_username: usernamePayload,
          recipient_id: recipientId,
          message,
          message_type: messageType,
          timestamp: new Date(timestamp),
        });
        
        await chatMessage.save();
        
        // Emit message with database ID
        io.to(room).emit('new_message', {
          id: chatMessage._id,
          room,
          message,
          userId: userIdPayload,
          username: usernamePayload,
          timestamp,
          messageType,
        });
      } catch (error) {
        console.error('Error saving chat message:', error);
        // Still emit the message even if database save fails
        io.to(room).emit('new_message', {
          room,
          message,
          userId: userIdPayload,
          username: usernamePayload,
          timestamp,
          messageType,
        });
      }
    });

    socket.on('disconnect', () => {
      onlineUsers.delete(socket.id);
      broadcastOnlineUsers(io);
    });
  });

  return io;
};

const broadcastOnlineUsers = (io: SocketServer) => {
  const users = Array.from(onlineUsers.values()).map((user) => ({
    userId: user.userId,
    username: user.username,
    isOnline: true,
  }));
  io.emit('online_users', users);
};

const normalizeHeader = (value: string | string[] | undefined) => {
  if (!value) return undefined;
  if (Array.isArray(value)) return value[0];
  return value.toString();
};

