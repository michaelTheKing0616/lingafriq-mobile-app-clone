import { Express, Request, Response } from "express";
import swaggerJSDoc from "swagger-jsdoc";
import swaggerUi from "swagger-ui-express";

const options: swaggerJSDoc.Options = {
    definition:{
        failOnErrors: true,
        openapi:"3.0.0",
        info:{
            title:"LingAfriq API docs",
            version: "1.1.0"
        },
        components:{
            securitySchemas:{
                bearerAuth:{
                    type: "http",
                    scheme: "bearer",
                    bearerFormat: "JWT",
                }
            }
        }, 
        security :[
            {
                bearerAuth:[]
            }
        ],
        basePath: "/",
    },
    
    apis:["./src/routes/*.route.ts"]
}

const swaggerSpec = swaggerJSDoc(options)

function swaggerDocs(app: Express, port:number){
    app.use('/docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));

    app.get("/docs.json", (req: Request, res:Response)=>{
        res.setHeader("Content-type", "application/json");
        res.send(swaggerSpec)
    })
}

export default swaggerDocs