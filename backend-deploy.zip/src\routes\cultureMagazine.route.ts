import express from 'express';
import * as magazineController from '../controllers/cultureMagazine.controller.js';
import { protect } from '../middleware/auth.middleware.js';

const router = express.Router();

// Public routes
router.get('/articles', magazineController.getArticles);
router.get('/articles/featured', magazineController.getFeaturedArticles);
router.get('/articles/:slug', magazineController.getArticleBySlug);
router.get('/categories', magazineController.getCategories);

// Protected routes
router.post('/articles/:id/like', protect, magazineController.likeArticle);

// Admin routes (add admin middleware)
router.post('/articles', protect, magazineController.createArticle);
router.put('/articles/:id', protect, magazineController.updateArticle);
router.delete('/articles/:id', protect, magazineController.deleteArticle);

export default router;

