import LoadingScreenContentModel from '../models/loadingScreenContent.model.js';
import { Response, NextFunction } from "express";
import { AuthenticatedRequest } from '../types/request.js';
import UserModel from '../models/user.model.js';
import { AuthenticationError } from '../utils/error.js';

/**
 * Get random loading screen content
 * Excludes recently viewed content for the user
 */
export const getRandomContent = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const user = await UserModel.findById(req.userId);
    if (!user) throw new AuthenticationError("User not found");

    // Get user's viewed loading screen content IDs
    const viewedIds = (user as any).viewedLoadingContent || [];
    const lastViewedId = (user as any).lastLoadingContentId;

    // Find all published content, excluding recently viewed
    const availableContent = await LoadingScreenContentModel.find({
      isPublished: true,
      id: { $nin: [...viewedIds, lastViewedId].filter(Boolean) }
    });

    // If all content has been viewed, reset and show all
    let contentToChooseFrom = availableContent;
    if (availableContent.length === 0) {
      contentToChooseFrom = await LoadingScreenContentModel.find({ isPublished: true });
      // Reset user's viewed list
      await UserModel.findByIdAndUpdate(req.userId, {
        $set: { viewedLoadingContent: [] }
      });
    }

    // Randomly select one
    const randomIndex = Math.floor(Math.random() * contentToChooseFrom.length);
    const selectedContent = contentToChooseFrom[randomIndex];

    if (!selectedContent) {
      return res.status(404).json({ error: "No loading screen content available" });
    }

    // Update user's viewed content
    const updatedViewed = [...viewedIds, selectedContent.id].filter(Boolean);
    // Keep only last 5 viewed
    const trimmedViewed = updatedViewed.slice(-5);

    await UserModel.findByIdAndUpdate(req.userId, {
      $set: {
        lastLoadingContentId: selectedContent.id,
        viewedLoadingContent: trimmedViewed
      }
    });

    // Return content with full image URL
    const contentData = {
      id: selectedContent.id,
      country: selectedContent.country,
      countryFlag: selectedContent.countryFlag,
      greeting: selectedContent.greeting,
      greetingTranslation: selectedContent.greetingTranslation,
      language: selectedContent.language,
      fact: selectedContent.fact,
      imageUrl: selectedContent.imageUrl || (selectedContent as any).fullImageUrl || null,
    };

    res.json({ result: contentData });
  } catch (e) {
    next(e);
  }
};

/**
 * Get content by country
 */
export const getContentByCountry = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const { country } = req.params;
    const content = await LoadingScreenContentModel.find({
      country: country,
      isPublished: true
    });

    const contentData = content.map(item => ({
      id: item.id,
      country: item.country,
      countryFlag: item.countryFlag,
      greeting: item.greeting,
      greetingTranslation: item.greetingTranslation,
      language: item.language,
      fact: item.fact,
      imageUrl: item.imageUrl || (item as any).fullImageUrl || null,
    }));

    res.json({ result: contentData });
  } catch (e) {
    next(e);
  }
};

/**
 * Get content by language
 */
export const getContentByLanguage = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const { language } = req.params;
    const content = await LoadingScreenContentModel.find({
      language: language,
      isPublished: true
    });

    const contentData = content.map(item => ({
      id: item.id,
      country: item.country,
      countryFlag: item.countryFlag,
      greeting: item.greeting,
      greetingTranslation: item.greetingTranslation,
      language: item.language,
      fact: item.fact,
      imageUrl: item.imageUrl || (item as any).fullImageUrl || null,
    }));

    res.json({ result: contentData });
  } catch (e) {
    next(e);
  }
};

/**
 * Get all content (admin only)
 */
export const getAllContent = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const limit = 50;
    let page = 1;

    if (typeof req.query.page === "string") page = parseInt(req.query.page);
    if (Array.isArray(req.query.page) && typeof req.query.page[0] === "string") {
      page = parseInt(req.query.page[0]);
    }

    const fullUrl = process.env.HOSTNAME;

    await LoadingScreenContentModel.paginate(
      {},
      { page, limit, sort: { createdAt: -1 } }
    ).then((result) => {
      const count = result.totalDocs;
      const next = result.hasNextPage ? `${fullUrl}/api/loading-screen?page=${page + 1}` : null;
      const previous = result.hasPrevPage ? `${fullUrl}/api/loading-screen?page=${page - 1}` : null;

      const results = result.docs.map(doc => ({
        id: doc.id,
        country: doc.country,
        countryFlag: doc.countryFlag,
        greeting: doc.greeting,
        greetingTranslation: doc.greetingTranslation,
        language: doc.language,
        fact: doc.fact,
        imageUrl: doc.imageUrl || (doc as any).fullImageUrl || null,
        isPublished: doc.isPublished,
        isFeatured: doc.isFeatured,
        createdAt: doc.createdAt,
        updatedAt: doc.updatedAt,
      }));

      res.json({ result: { count, next, previous, results } });
    });
  } catch (e) {
    next(e);
  }
};

