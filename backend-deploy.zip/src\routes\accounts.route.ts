import express, { Request, Response } from "express";
import { getIdFromJWT, requireSignin } from "../middleware/auth.middleware.js";
import {
  getProfileInfo,
  getUserDetails,
  updateUserDetails,
  resetUserPassword,
  changeUserPassword,
  deleteUserAccount,
  getAllUsersRanked,
  updateUsers,
  handleResetPassword,
  deleteUserViaCredentials,
} from "../controllers/accounts.controller.js";
import { login, register } from "../controllers/auth.controller.js";

const router = express.Router();

/**
 * @openapi
 * /auth/users/me:
 *   get:
 *     summary: Get user data from logged in user
 *     tags:
 *       - Accounts
 *     responses:
 *       '200':
 *         description: OK
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: integer
 *                 email:
 *                   type: string
 *                   format: email
 *                 username:
 *                   type: string
 *                 first_name:
 *                   type: string
 *                 last_name:
 *                   type: string
 *                 nationality:
 *                   type: string
 *                 agree_to_privacy_terms:
 *                   type: boolean
 *                 avatar:
 *                   type: string
 *                   format: url
 *                 ranks:
 *                   type: number
 *                 points:
 *                   type: number
 *                 level:
 *                   type: number
 */
router.get("/auth/users/me", requireSignin, getIdFromJWT, getUserDetails);

router.put("/auth/users/me", requireSignin, getIdFromJWT, updateUserDetails);

router.post("/auth/users/reset_password/", resetUserPassword);

router.post("/auth/reset_password/handle_reset", handleResetPassword);

router.post("/auth/users/set_password/", requireSignin, getIdFromJWT, changeUserPassword);

router.delete("/user_delete/:userId", requireSignin, getIdFromJWT, deleteUserAccount);

// POST alias for clients that can't send DELETE with body
router.post("/user_delete", requireSignin, getIdFromJWT, deleteUserAccount);

router.get("/my_user_profile/", requireSignin, getIdFromJWT, getProfileInfo);

router.get("/all_users", requireSignin, getIdFromJWT, getAllUsersRanked);

router.get("/update_users", requireSignin, getIdFromJWT, updateUsers);

router.get("/update", requireSignin, getIdFromJWT, (req: Request, res: Response) =>
  res.status(200).send({ ok: true })
);

/**
 * @openapi
 * /accounts/auth/users:
 *   post:
 *     summary: Create a new user and returns ok if everything is ok
 *     tags:
 *       - Accounts
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               email:
 *                 type: string
 *               password:
 *                 type: string
 *               username:
 *                  type: string
 *               first_name:
 *                  type: string
 *               last_name:
 *                  type: string
 *               nationality:
 *                  type: string
 *               agree_to_privacy_terms:
 *                  type: boolean
 *               ranks: 
 *                  type: string
 *               level:
 *                  type: string
 *               avater:
 *                  type: string
 *               points:
 *                  type: number
 *               image_url:
 *                  type: string
 *     responses:
 *       '201':
 *         description: OK
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                  ok:
 *                      type: boolean
 */
router.post("/auth/users/", register);

/**
 * @openapi
 * /accounts/create/jwt:
 *   post:
 *     summary: Login the user and sends back a cookie along with a refresh and access token
 *     tags:
 *       - Accounts
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               email:
 *                 type: string
 *                 description: The first argument.
 *               password:
 *                 type: string
 *                 description: The second argument.
 *     responses:
 *       '200':
 *         description: OK
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 access:
 *                   type: string
 *                   description: The access token.
 *                 refresh:
 *                   type: string
 *                   description: The refresh token.
 *         headers:
 *           Set-Cookie:
 *             description: Cookie containing access and refresh tokens.
 *             schema:
 *               type: string
 */
router.post("/auth/jwt/create", login);

/**
 * @openapi
 * /accounts/auth/users/delete_via_credentials:
 *   post:
 *     summary: Delete account by verifying email + password (no JWT required)
 *     tags:
 *       - Accounts
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               email:
 *                 type: string
 *               password:
 *                 type: string
 *     responses:
 *       '200':
 *         description: Account deleted successfully
 */
router.post("/auth/users/delete_via_credentials", deleteUserViaCredentials);

export default router;
