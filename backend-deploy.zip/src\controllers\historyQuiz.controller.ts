import { Response, NextFunction } from "express";
import { AuthenticatedRequest } from '../types/request.js';
import HistoryQuizModel from '../models/historyQuiz.model.js';
import UserModel from "../models/user.model.js";
import { ValidationError } from "../utils/error.js";
import _ from "lodash";

export const getAllHistoryQuiz = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try{
        const page = 1;
        const limit = 50;

        const fullUrl = process.env.HOSTNAME;

        HistoryQuizModel.paginate({}, {page, limit}).then((result)=>{
            let total_score = 0;
            const count = result.totalDocs;
            const next = result.hasNextPage ? `${fullUrl}?page=${page + 1}` : null;
            const previous = result.hasPrevPage ? `${fullUrl}?page=${page - 1}` : null;
            const results = result.docs;
            const data = results.map(result=>{

                const count = result.quiz_sections.length;
                let completed = 0;
                let score = 0;

                result.quiz_sections.forEach((section)=>{
                    score = score + section.score;
                    total_score = total_score + section.score;
                })

                return {count, completed, score, language: result.language_id, id:result.id, congrats: result.congrats, name: result.name}
            })
            res.status(200).json({ total_score, result: {count, next, previous, results:data }});
        })
        
    } catch (e){
        next(e)
    }
}

export const getHistoryQuizSections = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try{
        const lessonId = Number(req.params.lessonId);
        const sectionId = Number(req.params.sectionId);

        if (typeof lessonId !== "number" || typeof sectionId !== "number" ) throw new ValidationError("Id should be a number");

        const lesson = await HistoryQuizModel.findOne({id: lessonId});
        
        const quizSection = lesson.quiz_sections.find(section=>section.id === sectionId);

        if(quizSection === undefined) return res.status(200).json([])

        const quiz = [{
            ..._.pick(quizSection, ["id", "quiz", "quiz_type", "score", "date_time"]),
            completed_by: req.userId,
            quiz_section: quizSection.quiz_section_id
        }]

        const questionArray = [];

        quizSection.questions.forEach(questionItem=>{
            const choices = questionItem.options;
            const question = {
                ..._.pick(questionItem, ["id", "question", "text", "image", "audio", "video", "add_hint", "fun_fact", "is_published", "types",]),
                lesson_section: questionItem.quiz_section_id
            }
            questionArray.push({question, choices});
        })
            
        return res.status(200).json([{quiz, question: questionArray}])
    } catch (e){
        next(e)
    }
}

export const getAllHistoryQuizSection =  async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try{
        const lessonId = Number(req.params.lessonId);

        if (typeof lessonId !== "number" ) throw new ValidationError("Id should be a number");

        const user = await UserModel.findById(req.userId);
        const lesson = await HistoryQuizModel.findOne({id: lessonId});
        
        const quizSection = lesson.quiz_sections[0];

        const completed = user.history_quiz.quiz_sections.includes(quizSection.id);

        if(quizSection === undefined) return res.status(200).json([])

        const quiz = [{
            ..._.pick(quizSection, ["id", "quiz", "quiz_type", "score", "date_time"]),
            completed_by: completed ? user.id : null,
            quiz_section: quizSection.quiz_section_id
        }]

        const questionArray = [];

        quizSection.questions.forEach(questionItem=>{
            const choices = questionItem.options.map(item=>{
                return {..._.pick(item, ["id", "text", "image", "correct_answer"]), quiz_question: item.quiz_question_id}
            })
            const question = {
                ..._.pick(questionItem, ["id", "question", "text", "image", "audio", "video", "add_hint", "fun_fact", "is_published"]),
                types: "Instant Question",
                lesson_section: questionItem.quiz_section_id
            }
            questionArray.push({question, choices});
        })
            
        return res.status(200).json([{quiz, question: questionArray}])
    } catch (e){
        next(e)
    }
}

export const markHistoryQuizQuestionAsCompleted = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try{
        const { sectionId, questionId } = req.params;

        if(!questionId || !sectionId) throw new ValidationError("language Id and question Id should be provided")

        const lesson_section = await HistoryQuizModel.findOne({id: sectionId});
        const lesson = lesson_section.quiz_sections.find(item=> item.id === Number(sectionId));
        
        if(!lesson) throw new Error("Document not Found")

        const currentUser = await UserModel.findById(req.userId);

        let msg;

        if(!currentUser.history_quiz.quiz_sections.includes(Number(questionId))){
            currentUser.points = currentUser.points + lesson.score;
            currentUser.history_quiz.quiz_sections.push(Number(questionId))
            await currentUser.save();
            msg = "Lesson Completed Successfully"
        }
        else msg = "You have already completed this Lesson!"

        res.status(200).json({msg})

    } catch(e){
        next(e)
    }
}
