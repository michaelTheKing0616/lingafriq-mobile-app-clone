import mongoose from "mongoose";
import supertest from "supertest";
import app from "../app.js";
import UserModel, { IUser, UserDocument } from "../models/user.model.js";

const request = supertest(app);

const formData = {
    email: "JoeBizzy@gmail.com",
    password: "Saturn92.",
    nationality: "Nigerian",
    level: "Beginner",
    first_name: "Joe",
    last_name: "Bunzz",
    username: "Joebizzy",
    avater: "mock-avatar.png"
}

describe("Test the tests",()=>{

    beforeAll(async ()=>{
        try{
            await mongoose.connect("mongodb://127.0.0.1:27017/lingafriq")
        } catch(e){
            console.log(e)
        }
    })

    let cookie;
    let user: UserDocument;

    it("Check if app is responding", async()=>{
        const response = await request.get("/healthcheck");
        expect(response.statusCode).toBe(200);
    });

    it("Register New User", async ()=>{
        const response = await request.post("/accounts/auth/users/").send({...formData})
        expect(response.statusCode).toBe(201);
        user = await UserModel.findOne({email: formData.email});
        expect(user).toBeDefined();
        expect(user.email).toBe("joebizzy@gmail.com");
    })

    it("Login user", async ()=>{
        const response = await request.post("/accounts/auth/jwt/create").send({email: "joebizzy@gmail.com ", password: formData.password});
        expect(response.statusCode).toBe(200);
        expect(response.body.access).toBeTruthy();
        expect(typeof response.body.access).toBe("string");
        cookie = response.headers['set-cookie'];
        expect(cookie).toBeTruthy();
    })

    it("Check User", async ()=>{
        const user = await UserModel.findOne({email: formData.email});  
        console.log(user)
        expect(user._id).toBeTruthy()
    })

    it("Get All Languages", async()=>{
        const response = await request.get("/language").set("Cookie", cookie)
        expect(response.statusCode).toBe(200);
    })

    it("Delete Account After all tests are run", async()=>{
        const response = await request.delete(`/accounts/user_delete/${user._id}`).set("Cookie", cookie).send({current_password: formData.password})
        expect(response.statusCode).toBe(204);
        const res = await UserModel.findOne({email: formData.email});
        expect(res).toBeNull();
    })

    afterAll(async ()=>{
        await mongoose.disconnect()
    })
})