import { Schema, Document, model } from 'mongoose';
import { Lesson, LessonSchema } from './schemas/lesson.js';
import mongoosePaginate from "mongoose-paginate-v2";
import { PaginateModel } from 'mongoose';
import { getUniqueId } from '../utils/random.js';

export interface Mannerism {
  congrats: string
  id: number;
  language_id: number
  name: string;
  lessons: Lesson []
}

export type MannerismDocument = Mannerism & Document

const mannerismSchema = new Schema<MannerismDocument>({
  congrats: { type: String },
  id: { type: Number, required: true, index: true },
  name: { type: String, required: true },
  language_id: {type: Number, required: true, default: getUniqueId(), index: true},
  lessons: {
    type: [LessonSchema],
    default:[]
  },
});

mannerismSchema.plugin(mongoosePaginate)

const MannerismModel = model<MannerismDocument, PaginateModel<MannerismDocument>>("mannerism", mannerismSchema, 'mannerism')

export default MannerismModel;
