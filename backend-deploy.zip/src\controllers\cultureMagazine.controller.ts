import { Request, Response, NextFunction } from 'express';
import CultureArticle from '../models/cultureMagazine.model.js';
import { PaginateResult } from 'mongoose';

// Get all articles with pagination and filters
export const getArticles = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { 
      page = 1, 
      limit = 10, 
      category, 
      country, 
      featured, 
      search 
    } = req.query;

    const query: any = { published: true };
    
    if (category) query.category = category;
    if (country) query.country = country;
    if (featured) query.featured = featured === 'true';
    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { content: { $regex: search, $options: 'i' } },
        { tags: { $in: [new RegExp(search as string, 'i')] } }
      ];
    }

    const options = {
      page: Number(page),
      limit: Number(limit),
      sort: { published_date: -1 },
      select: '-__v'
    };

    const articles = await CultureArticle.paginate(query, options);
    
    res.json({
      success: true,
      data: articles
    });
  } catch (error) {
    next(error);
  }
};

// Get single article by slug
export const getArticleBySlug = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { slug } = req.params;
    
    const article = await CultureArticle.findOne({ slug, published: true });
    
    if (!article) {
      return res.status(404).json({
        success: false,
        message: 'Article not found'
      });
    }

    // Increment views
    article.views += 1;
    await article.save();

    res.json({
      success: true,
      data: article
    });
  } catch (error) {
    next(error);
  }
};

// Get featured articles
export const getFeaturedArticles = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { limit = 5 } = req.query;

    const articles = await CultureArticle.find({ published: true, featured: true })
      .sort({ published_date: -1 })
      .limit(Number(limit))
      .select('-__v');

    res.json({
      success: true,
      data: articles
    });
  } catch (error) {
    next(error);
  }
};

// Like article
export const likeArticle = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;

    const article = await CultureArticle.findById(id);
    
    if (!article) {
      return res.status(404).json({
        success: false,
        message: 'Article not found'
      });
    }

    article.likes += 1;
    await article.save();

    res.json({
      success: true,
      data: { likes: article.likes }
    });
  } catch (error) {
    next(error);
  }
};

// Get categories
export const getCategories = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const categories = await CultureArticle.distinct('category', { published: true });
    
    const categoriesWithCounts = await Promise.all(
      categories.map(async (category) => ({
        name: category,
        count: await CultureArticle.countDocuments({ category, published: true })
      }))
    );

    res.json({
      success: true,
      data: categoriesWithCounts
    });
  } catch (error) {
    next(error);
  }
};

// Admin: Create article
export const createArticle = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const article = new CultureArticle(req.body);
    await article.save();

    res.status(201).json({
      success: true,
      data: article
    });
  } catch (error) {
    next(error);
  }
};

// Admin: Update article
export const updateArticle = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;
    
    const article = await CultureArticle.findByIdAndUpdate(
      id,
      { ...req.body, updated_at: new Date() },
      { new: true, runValidators: true }
    );

    if (!article) {
      return res.status(404).json({
        success: false,
        message: 'Article not found'
      });
    }

    res.json({
      success: true,
      data: article
    });
  } catch (error) {
    next(error);
  }
};

// Admin: Delete article
export const deleteArticle = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;
    
    const article = await CultureArticle.findByIdAndDelete(id);

    if (!article) {
      return res.status(404).json({
        success: false,
        message: 'Article not found'
      });
    }

    res.json({
      success: true,
      message: 'Article deleted successfully'
    });
  } catch (error) {
    next(error);
  }
};

