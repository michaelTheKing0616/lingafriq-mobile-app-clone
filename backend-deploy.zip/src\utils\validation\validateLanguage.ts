import { ValidationError } from "../error.js";

export interface LanguageData {
    Introduction: string;
    background: string;
    is_featured: "true" | "false";
    is_published: "true" | "false";
    name: string;
}

export const validateLanguage = (lang: LanguageData) => {
    if(typeof lang.Introduction !== "string" || lang.Introduction.length < 1){
        throw new ValidationError("Introduction should be a string and is required")
    }
    if(typeof lang.name !== "string" || lang.name.length < 1){
        throw new ValidationError("Introduction should be a string and is required")
    }
}