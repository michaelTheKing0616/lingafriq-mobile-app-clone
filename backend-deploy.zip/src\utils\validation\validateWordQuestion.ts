import Joi from "joi";

export const validateWordQuestion = (formData: any) => {
    return Joi.object({
        id: Joi.number().unsafe(), 
        content: Joi.string().allow(null, "").default(null),
        add_hint: Joi.string().allow(null, ""),
        is_published: Joi.boolean().default(true),
        question: Joi.string().required(),
        quiz_section_id: Joi.number().unsafe(),
        text: Joi.string(),
        types: Joi.string().default("Word Question")
    }).validate(formData, {allowUnknown: true, stripUnknown: true})
}

const type = {
    "content": "WSQ",
    "add_hint": null,
    "id": 3,
    "is_published": true,
    "question": "WSQ1",
    "quiz_section_id": 11,
    "text": "Replace the English words in brackets with their correct Pidgin interpretations.  \r\n\r\n\r\nJohnny! \r\n\r\nOh hi, Amaka! [ How far?/How’s it going?]  I was just on my way to your house. \r\n\r\nReally? [ Wetin dey sup?/What’s up? ] \r\n\r\nNothing much. I just realised that I had been so preoccupied with work that I had not come by to say hello in weeks. [No vex/I’m sorry'] about that. \r\n\r\nAh ahn. Johnny? Na you be dis? You’ve never been this nice to me before! \r\n\r\n😂[Ehn ehn/No] Amaka you know that’s not true. So you speak Pidgin? \r\n\r\n😜 [I no dey speak Pidgin/I don’t speak Pidgin] o.  \r\n\r\nBut that was Pidgin you spoke just now, wasn’t it? \r\n\r\n😂 you don catch me. [Ehn/Yes ] it was. Actually, [Na small pidgin I dey speak/I speak a little pidgin ] .",
    "types": "Word Question",
}