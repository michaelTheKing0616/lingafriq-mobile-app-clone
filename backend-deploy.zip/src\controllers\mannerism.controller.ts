import { Request, Response, NextFunction } from "express";
import dotenv from "dotenv";
import { AuthenticatedRequest } from "../types/request.js";
import { ValidationError } from "../utils/error.js";
import MannerismModel from "../models/mannerism.model.js";
import UserModel from "../models/user.model.js";
import _ from "lodash";

dotenv.config()

export const getAllMannerism = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try{
        const userId = req.userId;
        const page = 1;
        const limit = 50;
        
        const user = await UserModel.findById(req.userId);

        const fullUrl = process.env.HOSTNAME;

        MannerismModel.paginate({}, {page, limit}).then((result)=>{
            let total_score = 0;
            const count = result.totalDocs;
            const next = result.hasNextPage ? `${fullUrl}?page=${page + 1}` : null;
            const previous = result.hasPrevPage ? `${fullUrl}?page=${page - 1}` : null;
            const results = result.docs;

            const data = results.map(result=>{

                const count = result.lessons.length;
                let completed = 0;
                let score = 0;
                const mannerism_language = result.language_id;

                result.lessons.forEach((section)=>{
                    score = score + section.score;
                    total_score = total_score + section.score;
                    if(user.mannerism.lesson_sections.includes(section.id)) {
                        completed = completed + 1
                    }
                })

                return {count, completed, score, mannerism_language, id: result.id, congrats: result.congrats, name: result.name}
            })
            res.status(200).json({ total_score, result: {count, next, previous, results:data }});
        })
        
    }catch(e){
        next(e);
    }
}

export const getAllMannerismLessons = async (req: AuthenticatedRequest, res: Response, next: NextFunction) =>{
    try{
        const userId = req.userId
        const lessonId = Number(req.params.lessonId);
        const lesson = await MannerismModel.findOne({id: lessonId});

        if(!lesson) res.status(200).json([]);

        const user = await UserModel.findById(userId);

        const mannerism = {
            ..._.pick(lesson, ["id", "name", "congrats"]), 
            mannerism_language: lesson.language_id
        }

        const lessonsArray = lesson.lessons.map(item=>{
            const completed = user.mannerism.lesson_sections.includes(item.id)
            return {
                ..._.pick(item, ["id", "title", "text", "image", "audio", "video", "score", "types", "date_time"]),
                completed_by: completed ? user.id : null,
                lesson_section: item.lesson_section_id
            }
        })
        
        res.status(200).json([{mannerism}, {mannerism_lesson: [...lessonsArray]}])
    } catch(e){
        next
    }
}

export const getMannerismLessonSections = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try{
        const userId = req.userId
        const lessonId = Number(req.params.lessonId);
        const sectionId = Number(req.params.sectionId);

        const user = await UserModel.findById(userId);

        if (typeof lessonId !== "number" || typeof sectionId !== "number" ) throw new ValidationError("Id should be a number");

        const lesson = await MannerismModel.findOne({id: lessonId});
        const lessonSection = lesson.lessons.find(section=>section.id === sectionId);

        // const completed = lessonSection.completed_by.includes(userId);

        return res.status(200).json([{
            ..._.pick(lessonSection, ["id", "title", "score","types", "date_time", "text", "image", "audio", "video"]),
            lesson_history: lessonSection.lesson_section_id,
            completed_by: user.id
        }]);
    } catch (e){
        next(e)
    }
}

export const markMannerismSectionAsCompleted = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try{
        const { lessonId, sectionId } = req.params;

        if(!lessonId || !sectionId) throw new ValidationError("language Id and question Id should be provided")

        const lesson_section = await MannerismModel.findOne({id: lessonId});
        const lesson = lesson_section.lessons.find(item=> item.id === Number(sectionId))

        if(!lesson) throw new Error("Document not Found")

        const currentUser = await UserModel.findById(req.userId);

        let msg;

        if(!currentUser.mannerism.lesson_sections.includes(Number(sectionId))){
            currentUser.points = currentUser.points + lesson.score;
            currentUser.mannerism.lesson_sections.push(Number(sectionId))
            await currentUser.save();
            msg = "Lesson Completed Successfully"
        }
        else msg = "You have already completed this Lesson!"

        res.status(200).json({msg})

    } catch(e){
        next(e)
    }
}