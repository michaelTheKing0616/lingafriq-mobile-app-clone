import { Lesson } from "@/models/schemas/lesson.js";
import { NextFunction, Request, Response } from "express";
import { Model, Document } from "mongoose";
import { QuizSection } from "@/models/schemas/quiz.js";
import _ from "lodash";
import { Option } from "@/models/schemas/question.js";
import { ValidationError } from "../utils/error.js";
import { RandomQuestion } from "../models/randomQuiz.model.js";
import { getUniqueId } from "../utils/random.js";
import { validateRandomQuestion } from "../utils/validation/validateRandomQuestion.js";

interface ModelDocument extends Document {
    lessons?: Lesson []
    history_lessons?: Lesson []
    lesson_sections?: Lesson [];
    quiz_sections?: QuizSection []
}

export const fetchAllRandomQuestions = (Model: Model<RandomQuestion>) => async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { language_id } = req.params;
        const questions = await Model.find({language_id});

        const final_questions = questions.map(question=>{
            return {
                id: question.id,
                image: question.image,
                video: question.video,
                audio: question.audio
            }
        })

        console.log({final_questions})
        res.status(200).json([...final_questions]);
    } catch (error) {
        next(error)
    }
}

export const addNewRandomQuestionsToModel = (Model: Model<RandomQuestion>) => async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { language_id } = req.params;
    
        const formData = req.body;
    
        const image: Express.Multer.File | undefined = req.files["image"];
        const audio: Express.Multer.File | undefined = req.files["audio"];
        const video: Express.Multer.File | undefined = req.files["video"];
    
        if(image) formData.image = _.replace(image[0].path, "public/media/", "")
        if(audio) formData.audio = _.replace(audio[0].path, "public/media/", "")
        if(video) formData.video = _.replace(video[0].path, "public/media/", "")

        const id = getUniqueId();
    
        formData.options = JSON.parse(formData.options).map((option: Option, index: number)=>{
            return {
                ...option,
                id: index + 1,
                quiz_question_id: id
            }
        }) as Option [];

        const {error, value} = validateRandomQuestion({...formData, language_id, id})

        if(error) throw new ValidationError(error.details[0].message);

        const question = new Model({...value});

        question.save();
    
        res.status(200).json({msg: "Question Added Suceesfully"})
    } catch (error) {
        next(error)
    }
}

export const updateRandomQuestionsInModel = (Model: Model<ModelDocument>) => async <T extends Document> (req: Request, res: Response, next: NextFunction) => {
    try {
        const { question_id } = req.params;
    
        const formData = req.body;
    
        const image: Express.Multer.File | undefined = req.files["image"];
        const audio: Express.Multer.File | undefined = req.files["audio"];
        const video: Express.Multer.File | undefined = req.files["video"];
    
        if(image) formData.image = _.replace(image[0].path, "public/media/", "")
        if(audio) formData.audio = _.replace(audio[0].path, "public/media/", "")
        if(video) formData.video = _.replace(video[0].path, "public/media/", "")
    
        formData.options = JSON.parse(formData.options).map((option: Option, index: number)=>{
            return {
                ...option,
                id: index + 1,
                quiz_question_id: question_id
            }
        }) as Option [];

        const {error, value} = validateRandomQuestion({...formData});
        
        if(error) throw new ValidationError(error.details[0].message);

        await Model.findOneAndUpdate({id: question_id}, {...value})
    
        res.status(200).json({msg: "Question Updated Suceesfully"})
    } catch (error) {
        next(error)
    }
}

export const deleteRandomQuestionsFromModel = (Model: Model<ModelDocument>) => async <T extends Document> (req: Request, res: Response, next: NextFunction) => {
    try {
        const { question_id } = req.params;
    
        await Model.findOneAndDelete({id: question_id});

        res.status(200).json({msg: "Question Deleted Suceesfully"})
    } catch (error) {
        next(error)
    }
}