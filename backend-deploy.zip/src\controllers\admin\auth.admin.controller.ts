import { NextFunction, Response, Request } from "express";
import { ValidationError } from "../../utils/error.js";
import { AuthenticationError } from "../../utils/error.js";
import UserModel from "../../models/user.model.js";
import djangoHash from "django-hash";
import jwt from "jsonwebtoken";


export const adminLogin = async (req: Request, res:Response, next: NextFunction) => {
    try{
        // get login details from request
        const {email, password} = req.body;

        if(!email || !password)throw new ValidationError("Email and Password are required");

        if(email.length < 1 || password.length < 6){
            throw new ValidationError("Email and password are required")
        }

        // check to see if user is in system and return with error message
        const user = await UserModel.findOne({ email: { $regex: new RegExp('^' + email.trim() + '$', 'i') } })
        if(!user) throw new AuthenticationError("User not Found");


        const match = await djangoHash.verify(password, user.password);
        if(!match) throw new AuthenticationError("Password is not a match");

        if(!user.is_admin){
            throw new AuthenticationError("User is not an admin");
        }

        const token = jwt.sign({_id: user._id.toString()}, process.env.JWT_SECRET , {expiresIn: "7d"})

        res.cookie("token", token, {httpOnly: true, secure: true, sameSite: "none"});

        res.status(200).json(user)

    }catch(e){
        next(e)
    }
}

export const logout = async (req: Request, res: Response, next: NextFunction) => {
    try{
        // clear cookie from user seystem
        res.clearCookie('token');
        
        // response to determine logout was successful
        res.status(204).json({msg: "Logged out Successfully"});
    } catch(e){
        next(e);
    }
}