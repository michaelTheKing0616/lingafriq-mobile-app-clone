/**
 * Scraper Client Service - API-based approach
 * 
 * This service scrapes Wikipedia content and POSTs it to the backend API
 * instead of directly accessing the database. This is more secure and follows
 * best practices for automated scrapers.
 */

import { CultureScraperService } from './cultureScraper.service.js';

interface ScrapedArticle {
  title: string;
  content: string;
  excerpt: string;
  category: string;
  country: string;
  region?: string;
  language?: string;
  featured_image?: string;
  images?: string[];
  source_url: string;
  source_name: string;
  tags: string[];
}

export class ScraperClientService {
  private backendUrl: string;
  private scraperToken: string;

  constructor() {
    this.backendUrl = process.env.BACKEND_URL || 'http://localhost:4000';
    this.scraperToken = process.env.SCRAPER_TOKEN || '';
    
    if (!this.scraperToken) {
      console.warn('⚠️  SCRAPER_TOKEN not set. API calls will fail.');
    }
  }

  /**
   * Post articles to backend API
   */
  async postArticlesToAPI(articles: ScrapedArticle[]) {
    try {
      const response = await fetch(`${this.backendUrl}/scraper/articles/bulk`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.scraperToken}`
        },
        body: JSON.stringify({ articles })
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(`API error: ${error.error || response.statusText}`);
      }

      const result = await response.json();
      return result;

    } catch (error: any) {
      console.error('Error posting to API:', error.message);
      throw error;
    }
  }

  /**
   * Test API connectivity
   */
  async testConnection() {
    try {
      const response = await fetch(`${this.backendUrl}/scraper/health`);
      const result = await response.json();
      return result.success;
    } catch (error) {
      return false;
    }
  }
}

/**
 * Run scraper job via API
 */
export const runScraperViaAPI = async () => {
  console.log('Starting culture content scraper (API mode)...');
  console.log('');
  
  const client = new ScraperClientService();
  const scraper = new CultureScraperService();

  // Test API connection first
  console.log('Testing API connection...');
  const apiUrl = process.env.BACKEND_URL || 'http://localhost:4000';
  console.log(`Backend URL: ${apiUrl}`);
  
  const isConnected = await client.testConnection();
  if (!isConnected) {
    throw new Error(`Cannot connect to backend API at ${apiUrl}/scraper/health`);
  }
  console.log('✓ API connection successful');
  console.log('');

  try {
    // Scrape default topics from Wikipedia
    console.log('Scraping Wikipedia articles...');
    const articles = await scraper.scrapeDefaultTopics();
    console.log(`✓ Scraped ${articles.length} articles from Wikipedia`);
    console.log('');

    if (articles.length === 0) {
      console.log('No new articles to save.');
      return;
    }

    // Post to API
    console.log(`Posting ${articles.length} articles to backend API...`);
    const result = await client.postArticlesToAPI(articles as any);
    
    console.log('');
    console.log('==========================================');
    console.log('✅ SCRAPER COMPLETED SUCCESSFULLY!');
    console.log('==========================================');
    console.log('');
    console.log(`Results:`);
    console.log(`  • Total articles: ${result.stats.total}`);
    console.log(`  • Saved: ${result.stats.saved}`);
    console.log(`  • Skipped: ${result.stats.skipped}`);
    console.log(`  • Errors: ${result.stats.errors}`);
    console.log('');

    if (result.errors && result.errors.length > 0) {
      console.log('Errors encountered:');
      result.errors.forEach((err: any) => {
        console.log(`  ❌ ${err.title}: ${err.error}`);
      });
      console.log('');
    }

    // Optionally scrape news (requires API key)
    if (process.env.NEWS_API_KEY) {
      console.log('Scraping news articles...');
      const newsArticles = await scraper.scrapeAfricanNews(
        process.env.NEWS_API_KEY,
        'culture'
      );
      
      if (newsArticles.length > 0) {
        console.log(`Posting ${newsArticles.length} news articles...`);
        const newsResult = await client.postArticlesToAPI(newsArticles as any);
        console.log(`✓ News articles - Saved: ${newsResult.stats.saved}, Skipped: ${newsResult.stats.skipped}`);
      }
    }

    console.log('Culture content scraper completed.');

  } catch (error: any) {
    console.error('');
    console.error('==========================================');
    console.error('❌ SCRAPER ERROR:');
    console.error('==========================================');
    console.error(error.message);
    console.error('');
    console.error('Common issues:');
    console.error('  1. Backend not running');
    console.error(`     → Check that backend is accessible at ${process.env.BACKEND_URL || 'http://localhost:4000'}`);
    console.error('  2. Invalid SCRAPER_TOKEN');
    console.error('     → Verify SCRAPER_TOKEN secret is correct');
    console.error('  3. Network timeout');
    console.error('     → Check network connectivity to backend');
    console.error('');
    throw error;
  }
};

