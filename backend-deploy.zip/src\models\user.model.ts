import mongoose from 'mongoose';
import { Document, Schema, model } from 'mongoose';
import mongoosePaginate from "mongoose-paginate-v2";
import { PaginateModel } from 'mongoose';
import { getUniqueId } from '../utils/random.js';
import dotenv from "dotenv";

dotenv.config();
export interface IUser {
    id: number,
    email: string,
    password: string,
    last_login: string,
    username: string,
    first_name: string
    last_name: string,
    avater: string,
    points:number,
    level: string,
    agree_to_privacy_terms: boolean,
    is_active: boolean
    is_admin: boolean
    is_staff: boolean,
    nationality: string,
    lesson: {
        lesson_sections: number [],
        quiz_sections: number []
    },
    mannerism:{
        lesson_sections: number []
    },
    history:{
        lesson_sections: number []
        quiz_sections: number []
    },
    random_quiz: number [],
    history_quiz: {
        quiz_sections: number []
    },
    language_quiz: {
        quiz_sections: number []
    },
    // Loading screen content tracking
    lastLoadingContentId?: string,
    viewedLoadingContent?: string[]
}

export interface UserDocument extends IUser,  Omit<Document, "id"> {
    ranks: Promise<number>,
}

const userSchema = new Schema<UserDocument>({
    id:{
        type: Number,
        unique: true,
        default: getUniqueId()
    },
    email: {
        type:String,
        trim:true,
        required:true, 
        unique: true, 
        index: true,
        lowercase: true
    },
    password: {
        type:String,
        required:true
    },
    last_login: {
        type: String,
        default: new Date().toString()
    },
    username: {
        type: String,
        required: true,
        trim: true
    },
    first_name: {
        type: String,
        required: true,
    },
    last_name: {
        type: String, 
        required: true,
    },
    avater: {
        type: String
    }, 
    points: {
        type: Number,
        index: true
    },
    level: {
        type: String
    },
    agree_to_privacy_terms: {
        type: Boolean,
        default: true,
    },
    is_active: {
        type: Boolean,
        default: true,
        required: true
    },
    is_admin: {
        type:Boolean,
        default: false,
        required: true
    },
    is_staff: {
        type: Boolean,
        default: false,
        required: true
    },
    nationality: {
        type: String,
        required: true
    },
    lesson:{
        lesson_sections: {type: [Number]},
        quiz_sections: {type: [Number]}
    },
    history:{
        lesson_sections: {type: [Number]},
        quiz_sections: {type: [Number]}
    },
    mannerism:{
        lesson_sections: {type: [Number]},
    },
    history_quiz:{
        quiz_sections: {type: [Number]}
    },
    language_quiz: {
        quiz_sections: {type: [Number]}
    },
    random_quiz: {type: [Number]},
    // Loading screen content tracking
    lastLoadingContentId: {
        type: String,
        default: null
    },
    viewedLoadingContent: {
        type: [String],
        default: []
    }
} , { timestamps:true});

userSchema.virtual("ranks").get(async function () {
    return  await this.$model('user')
      .countDocuments({ points: { $gt: this.points } })
      .then(count => count + 1);
});
userSchema.plugin(mongoosePaginate);

const UserModel = model<UserDocument, PaginateModel<UserDocument>>("user", userSchema, 'user');
export default UserModel;