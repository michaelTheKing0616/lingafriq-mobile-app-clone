import { Request, Response, NextFunction } from "express";
import LanguageModel from "../models/language.model.js";
import LessonModel from "../models/lesson.model.js";
import HistoryModel from "../models/history.model.js";
import AppMetadata from "../models/appMetadata.model.js";
import MannerismModel from "../models/mannerism.model.js";
import HistoryQuizModel from "../models/historyQuiz.model.js";
import LanguageQuizModel from "../models/languageQuiz.model.js";
import RandomQuizModel from "../models/randomQuiz.model.js";

export const storeDefaults = async (req: Request, res: Response, next: NextFunction) => {
    try{

        const defaultData = new AppMetadata({});

        // Save Languages to Default Data
        const languages = await LanguageModel.find({});

        languages.forEach((language)=>{
            defaultData.languages[language.id] = {
                language_id: language.id,
                language_name: language.name,
                lesson: {
                    lesson_sections: [],
                    quiz_sections: []
                },
                history: {
                    lesson_sections: [],
                    quiz_sections: []
                },
                mannerism: {
                    lesson_sections: []
                },
                history_quiz: {
                    quiz_sections: []
                },
                language_quiz: {
                    quiz_sections: []
                },
                random_quiz: {
                    questions: []
                }
            }
        });

        const lessons = await LessonModel.find({});
        const history = await HistoryModel.find({})
        const mannerisms = await MannerismModel.find({})
        const historyQuiz = await HistoryQuizModel.find({})
        const languageQuiz = await LanguageQuizModel.find({})
        const randomQuiz = await RandomQuizModel.find({})

        lessons.forEach((lesson)=>{
            lesson.lesson_sections.forEach(section=>{
                defaultData.languages[lesson.language_id].lesson.lesson_sections.push(section.id)
            })
            lesson.quiz_sections.forEach(section=>{
                defaultData.languages[lesson.language_id].lesson.quiz_sections.push(section.id)
            })
        })

        history.forEach((lesson)=>{
            lesson.history_lessons.forEach(section=>{
                defaultData.languages[lesson.language_id].history.lesson_sections.push(section.id)
            })
            lesson.quiz_sections.forEach(section=>{
                defaultData.languages[lesson.language_id].history.quiz_sections.push(section.id)
            })
        })

        mannerisms.forEach((lesson)=>{
            lesson.lessons.forEach(section=>{
                defaultData.languages[lesson.language_id].mannerism.lesson_sections.push(section.id)
            })
        })

        historyQuiz.forEach((lesson)=>{
            lesson.quiz_sections.forEach(section=>{
                defaultData.languages[lesson.language_id].history_quiz.quiz_sections.push(section.id)
            })
        })

        languageQuiz.forEach((lesson)=>{
            lesson.quiz_sections.forEach(section=>{
                defaultData.languages[lesson.language_id].language_quiz.quiz_sections.push(section.id)
            })
        })

        randomQuiz.forEach((question)=>{
            defaultData.languages[question.language_id].random_quiz.questions.push(question.id)
        })
        

        await defaultData.save()

        res.status(200).json({msg: "Defaults Saved succesfully"})

    } catch(e){
        console.log("Storing Default Function Failed")
        next(e)
    }
}