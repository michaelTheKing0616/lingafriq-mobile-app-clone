import mongoose, { Schema, Document } from 'mongoose';
import { QuizSection, QuizSectionSchema } from './schemas/quiz.js';
import mongoosePaginate from "mongoose-paginate-v2";
import { PaginateModel } from 'mongoose';
import { getUniqueId } from '../utils/random.js';

export interface ILanguageQuiz {
  congrats: string;
  id: number;
  language_id: number,
  name: string;
  quiz_sections: QuizSection [], 
}

export type LanguageQuizDocument = ILanguageQuiz & Document

const languageQuizSchema: Schema = new Schema<LanguageQuizDocument>({
  congrats: { type: String },
  id: { type: Number, required: true, index: true },
  language_id: {type: Number, required: true, default: getUniqueId(), index: true},
  name: { type: String, required: true }, 
  quiz_sections: {type: [QuizSectionSchema], default: []},
});

languageQuizSchema.plugin(mongoosePaginate)

const LanguageQuizModel = mongoose.model<LanguageQuizDocument, PaginateModel<LanguageQuizDocument>>('languageQuiz', languageQuizSchema, "language_quiz");
export default LanguageQuizModel;
 