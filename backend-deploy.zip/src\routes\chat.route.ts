import express from 'express';
import * as chatController from '../controllers/chat.controller.js';
import { protect } from '../middleware/auth.middleware.js';

const router = express.Router();

// All routes require authentication
router.use(protect);

// Global chat
router.get('/global', chatController.getGlobalMessages);
router.post('/global', chatController.sendGlobalMessage);

// Private chat
router.get('/private/:otherUserId', chatController.getPrivateMessages);
router.post('/private', chatController.sendPrivateMessage);
router.get('/conversations', chatController.getConversations);

// Message management
router.delete('/messages/:id', chatController.deleteMessage);

export default router;

