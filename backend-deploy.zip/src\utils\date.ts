import moment from "moment";

export const dateFormat = "YYYY-MM-DD HH:mm:ss.SSSSSS";

export const getCurrentDate = () => {
    return moment().format(dateFormat)
}