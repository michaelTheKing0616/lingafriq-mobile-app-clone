import express from 'express';
import { requireAdmin, requireSignin } from '../../middleware/auth.middleware.js';
import { sendMessageToMultipleUsers, sendMessageToSingleUser, getAllMessages, deleteMessage } from '../../controllers/admin/messages.admin.controller.js';

const router = express.Router();

router.get("/all", requireSignin, requireAdmin, getAllMessages);

router.delete("/:message_id", requireSignin, requireAdmin, deleteMessage);

router.post("/send_message", requireSignin, requireAdmin, sendMessageToSingleUser);

router.post("/send_multi_message", requireSignin, requireAdmin, sendMessageToMultipleUsers);


export default router;