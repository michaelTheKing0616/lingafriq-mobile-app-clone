# 🔒 Secure API-Based Scraper Setup

## ✅ WHAT WE IMPLEMENTED

Instead of having GitHub Actions connect directly to your MongoDB database, we've implemented a **secure API endpoint approach**:

```
GitHub Actions → HTTPS API → Your Backend → MongoDB (local/private)
```

**Benefits:**
- ✅ MongoDB stays completely private (no network exposure)
- ✅ Backend validates all data before saving
- ✅ JWT authentication protects the API
- ✅ You control access via tokens
- ✅ Can add rate limiting, logging, etc.

---

## 🎯 QUICK SETUP (3 Steps)

### **Step 1: Generate Scraper Token**

On your server (or locally with access to your .env):

```bash
cd /path/to/node-backend
node scripts/generateScraperToken.js
```

This will output a JWT token. **Copy it!**

---

### **Step 2: Add GitHub Secrets**

Add these two secrets to **BOTH** backend repositories:

**For lingafriq/node-backend:**
- Go to: https://github.com/lingafriq/node-backend/settings/secrets/actions

**For LingAfrika/node-backend:**
- Go to: https://github.com/LingAfrika/node-backend/settings/secrets/actions

**Add these secrets:**

```
Name: BACKEND_URL
Value: https://your-backend-domain.com
(Example: https://api.lingafriq.com or https://lingafriq.herokuapp.com)
```

```
Name: SCRAPER_TOKEN
Value: (paste the token from Step 1)
```

---

### **Step 3: Deploy Updated Backend**

The new API endpoint needs to be live before the scraper can use it.

**Option A - Manual deployment:**
```bash
# Pull latest code
git pull origin main

# Install dependencies (if needed)
npm install

# Build
npm run build

# Restart server
pm2 restart lingafriq-backend
# OR
systemctl restart your-backend-service
```

**Option B - Automatic:**
If you have auto-deployment set up, just push the code and it will deploy automatically.

---

## 📋 WHAT WAS ADDED

### **New Files:**

1. **`src/routes/scraper.route.ts`**
   - Secure API endpoints for scraper
   - JWT authentication middleware
   - Bulk article save endpoint
   - Single article save endpoint
   - Health check endpoint

2. **`src/services/scraperClient.service.ts`**
   - Client that POSTs to API instead of saving directly
   - Connection testing
   - Error handling

3. **`scripts/generateScraperToken.js`**
   - Generates JWT tokens for scraper authentication

### **Modified Files:**

1. **`src/routes/index.route.ts`**
   - Added `/scraper` route

2. **`src/services/cultureScraper.service.ts`**
   - Split into separate methods for API vs direct DB access

3. **`.github/workflows/simple-deploy.yml`**
   - Updated to use API-based scraper
   - Requires BACKEND_URL and SCRAPER_TOKEN

---

## 🔧 API ENDPOINTS

### **Health Check (No Auth)**
```
GET /scraper/health
```

Returns:
```json
{
  "success": true,
  "message": "Scraper API is running",
  "timestamp": "2025-12-04T..."
}
```

---

### **Save Single Article**
```
POST /scraper/articles/save
Authorization: Bearer {SCRAPER_TOKEN}
Content-Type: application/json
```

Body:
```json
{
  "title": "Yoruba people",
  "content": "The Yoruba people are...",
  "excerpt": "Short summary...",
  "category": "tradition",
  "country": "Nigeria",
  "source_url": "https://en.wikipedia.org/wiki/Yoruba_people",
  "source_name": "Wikipedia",
  "tags": ["yoruba", "nigeria", "culture"]
}
```

Response:
```json
{
  "success": true,
  "message": "Article saved successfully",
  "article": {
    "id": "507f1f77bcf86cd799439011",
    "title": "Yoruba people",
    "category": "tradition",
    "slug": "yoruba-people"
  }
}
```

---

### **Bulk Save Articles**
```
POST /scraper/articles/bulk
Authorization: Bearer {SCRAPER_TOKEN}
Content-Type: application/json
```

Body:
```json
{
  "articles": [
    {
      "title": "Yoruba people",
      "content": "...",
      "category": "tradition",
      ...
    },
    {
      "title": "Igbo people",
      ...
    }
  ]
}
```

Response:
```json
{
  "success": true,
  "message": "Bulk article save completed",
  "stats": {
    "total": 42,
    "saved": 40,
    "skipped": 2,
    "errors": 0
  },
  "savedArticles": [...],
  "skippedArticles": [...],
  "errors": []
}
```

---

## 🔒 SECURITY FEATURES

### **JWT Authentication**
- All endpoints (except health check) require valid JWT token
- Token never expires (for automation)
- Token can be revoked by changing SCRAPER_SECRET

### **Data Validation**
- Required fields checked before saving
- Duplicate detection (by title)
- Invalid data rejected

### **Error Handling**
- Detailed error messages
- Partial success (some articles saved, some skipped)
- No data corruption on errors

---

## 🧪 TESTING

### **Test API Health (No Auth)**
```bash
curl https://your-backend.com/scraper/health
```

Should return:
```json
{"success":true,"message":"Scraper API is running",...}
```

---

### **Test with Token**
```bash
curl -X POST https://your-backend.com/scraper/articles/save \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Test Article",
    "content": "Test content",
    "excerpt": "Test excerpt",
    "category": "tradition",
    "country": "Test",
    "source_url": "https://example.com",
    "source_name": "Test",
    "tags": ["test"]
  }'
```

Should return:
```json
{"success":true,"message":"Article saved successfully",...}
```

---

## 🔄 HOW THE WORKFLOW WORKS

### **GitHub Actions Workflow:**

1. ✅ Checkout code
2. ✅ Build TypeScript
3. ✅ Run scraper client:
   - Scrapes Wikipedia (40+ articles)
   - POSTs to your backend API at BACKEND_URL
   - Backend authenticates with SCRAPER_TOKEN
   - Backend validates and saves to MongoDB
4. ✅ Reports success/failure

**Your MongoDB:**
- ✅ Stays completely private
- ✅ No network exposure needed
- ✅ No firewall changes required
- ✅ Secure!

---

## 🎯 ENVIRONMENT VARIABLES

### **Backend Server (.env):**
```bash
# Existing (keep these)
MONGODB_URI=mongodb://localhost:27017/lingafriq
JWT_SECRET=your_jwt_secret_here

# Optional: Separate scraper secret (recommended)
SCRAPER_SECRET=your_scraper_secret_here

# If not set, SCRAPER_SECRET defaults to JWT_SECRET
```

### **GitHub Secrets (Required):**
```
BACKEND_URL=https://your-backend.com
SCRAPER_TOKEN=(generated JWT token)
NEWS_API_KEY=(optional, for news scraping)
```

---

## 🆘 TROUBLESHOOTING

### **Error: "Cannot connect to backend API"**
**Solution:**
- Verify BACKEND_URL is correct and accessible
- Test: `curl https://your-backend.com/scraper/health`
- Check backend server is running
- Check firewall allows HTTPS (443) traffic

---

### **Error: "Invalid or expired token"**
**Solution:**
- Regenerate token: `node scripts/generateScraperToken.js`
- Update SCRAPER_TOKEN secret in GitHub
- Make sure JWT_SECRET hasn't changed on server

---

### **Error: "Article with this title already exists"**
**This is OK!** The scraper skips duplicates automatically.

**To re-import:**
- Delete existing articles from MongoDB
- Or modify article titles in scraper

---

### **GitHub Actions Fails:**
**Check:**
1. Both secrets (BACKEND_URL, SCRAPER_TOKEN) are set
2. Backend server is running and accessible
3. API endpoint is deployed (new code is live)
4. Token is valid (test with curl)

---

## 📊 MONITORING

### **Check Article Count:**
```bash
# Via API
curl https://your-backend.com/culture-magazine/articles

# Via MongoDB (on server)
mongosh lingafriq --eval "db.culturearticles.countDocuments()"
```

### **View Recent Articles:**
```bash
mongosh lingafriq --eval "db.culturearticles.find().sort({created_at:-1}).limit(5)"
```

---

## 🎉 BENEFITS RECAP

| Aspect | Direct DB Access | API Approach (Implemented) |
|--------|------------------|----------------------------|
| MongoDB Exposure | ❌ Must be publicly accessible | ✅ Stays private |
| Security | ❌ Database credentials exposed | ✅ Only API tokens exposed |
| Data Validation | ❌ None | ✅ Backend validates |
| Access Control | ❌ All or nothing | ✅ Fine-grained (JWT) |
| Monitoring | ❌ Difficult | ✅ Easy (API logs) |
| Scalability | ❌ Limited | ✅ Can add rate limiting |

---

## ✅ FINAL CHECKLIST

Before running the workflow:

- [ ] Backend server is running
- [ ] New code is deployed (with /scraper routes)
- [ ] Generated SCRAPER_TOKEN
- [ ] Added BACKEND_URL to GitHub Secrets
- [ ] Added SCRAPER_TOKEN to GitHub Secrets
- [ ] Tested `/scraper/health` endpoint
- [ ] (Optional) Tested with curl to save test article

---

## 🚀 READY TO RUN

Once everything is set up:

1. Push code to GitHub (workflow runs automatically)
2. Or manually trigger: Actions → "Simple Deploy & Prime Database" → "Run workflow"
3. Watch it populate your database via API!

**Expected output:**
```
✅ API connection successful
✓ Scraped 42 articles from Wikipedia
Posting 42 articles to backend API...
✅ SCRAPER COMPLETED SUCCESSFULLY!
Results:
  • Total articles: 42
  • Saved: 40
  • Skipped: 2 (already exist)
  • Errors: 0
```

---

**Your MongoDB is now secure, and your database gets populated automatically via API!** 🎉

