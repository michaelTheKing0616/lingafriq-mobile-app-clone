import { NextFunction, Request, Response } from "express";
import { AuthenticatedRequest } from "../types/request.js";
import _ from "lodash";
import DeviceModel from "../models/devices.model.js";
import UserModel from "../models/user.model.js";

interface DeviceData {
    registration_id: string;
    type: "android" | "ios";
}


export const getAllDevices = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try{
        const user  = await UserModel.findById(req.userId);
        const devices = await DeviceModel.find({user_id: user.id});
        const data = devices.map(item=>{
            return{..._.pick(item, [ "registration_id", "name", "device_id", "date_created", "active", "type"]), id: item._id}
        })
        res.status(200).json([...data])
    } catch(e){
        next(e)
    }
}

export const addDevice = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try{
        const user  = await UserModel.findById(req.userId);
        const deviceData: DeviceData = req.body;

        const current_device =  DeviceModel.findOne({registration_id: deviceData.registration_id});
        if(current_device) return res.status(201).json({msg: "device already registered"});

        const device =  new DeviceModel({...deviceData, user_id: user.id});
        await device.save();

        res.status(201).json({msg: "Device registered successfully"});
    } catch(e){
        next(e)
    }
}

export const removeDevice = async (req: Request, res: Response, next: NextFunction) => {
    try{
        const token = req.params.token;

        await DeviceModel.findOneAndDelete({registration_id: token});

        res.status(204).send({msg: "Deleted Succesfully"});
    } catch(e){
        console.log(e)
        next(e)
    }
}