import { customAlphabet } from "nanoid";

export const getUniqueId = (): number => {
    const alphabet = '0123456789';
    const idLength = 16;
    const uniqueId = customAlphabet(alphabet, idLength)();
    return Number(uniqueId)
}