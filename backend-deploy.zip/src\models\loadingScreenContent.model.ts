import mongoose, { ObjectId } from "mongoose";
import { Document, Schema, model } from 'mongoose';
import mongoosePaginate from "mongoose-paginate-v2";
import { PaginateModel } from "mongoose";
import { getUniqueId } from "../utils/random.js";

export interface ILoadingScreenContent {
  id: string;
  country: string;
  countryFlag: string;
  greeting: string;
  greetingTranslation: string;
  language: string;
  fact: string;
  imageUrl?: string;
  imageGeneratedAt?: Date;
  isPublished: boolean;
  isFeatured: boolean;
  createdAt: Date;
  updatedAt: Date;
}

interface LoadingScreenContentDocument extends ILoadingScreenContent, Omit<Document, "id"> {}

const loadingScreenContentSchema = new mongoose.Schema<LoadingScreenContentDocument>({
  id: {
    type: String,
    required: true,
    unique: true,
    index: true
  },
  country: {
    type: String,
    required: true
  },
  countryFlag: {
    type: String,
    required: true
  },
  greeting: {
    type: String,
    required: true
  },
  greetingTranslation: {
    type: String,
    required: true
  },
  language: {
    type: String,
    required: true,
    index: true
  },
  fact: {
    type: String,
    required: true
  },
  imageUrl: {
    type: String,
    default: null
  },
  imageGeneratedAt: {
    type: Date,
    default: null
  },
  isPublished: {
    type: Boolean,
    default: true
  },
  isFeatured: {
    type: Boolean,
    default: false
  }
}, { timestamps: true });

// Virtual to get full image URL if imageUrl is relative
loadingScreenContentSchema.virtual("fullImageUrl").get(function() {
  if (!this.imageUrl) return null;
  if (this.imageUrl.startsWith('http')) return this.imageUrl;
  const prefix = process.env.HOSTNAME;
  return `${prefix}/media/${this.imageUrl}`;
});

loadingScreenContentSchema.plugin(mongoosePaginate);

const LoadingScreenContentModel = model<LoadingScreenContentDocument, PaginateModel<LoadingScreenContentDocument>>(
  'loadingScreenContent',
  loadingScreenContentSchema,
  "loadingScreenContent"
);

export default LoadingScreenContentModel;

