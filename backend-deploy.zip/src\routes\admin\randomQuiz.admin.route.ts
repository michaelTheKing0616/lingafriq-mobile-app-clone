import express from 'express';
import { requireAdmin, requireSignin } from '../../middleware/auth.middleware.js';

import multer from 'multer';

import * as RandomQuizService from "../../services/RandomQuizService.js";

import RandomQuizModel from '../../models/randomQuiz.model.js';

const storageDisk = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'public/media/random_quiz/');
    },
    filename: function (req, file, cb) {
        const objName = Date.now().valueOf().toString() + file.originalname
        cb(null, objName);
    }
})
const upload = multer({ storage: storageDisk })

const router = express.Router();

router.get("/:language_id", requireSignin, requireAdmin, RandomQuizService.fetchAllRandomQuestions(RandomQuizModel))

router.post("/:language_id", 
    requireSignin, 
    requireAdmin,
    upload.fields([
        { name: 'image', maxCount: 1 },
        { name: 'audio', maxCount: 1 },
        { name: 'video', maxCount: 1 }
    ]), 
    RandomQuizService.addNewRandomQuestionsToModel(RandomQuizModel))

router.put("/:question_id", 
    requireSignin, 
    requireAdmin, 
    upload.fields([
        { name: 'image', maxCount: 1 },
        { name: 'audio', maxCount: 1 },
        { name: 'video', maxCount: 1 }
    ]), 
    RandomQuizService.updateRandomQuestionsInModel(RandomQuizModel))

router.delete("/:question_id", requireSignin, requireAdmin, RandomQuizService.deleteRandomQuestionsFromModel(RandomQuizModel))

export default router;