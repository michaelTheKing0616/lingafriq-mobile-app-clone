import Joi from "joi"
import { getCurrentDate } from "../date.js"

export const validateLessonSection = (formData: any, section_id: number, lesson_id: number) => {
    return Joi.object({
        id: Joi.number().unsafe().default(lesson_id), 
        score: Joi.number().default(5),
        date_time: Joi.string().default(getCurrentDate()),
        audio: Joi.string().allow(null, "").default(''),
        image: Joi.string().allow(null, "").default(''),
        lesson_section_id: Joi.number().unsafe().default(section_id),
        text: Joi.string(),
        title: Joi.string(),
        types: Joi.string().default("Tutorial"),
        video: Joi.string().allow(null, "").default(''),
    }).validate(formData, {allowUnknown: true, stripUnknown: true})
}