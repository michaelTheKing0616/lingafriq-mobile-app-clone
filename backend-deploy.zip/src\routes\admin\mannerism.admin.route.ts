import express from 'express';
import { requireAdmin, requireSignin } from '../../middleware/auth.middleware.js';

import * as LessonSectionController from "../../services/LessonSectionsService.js";
import * as LessonsController from "../../services/LessonService.js"

import MannerismModel from '../../models/mannerism.model.js';

import multer from "multer";

const storageDisk = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'public/media/mannerism/');
    },
    filename: function (req, file, cb) {
        const objName = Date.now().valueOf().toString() + file.originalname
        cb(null, objName);
    }
})

const upload = multer({ storage: storageDisk })

const router = express.Router();

router.get("/get_all_lessons/:language_id", requireSignin, requireAdmin, LessonsController.fetchAllLessonsFromModel(MannerismModel));

router.post("/add_new_lesson/:language_id", requireSignin, requireAdmin,  LessonsController.addNewLessonToModel(MannerismModel));

router.put("/update_lesson/:lesson_id", requireSignin, requireAdmin, LessonsController.updateLessonInModel(MannerismModel));

router.delete("/delete_lesson/:lesson_id",  requireSignin, requireAdmin, LessonsController.deleteLessonFromModel(MannerismModel));

/**
 * Lesson And Quiz Routes
 */
router.get("/get_all_sections/:lesson_id", requireSignin, requireAdmin, LessonSectionController.fetchAllLessonSectionsFromModel(MannerismModel));

/**
 * Lesson Section Routes
 */
router.post("/:lesson_id/lesson_section", 
    requireSignin, 
    requireAdmin, 
    upload.fields([
        { name: 'image', maxCount: 1 },
        { name: 'audio', maxCount: 1 },
        { name: 'video', maxCount: 1 }
    ]
    ), LessonSectionController.addNewLessonSectionToModel(MannerismModel));

router.put("/:lesson_id/lesson_section/:section_id", 
    requireSignin, 
    requireAdmin, 
    upload.fields([
        { name: 'image', maxCount: 1 },
        { name: 'audio', maxCount: 1 },
        { name: 'video', maxCount: 1 }
    ]
    ), LessonSectionController.updateLessonSectionInModel(MannerismModel));

router.delete("/:lesson_id/lesson_section/:section_id", requireSignin, requireAdmin, LessonSectionController.deleteLessonSectionFromModel(MannerismModel));

export default router;