import express from 'express';
import { requireAdmin, requireSignin } from '../../middleware/auth.middleware.js';

import * as LessonSectionController from "../../services/LessonSectionsService.js";
import * as QuizSectionController from "../../services/QuizSectionsService.js";
import * as QuestionController from "../../services/QuestionsService.js"
import * as LessonsController from "../../services/LessonService.js"

import HistoryQuizModel from '../../models/historyQuiz.model.js';

import multer from "multer";

const storageDisk = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'public/media/history_quiz/');
    },
    filename: function (req, file, cb) {
        const objName = Date.now().valueOf().toString() + file.originalname
        cb(null, objName);
    }
})

const upload = multer({ storage: storageDisk })

const router = express.Router();

router.get("/get_all_lessons/:language_id", requireSignin, requireAdmin, LessonsController.fetchAllLessonsFromModel(HistoryQuizModel));

router.post("/add_new_lesson/:language_id", requireSignin, requireAdmin,  LessonsController.addNewLessonToModel(HistoryQuizModel));

router.put("/update_lesson/:lesson_id", requireSignin, requireAdmin, LessonsController.updateLessonInModel(HistoryQuizModel));

router.delete("/delete_lesson/:lesson_id",  requireSignin, requireAdmin, LessonsController.deleteLessonFromModel(HistoryQuizModel));

/**
 * Lesson And Quiz Routes
 */
router.get("/get_all_sections/:lesson_id", requireSignin, requireAdmin, LessonSectionController.fetchAllLessonSectionsFromModel(HistoryQuizModel));

/**
 * Quiz Section Routes
 */
router.post("/:lesson_id/quiz_section", requireSignin, requireAdmin, QuizSectionController.addNewQuizSectionToModel(HistoryQuizModel));

router.put("/:lesson_id/quiz_section/:section_id", requireSignin, requireAdmin, QuizSectionController.updateQuizSectionInModel(HistoryQuizModel));

router.delete("/:lesson_id/quiz_section/:section_id", requireSignin, requireAdmin, QuizSectionController.deleteQuizSectionFromModel(HistoryQuizModel));

/** 
 * Question Routes
 */
router.get("/:lesson_id/quiz_section/:section_id/questions", requireSignin, requireAdmin, QuestionController.fetchAllQuestionsFromModel(HistoryQuizModel))

// Question section upload routes
router.post("/:lesson_id/quiz_section/:section_id/questions", 
    requireSignin, 
    requireAdmin, 
    upload.fields([
        { name: 'image', maxCount: 1 },
        { name: 'audio', maxCount: 1 },
        { name: 'video', maxCount: 1 }
    ]
    ), QuestionController.addNewQuestionsToModel(HistoryQuizModel));

// Lesson section upload routes
router.put("/:lesson_id/quiz_section/:section_id/questions/:question_id", 
    requireSignin, 
    requireAdmin, 
    upload.fields([
        { name: 'image', maxCount: 1 },
        { name: 'audio', maxCount: 1 },
        { name: 'video', maxCount: 1 }
    ]
), QuestionController.updateQuestionsInModel(HistoryQuizModel));

router.delete("/:lesson_id/quiz_section/:section_id/questions/:question_id", requireSignin, requireAdmin, QuestionController.deleteQuestionsFromModel(HistoryQuizModel))

export default router;