import Joi from "joi"
import { getCurrentDate } from "../date.js"

export const validateQuizSection = (formData: any, section_id: number, lesson_id: number) => {
    return Joi.object({
        id: Joi.number().unsafe().default(lesson_id), 
        score: Joi.number().default(5),
        date_time: Joi.string().default(getCurrentDate()),
        quiz_section_id: Joi.number().default(section_id),
        quiz: Joi.string(),
        quiz_type: Joi.string().default("Instant Quiz"),
    }).validate(formData, {allowUnknown: true, stripUnknown: true})
}