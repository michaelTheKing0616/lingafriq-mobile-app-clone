import { Response, NextFunction } from "express";
import { AuthenticatedRequest } from '../types/request.js';
import { ValidationError } from "../utils/error.js";
import _ from "lodash";
import RandomQuizModel from "../models/randomQuiz.model.js";
import UserModel from "../models/user.model.js";

export const getALLRandomQuizQuestions = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try{
        const userId = req.userId
        const languageId = req.params.languageId;
        const questions = await  RandomQuizModel.find({language_id: languageId});
        const inst_question = [];
        const user = await UserModel.findById(userId);
        questions.forEach(questionItem=>{
            const completed = user.random_quiz.includes(questionItem.id);

            const choices = questionItem.options.map(option=>{
                return {..._.pick(option, ["id", "text", "image", "correct_answer", ]), quiz_question: option.quiz_question_id }
            });

            const question = {
                ..._.pick(questionItem, ["id", "title", "question", "text","image","video", "audio", "add_hint", "fun_fact", "is_published", "types", "score", "date_time"]),
                language: questionItem.language_id,
                types: "Instant Question",
                completed_by: completed ? user.id : null
            }
            inst_question.push({choices, question})
        })

        res.status(200).send([{inst_question, word_question:[]}])
    } catch (e){
        next(e);
    }
}

export const markRandomQuestionAsComplete = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try{
        const { languageId, questionId } = req.params;

        if(!languageId || !questionId) throw new ValidationError("language Id and question Id should be provided")

        const question = await RandomQuizModel.findOne({language_id: languageId, id: questionId});

        if(!question) throw new Error("Document not Found")

        const currentUser = await UserModel.findById(req.userId);

        let msg;

        if(!currentUser.random_quiz.includes(Number(questionId))){
            currentUser.points = currentUser.points + question.score;
            currentUser.random_quiz.push(Number(questionId))
            await currentUser.save();
            msg = "Question Completed Successfully"
        }
        else msg = "You have already completed this question!"

        res.status(200).json({msg})

    } catch(e){
        next(e)
    }
}