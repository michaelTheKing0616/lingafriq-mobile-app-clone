import express from 'express';
import { getIdFromJWT, requireSignin } from '../middleware/auth.middleware.js';
import {
  getRandomContent,
  getContentByCountry,
  getContentByLanguage,
  getAllContent
} from '../controllers/loadingScreen.controller.js';

const router = express.Router();

/**
 * @openapi
 * /api/loading-screen:
 *   get:
 *     tags:
 *       - Loading Screen
 *     summary: Get random loading screen content
 *     description: Returns a random loading screen content item, excluding recently viewed content for the user
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Successfully retrieved loading screen content
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 result:
 *                   type: object
 *                   properties:
 *                     id:
 *                       type: string
 *                     country:
 *                       type: string
 *                     countryFlag:
 *                       type: string
 *                     greeting:
 *                       type: string
 *                     greetingTranslation:
 *                       type: string
 *                     language:
 *                       type: string
 *                     fact:
 *                       type: string
 *                     imageUrl:
 *                       type: string
 *                       nullable: true
 *       401:
 *         description: Unauthorized
 *       404:
 *         description: No content available
 */
router.get("/", requireSignin, getIdFromJWT, getRandomContent);

/**
 * @openapi
 * /api/loading-screen/country/{country}:
 *   get:
 *     tags:
 *       - Loading Screen
 *     summary: Get loading screen content by country
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: country
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Successfully retrieved content
 */
router.get("/country/:country", requireSignin, getIdFromJWT, getContentByCountry);

/**
 * @openapi
 * /api/loading-screen/language/{language}:
 *   get:
 *     tags:
 *       - Loading Screen
 *     summary: Get loading screen content by language
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: language
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Successfully retrieved content
 */
router.get("/language/:language", requireSignin, getIdFromJWT, getContentByLanguage);

/**
 * @openapi
 * /api/loading-screen/all:
 *   get:
 *     tags:
 *       - Loading Screen
 *     summary: Get all loading screen content (admin)
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Successfully retrieved all content
 */
router.get("/all", requireSignin, getIdFromJWT, getAllContent);

export default router;

