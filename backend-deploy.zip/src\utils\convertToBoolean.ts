type bool = "false" | "true" | Boolean;

export const convertToBoolean = (val: bool) => {
    if (typeof val === "boolean") return val
    if(val === "false") return false;
    if(val === "true") return true;
}