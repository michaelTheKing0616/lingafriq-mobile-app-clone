import mongoose, { Document, Schema } from 'mongoose';
import mongoosePaginate from 'mongoose-paginate-v2';

export interface IUserConnection extends Document {
  user_id: mongoose.Types.ObjectId;
  connected_user_id: mongoose.Types.ObjectId;
  status: 'pending' | 'accepted' | 'blocked';
  initiated_by: mongoose.Types.ObjectId;
  created_at: Date;
  updated_at: Date;
}

const userConnectionSchema = new Schema<IUserConnection>({
  user_id: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  connected_user_id: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  status: { type: String, default: 'pending', enum: ['pending', 'accepted', 'blocked'] },
  initiated_by: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  created_at: { type: Date, default: Date.now },
  updated_at: { type: Date, default: Date.now }
});

userConnectionSchema.plugin(mongoosePaginate);

userConnectionSchema.index({ user_id: 1, connected_user_id: 1 }, { unique: true });
userConnectionSchema.index({ user_id: 1, status: 1 });

userConnectionSchema.pre('save', function(next) {
  this.updated_at = new Date();
  next();
});

export default mongoose.model<IUserConnection>('UserConnection', userConnectionSchema);

