import mongoose, { Document, Schema } from 'mongoose';
import mongoosePaginate from 'mongoose-paginate-v2';

export interface ICultureArticle extends Document {
  title: string;
  slug: string;
  content: string;
  excerpt: string;
  category: 'tradition' | 'cuisine' | 'music' | 'history' | 'language' | 'festivals' | 'art' | 'literature';
  country: string;
  region?: string;
  language?: string;
  featured_image?: string;
  images?: string[];
  author: string;
  source_url?: string;
  source_name?: string;
  tags: string[];
  views: number;
  likes: number;
  published: boolean;
  featured: boolean;
  published_date: Date;
  created_at: Date;
  updated_at: Date;
}

const cultureArticleSchema = new Schema<ICultureArticle>({
  title: { type: String, required: true, unique: true },
  slug: { type: String, required: true, unique: true, lowercase: true },
  content: { type: String, required: true },
  excerpt: { type: String, required: true, maxlength: 300 },
  category: { 
    type: String, 
    required: true, 
    enum: ['tradition', 'cuisine', 'music', 'history', 'language', 'festivals', 'art', 'literature'] 
  },
  country: { type: String, required: true },
  region: { type: String },
  language: { type: String },
  featured_image: { type: String },
  images: [{ type: String }],
  author: { type: String, default: 'LingAfriq Editorial' },
  source_url: { type: String },
  source_name: { type: String },
  tags: [{ type: String }],
  views: { type: Number, default: 0 },
  likes: { type: Number, default: 0 },
  published: { type: Boolean, default: false },
  featured: { type: Boolean, default: false },
  published_date: { type: Date, default: Date.now },
  created_at: { type: Date, default: Date.now },
  updated_at: { type: Date, default: Date.now }
});

cultureArticleSchema.plugin(mongoosePaginate);

cultureArticleSchema.pre('save', function(next) {
  this.updated_at = new Date();
  if (!this.slug) {
    this.slug = this.title.toLowerCase().replace(/[^\w\s-]/g, '').replace(/\s+/g, '-');
  }
  next();
});

const CultureArticle = mongoose.model<ICultureArticle>('CultureArticle', cultureArticleSchema);
export default CultureArticle as any; // Type assertion for paginate plugin

