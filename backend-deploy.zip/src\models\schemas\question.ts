import mongoose, { Document } from "mongoose";
import dotenv from "dotenv";
dotenv.config();

const { Schema } = mongoose;

export interface Option{
  correct_answer: boolean;
  quiz_question_id: number;
  id: number;
  image: string;
  text: string;
}

type OptionDocument = Option & Document;

export interface Question {
  add_hint: string | null;
  audio: string;
  fun_fact: string;
  id: number;
  image: string;
  is_published: boolean;
  question: string;
  quiz_section_id: number;
  text: string;
  types: string;
  video: string;
  options: Option []
}

type QuestionDocument = Question & Document

export interface WordQuestion {
  content: string, 
  add_hint: string;
  id: number;
  is_published: boolean;
  question: string;
  quiz_section_id: number;
  text: string;
  types: string;
}

interface WordQuestionDocument extends Omit<Document, "id">, WordQuestion{} 

export const optionSchema = new Schema<OptionDocument>({
    correct_answer: { type: Boolean, required: true },
    id: { type: Number, required: true },
    image: { type: String, default: '' },
    quiz_question_id: { type: Number, required: true },
    text: { type: String },
})

optionSchema.path("image").get(function(value: string | null) {
  const hostname = process.env.HOSTNAME; // Get the hostname from your .env file
  if(value === null || value.length === 0) return null;
  return value.length > 1 ? `${hostname}/${value}` : "";
});

const questionSchema = new Schema<QuestionDocument>({
  add_hint: { type: String, default: null },
  audio: { type: String, default: '' },
  fun_fact: { type: String, default: null },
  id: { type: Number, required: true, unique: true },
  image: { type: String, default: '' },
  is_published: { type: Boolean, default: true },
  question: { type: String, required: true },
  quiz_section_id: { type: Number, required: true },
  text: { type: String },
  video: { type: String, default: '' },
  options: {
    type: [optionSchema],
    default: []
  },
});

questionSchema.set("toJSON", {
  transform: function (doc, ret) {
    const hostname = process.env.HOSTNAME; // Make sure HOSTNAME is set in your environment
    if(ret.image && ret.image.length > 0){
      ret.image = `${hostname}/media/${ret.image}`; // Modify the image URL
    }
    if(ret.audio && ret.audio.length > 0){
      ret.audio = `${hostname}/media/${ret.audio}`; // Modify the image URL
    }
    if(ret.video && ret.video.length > 0){
      ret.video = `${hostname}/media/${ret.video}`; // Modify the image URL
    }
    return ret;
  },
})

questionSchema.path("image").get(function(value: string | null) {
  const hostname = process.env.HOSTNAME; // Get the hostname from your .env file
  if(value === null || value.length === 0) return null;
  return value.length > 1 ? `${hostname}/media/${value}` : null;
});

questionSchema.path("video").get(function(value: string | null) {
  const hostname = process.env.HOSTNAME; // Get the hostname from your .env file
  if(value === null || value.length === 0) return null;
  return value.length > 1 ? `${hostname}/media/${value}` : null;
});

questionSchema.path("audio").get(function(value: string | null) {
  const hostname = process.env.HOSTNAME; // Get the hostname from your .env file
  if(value === null || value.length === 0) return null;
  return value.length > 1 ? `${hostname}/media/${value}` : null;
});

export const wordQuestionSchema = new Schema<WordQuestionDocument>({
  content: {type: String},
  add_hint: { type: String, default: null },
  id: { type: Number, required: true },
  is_published: { type: Boolean, default: true },
  question: { type: String, required: true },
  quiz_section_id: { type: Number, required: true },
  text: { type: String },
  types: {type: String}
})

export { questionSchema };