import Joi from "joi";

const optionsSchema = Joi.object({
    id: Joi.number().required(),
    quiz_question_id: Joi.number().required(),
    correct_answer: Joi.boolean().required(),
    image: Joi.string().allow(null, "").default(''),
    text: Joi.string().min(1).required(),
});

export const validateQuestion = (formData: any, section_id: number, question_id: number) => {
    return Joi.object({
        id: Joi.number().unsafe().default(question_id), 
        add_hint: Joi.string().allow(null, "").default(null),
        audio: Joi.string().allow(null, ""),
        fun_fact: Joi.string().allow(null, "").default(null),
        image: Joi.string().allow(null, ""),
        is_published: Joi.boolean().default(true),
        question: Joi.string().required(),
        quiz_section_id: Joi.number().default(section_id),
        text: Joi.string(),
        video: Joi.string().allow(null, ""),
        options: Joi.array().items(optionsSchema).default([]),
    }).validate(formData, {allowUnknown: true, stripUnknown: true})
}