import { NextFunction, Request, Response } from "express";
import { AdminRequest } from "../../types/request.js";
import { ValidationError } from "../../utils/error.js";
import DeviceModel from "../../models/devices.model.js";
import { sendMessage } from "../../services/messagingService.js";
import MessageModel from "../../models/messages.model.js";

export const getAllMessages = async (req: AdminRequest, res: Response, next: NextFunction) => {
    try{
        const devices = await MessageModel.find({});
        res.status(200).json([...devices]);
    } catch(e){
        next(e)
    }
}

export const deleteMessage = async (req: AdminRequest, res: Response, next: NextFunction) => {
    try{
        const { message_id } = req.params
        await MessageModel.findByIdAndDelete(message_id);
        res.status(200).json({msg: "Message Deleted"});
    } catch(e){
        next(e)
    }
}

export const sendMessageToSingleUser = async (req: AdminRequest, res: Response, next: NextFunction) => {
    try{
        const {userId , title, body } = req.body;

        const device = await DeviceModel.findOne({user_id: userId}, null, { sort: { createdAt: -1 } });

        const deviceData = await DeviceModel.findById(device._id);

        const bool = await sendMessage(deviceData.registration_id, title, body);

        if(!bool) throw new Error("Couldn't Send Message");

        const msg = {
            message: {
                title, 
                body
            },
            users: [userId]
        }

        const newMessage = new MessageModel(msg);
        await newMessage.save();

        res.status(200).json({msg: "Message sent to 1 user"});
    } catch(e){
        next(e)
    }
}

export const sendMessageToMultipleUsers = async (req: AdminRequest, res: Response, next: NextFunction) => {
    try{
        const {ids, title, body }: {ids: number [], title: string, body: string} = req.body;

        const bools = await Promise.all(ids.map( async (id)=>{
            try{
                const device = await DeviceModel.findOne({user_id: ids}, null, { sort: { createdAt: -1 } });
                if(!device) return {id, ok: false};
                const deviceData = await DeviceModel.findById(device._id);
                const bool = await sendMessage(deviceData.registration_id, title, body);
                return {id, ok: bool}
            }catch(e){
                return {id, ok: false};
            }   
        }));

        const success = bools.filter(bool=> bool.ok === true).map(bool=>bool.id);

        const msg = {
            message: {
                title, 
                body
            },
            users: [...success]
        }

        const newMessage = new MessageModel(msg);
        await newMessage.save();

        res.status(200).json({msg: `Message sent to ${msg.users.length} users`});
    } catch(e){
        next(e)
    }
}