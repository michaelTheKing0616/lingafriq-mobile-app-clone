import { Router, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import CultureArticle from '../models/cultureMagazine.model.js';

const router = Router();

// Middleware to verify scraper token
const verifyScraperToken = (req: Request, res: Response, next: Function) => {
  const authHeader = req.headers['authorization'];
  
  if (!authHeader) {
    return res.status(401).json({ 
      success: false, 
      error: 'Missing authorization header' 
    });
  }

  const token = authHeader.replace('Bearer ', '');
  const scraperSecret = process.env.SCRAPER_SECRET || process.env.JWT_SECRET;

  try {
    jwt.verify(token, scraperSecret!);
    next();
  } catch (error) {
    return res.status(403).json({ 
      success: false, 
      error: 'Invalid or expired token' 
    });
  }
};

// Bulk save articles endpoint
router.post('/articles/bulk', verifyScraperToken, async (req: Request, res: Response) => {
  try {
    const { articles } = req.body;

    if (!Array.isArray(articles)) {
      return res.status(400).json({
        success: false,
        error: 'Articles must be an array'
      });
    }

    const savedArticles = [];
    const skippedArticles = [];
    const errors = [];

    for (const article of articles) {
      try {
        // Check if article already exists
        const existing = await CultureArticle.findOne({ title: article.title });
        
        if (existing) {
          skippedArticles.push({
            title: article.title,
            reason: 'Already exists'
          });
          continue;
        }

        // Validate required fields
        if (!article.title || !article.content || !article.category) {
          skippedArticles.push({
            title: article.title || 'Unknown',
            reason: 'Missing required fields'
          });
          continue;
        }

        // Create and save article
        const newArticle = new CultureArticle({
          ...article,
          published: false, // Require manual review
          featured: false,
          author: article.author || 'LingAfriq Editorial Team',
          published_date: article.published_date || new Date(),
          created_at: new Date(),
          updated_at: new Date()
        });

        await newArticle.save();
        savedArticles.push({
          id: newArticle._id,
          title: newArticle.title,
          category: newArticle.category
        });

      } catch (error: any) {
        errors.push({
          title: article.title,
          error: error.message
        });
      }
    }

    res.json({
      success: true,
      message: 'Bulk article save completed',
      stats: {
        total: articles.length,
        saved: savedArticles.length,
        skipped: skippedArticles.length,
        errors: errors.length
      },
      savedArticles,
      skippedArticles,
      errors
    });

  } catch (error: any) {
    console.error('Bulk save error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to save articles',
      message: error.message
    });
  }
});

// Single article save endpoint
router.post('/articles/save', verifyScraperToken, async (req: Request, res: Response) => {
  try {
    const article = req.body;

    // Validate required fields
    if (!article.title || !article.content || !article.category) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields: title, content, or category'
      });
    }

    // Check if article already exists
    const existing = await CultureArticle.findOne({ title: article.title });
    
    if (existing) {
      return res.status(409).json({
        success: false,
        error: 'Article with this title already exists',
        existingId: existing._id
      });
    }

    // Create and save article
    const newArticle = new CultureArticle({
      ...article,
      published: false, // Require manual review
      featured: false,
      author: article.author || 'LingAfriq Editorial Team',
      published_date: article.published_date || new Date(),
      created_at: new Date(),
      updated_at: new Date()
    });

    await newArticle.save();

    res.status(201).json({
      success: true,
      message: 'Article saved successfully',
      article: {
        id: newArticle._id,
        title: newArticle.title,
        category: newArticle.category,
        slug: newArticle.slug
      }
    });

  } catch (error: any) {
    console.error('Save article error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to save article',
      message: error.message
    });
  }
});

// Health check endpoint (no auth required)
router.get('/health', (req: Request, res: Response) => {
  res.json({
    success: true,
    message: 'Scraper API is running',
    timestamp: new Date().toISOString()
  });
});

export default router;

