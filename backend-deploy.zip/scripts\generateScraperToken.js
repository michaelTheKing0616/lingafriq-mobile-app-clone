/**
 * Generate Scraper Token
 * 
 * This script generates a JWT token that can be used by the automated scraper
 * to authenticate with the /scraper API endpoints.
 * 
 * Usage:
 *   node scripts/generateScraperToken.js
 * 
 * The generated token should be added to GitHub Secrets as SCRAPER_TOKEN
 */

import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';

dotenv.config();

const generateScraperToken = () => {
  const secret = process.env.SCRAPER_SECRET || process.env.JWT_SECRET;

  if (!secret) {
    console.error('❌ ERROR: Neither SCRAPER_SECRET nor JWT_SECRET is set in .env file');
    console.error('');
    console.error('Please add one of these to your .env file:');
    console.error('  SCRAPER_SECRET=your_secret_key_here');
    console.error('  OR');
    console.error('  JWT_SECRET=your_jwt_secret_here');
    console.error('');
    process.exit(1);
  }

  // Generate token that never expires (for automated scraper)
  const token = jwt.sign(
    {
      type: 'scraper',
      purpose: 'automated_content_import',
      generated: new Date().toISOString()
    },
    secret
    // No expiration for scraper tokens
  );

  console.log('');
  console.log('==========================================');
  console.log('✅ SCRAPER TOKEN GENERATED');
  console.log('==========================================');
  console.log('');
  console.log('Copy the token below and add it to GitHub Secrets:');
  console.log('');
  console.log('1. Go to: https://github.com/YOUR_ORG/node-backend/settings/secrets/actions');
  console.log('2. Click "New repository secret"');
  console.log('3. Name: SCRAPER_TOKEN');
  console.log('4. Secret: (paste the token below)');
  console.log('5. Click "Add secret"');
  console.log('');
  console.log('==========================================');
  console.log('TOKEN:');
  console.log('==========================================');
  console.log(token);
  console.log('==========================================');
  console.log('');
  console.log('⚠️  Keep this token secure!');
  console.log('⚠️  Do not commit it to version control');
  console.log('⚠️  Only store it in GitHub Secrets');
  console.log('');
};

// Run if executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  generateScraperToken();
}

export { generateScraperToken };

