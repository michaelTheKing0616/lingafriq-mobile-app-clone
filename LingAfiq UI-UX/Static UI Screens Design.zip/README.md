
  # Static UI Screens Design

  This is a code bundle for Static UI Screens Design. The original project is available at https://www.figma.com/design/Qjk8N0uNexgaZg1zyNPmr9/Static-UI-Screens-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  