import React from 'react';
import { AllScreensIndex } from './components/AllScreensIndex';

export default function App() {
  return <AllScreensIndex />;
}